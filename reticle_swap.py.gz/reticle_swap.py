"""Custom reticle / crosshair swap for Population: One (Pop1Forge).

The sight reticles are plain DXT5 Texture2D objects inside
``sharedassets1.assets`` (pixels streamed in the sibling ``.resS``). Each is a
single mip, so a swap is a *byte-exact* overwrite of that texture's slice of the
.resS — offsets never move, the .assets index is untouched, file sizes are
identical. That is the safest possible patch and needs only one backup to undo.

The stock reticles are a white shape on transparent alpha; the in-game colour
picker tints them. So by default we keep your art as a white shape (alpha =
your drawing) and let the game colour it — same as stock. Pass whiten=False to
bake your own colours in instead.

Legal: reticles are extracted from / written to the USER'S OWN install. Nothing
here ships game assets. A reticle is a gameplay HUD element, not a cosmetic
weapon skin, so confirm it falls under the BigBox texture-mod permission before
using it in ranked lobbies.
"""
import os

# The sniper scope reticle (the AWP one) is scope_crosshair. The rest are the
# other selectable reticles / masks in the same file.
RETICLES = [
    "scope_crosshair",   # AWP / sniper scope duplex crosshair  (2048)
    "Reticle_4",         # red-dot preset ring+ticks+dot          (2048)
    "reflex_crosshair",  # reflex sight crosshair                  (512)
    "scope_circlemask",  # scope vignette / circle mask            (512)
    "tunnel_reticle",    # scope tunnel reticle                    (512)
]

_GAME_GUESSES = [
    r"C:\Program Files\Meta Horizon\Software\Software\big-box-vr-inc-battleroyale",
    r"C:\Program Files\Oculus\Software\Software\big-box-vr-inc-battleroyale",
]
_REL = os.path.join("PopulationONE_Data", "sharedassets1.assets")


def find_assets(game_dir=None):
    """Path to the install's sharedassets1.assets, or None."""
    for g in ([game_dir] if game_dir else []) + _GAME_GUESSES:
        if not g:
            continue
        p = g if g.lower().endswith(".assets") else os.path.join(g, _REL)
        if os.path.isfile(p):
            return p
    return None


def _ress_for(assets_path):
    return assets_path + ".resS"


def _find_tex(env, name):
    for obj in env.objects:
        if obj.type.name == "Texture2D":
            d = obj.read()
            if getattr(d, "m_Name", "") == name:
                return d
    return None


def _stream(tex):
    """(offset, size) of this texture's pixels inside the .resS, or None."""
    sd = getattr(tex, "m_StreamData", None)
    if not sd:
        return None
    path = getattr(sd, "path", "") or ""
    size = int(getattr(sd, "size", 0) or 0)
    off = int(getattr(sd, "offset", 0) or 0)
    if not path or not size:
        return None
    return off, size, os.path.basename(path)


def list_reticles(assets_path):
    """[{name, w, h, offset, size}] for every reticle present."""
    import UnityPy
    env = UnityPy.load(assets_path)
    out = []
    wanted = set(RETICLES)
    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        d = obj.read()
        nm = getattr(d, "m_Name", "")
        if nm in wanted:
            s = _stream(d)
            out.append({"name": nm, "w": int(d.m_Width), "h": int(d.m_Height),
                        "offset": s[0] if s else None, "size": s[1] if s else None})
    out.sort(key=lambda r: RETICLES.index(r["name"]) if r["name"] in RETICLES else 99)
    return out


def _slice_backup(assets_path, tex, backup_dir):
    """Save this reticle's ORIGINAL bytes once (a few MB), so it can be undone.

    We only ever touch the .resS pixel bytes, never the .assets index, so the
    offset/size never move — a per-reticle slice is all restore needs.
    """
    s = _stream(tex)
    if not s:
        return
    off, size, ress_name = s
    os.makedirs(backup_dir, exist_ok=True)
    dst = os.path.join(backup_dir, getattr(tex, "m_Name", "reticle") + ".slice")
    if os.path.isfile(dst) and os.path.getsize(dst) == size:
        return  # pristine copy already saved — don't overwrite with modded bytes
    ress = os.path.join(os.path.dirname(assets_path), ress_name)
    with open(ress, "rb") as f:
        f.seek(off)
        data = f.read(size)
    with open(dst, "wb") as f:
        f.write(data)


def backup_exists(backup_dir):
    return (os.path.isdir(backup_dir)
            and any(fn.endswith(".slice") for fn in os.listdir(backup_dir)))


def restore(assets_path, backup_dir):
    """Write every backed-up reticle's original bytes back. Returns names restored."""
    if not os.path.isdir(backup_dir):
        return []
    import UnityPy
    slices = {fn[:-6]: os.path.join(backup_dir, fn)
              for fn in os.listdir(backup_dir) if fn.endswith(".slice")}
    if not slices:
        return []
    env = UnityPy.load(assets_path)
    done = []
    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        d = obj.read()
        nm = getattr(d, "m_Name", "")
        if nm not in slices:
            continue
        s = _stream(d)
        if not s:
            continue
        off, size, ress_name = s
        with open(slices[nm], "rb") as f:
            data = f.read()
        if len(data) != size:
            continue
        ress = os.path.join(os.path.dirname(assets_path), ress_name)
        with open(ress, "r+b") as f:
            f.seek(off)
            f.write(data)
        done.append(nm)
    return done


def _encode_dxt5_img(img, w, h, whiten=True):
    from PIL import Image
    from UnityPy.export.Texture2DConverter import image_to_texture2d
    from UnityPy.enums import TextureFormat
    img = img.convert("RGBA")
    if img.size != (w, h):
        img = img.resize((w, h), Image.LANCZOS)
    if whiten:
        # RGB must FOLLOW alpha: white where the shape is, BLACK where transparent.
        # The stock reticles are built this way and the scope shader reads RGB, so a
        # white background (even at alpha 0) blacks out the whole magnified lens.
        a = img.split()[3]
        img = Image.merge("RGBA", (a, a, a, a))
    enc, _fmt = image_to_texture2d(img, TextureFormat.DXT5, flip=True)
    return enc, img


def _encode_dxt5(png_path, w, h, whiten=True):
    from PIL import Image
    return _encode_dxt5_img(Image.open(png_path), w, h, whiten=whiten)


def inject_image(assets_path, tex_name, pil_img, whiten=True, backup_dir=None,
                 out_ress=None):
    """Overwrite one reticle in-place from a PIL image. Byte-exact; backs up first.

    out_ress: patch THIS .resS file instead of the one next to assets_path (used to
    build a shareable copy without touching the live game). No backup in that case —
    offsets/sizes still come from the (unchanged) game .assets index.

    Returns a dict describing what happened. Raises on any size mismatch so a
    bad encode can never corrupt the file.
    """
    import UnityPy
    env = UnityPy.load(assets_path)
    tex = _find_tex(env, tex_name)
    if tex is None:
        raise ValueError("reticle %r not found in %s" % (tex_name, assets_path))
    s = _stream(tex)
    if not s:
        raise ValueError("%r is not streamed — unexpected layout" % tex_name)
    offset, size, ress_name = s
    w, h = int(tex.m_Width), int(tex.m_Height)

    enc, _used = _encode_dxt5_img(pil_img, w, h, whiten=whiten)
    if len(enc) != size:
        raise ValueError(
            "encoded %d bytes but the slot is %d (w=%d h=%d). Reticle must stay "
            "%dx%d." % (len(enc), size, w, h, w, h))

    if backup_dir and not out_ress:
        _slice_backup(assets_path, tex, backup_dir)  # pristine bytes, before we overwrite

    ress = out_ress or os.path.join(os.path.dirname(assets_path), ress_name)
    with open(ress, "r+b") as f:
        f.seek(offset)
        f.write(enc)
    return {"name": tex_name, "w": w, "h": h, "offset": offset,
            "size": size, "ress": ress_name}


def inject(assets_path, tex_name, png_path, whiten=True, backup_dir=None):
    """File-path wrapper around inject_image (used by the CLI / standalone tool)."""
    from PIL import Image
    return inject_image(assets_path, tex_name, Image.open(png_path),
                        whiten=whiten, backup_dir=backup_dir)


def build_assets_file(assets_path, tex_name, pil_img, out_assets, whiten=True):
    """Bake ONE reticle INLINE into a copy of sharedassets1.assets at out_assets.

    Unlike the .resS byte-patch, this rewrites the small .assets index and stores
    the reticle's pixels *inside* it (m_StreamData cleared), so the file needs no
    .resS for that reticle. Every other texture keeps streaming from the user's own
    .resS. The live game is NOT touched. Result is ~20 MB vs the 385 MB .resS.
    """
    import UnityPy
    from PIL import Image
    from UnityPy.enums import TextureFormat
    env = UnityPy.load(assets_path)
    tgt = None
    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        d = obj.read()
        if getattr(d, "m_Name", "") == tex_name:
            tgt = d
            break
    if tgt is None:
        raise ValueError("reticle %r not found in %s" % (tex_name, assets_path))
    w, h = int(tgt.m_Width), int(tgt.m_Height)
    img = pil_img.convert("RGBA")
    if img.size != (w, h):
        img = img.resize((w, h), Image.LANCZOS)
    if whiten:
        a = img.split()[3]                    # RGB follows alpha (matches the stock art)
        img = Image.merge("RGBA", (a, a, a, a))
    try:
        tgt.set_image(img, target_format=TextureFormat.DXT5)
    except TypeError:
        tgt.set_image(img, TextureFormat.DXT5)
    sd = getattr(tgt, "m_StreamData", None)   # force inline: bytes go INTO the .assets
    if sd is not None:
        sd.path = ""
        sd.offset = 0
        sd.size = 0
    tgt.save()
    if os.path.dirname(out_assets):
        os.makedirs(os.path.dirname(out_assets), exist_ok=True)
    with open(out_assets, "wb") as f:
        f.write(env.file.save())
    return {"name": tex_name, "w": w, "h": h, "assets": out_assets,
            "bytes": os.path.getsize(out_assets)}


def verify(assets_path, tex_name):
    """Reload after a swap and return the now-live image (proves the file parses)."""
    import UnityPy
    env = UnityPy.load(assets_path)
    tex = _find_tex(env, tex_name)
    if tex is None:
        raise ValueError("verify: %r vanished" % tex_name)
    return tex.image.convert("RGBA")


def _decode_slice(data, w, h):
    """Decode a raw DXT5 .resS slice back to a PIL RGBA image (display orientation)."""
    from UnityPy.export.Texture2DConverter import parse_image_data
    from UnityPy.enums import TextureFormat
    img = parse_image_data(data, w, h, TextureFormat.DXT5, (2021, 3, 0, 0), 0, None)
    return img.convert("RGBA")


def export_originals(assets_path, backup_dir, out_dir):
    """Write each reticle's ORIGINAL image to out_dir as a PNG. Returns [paths].

    Prefers the pristine backup slice, so it is the TRUE original even for a
    reticle that has already been swapped; otherwise the live texture is the
    original. A clean base to trace over, then re-import through the aligner.
    """
    import UnityPy
    os.makedirs(out_dir, exist_ok=True)
    env = UnityPy.load(assets_path)
    made = []
    order = {n: i for i, n in enumerate(RETICLES)}
    found = []
    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        d = obj.read()
        nm = getattr(d, "m_Name", "")
        if nm not in order:
            continue
        w, h = int(d.m_Width), int(d.m_Height)
        slice_path = os.path.join(backup_dir, nm + ".slice") if backup_dir else ""
        if slice_path and os.path.isfile(slice_path):
            with open(slice_path, "rb") as f:
                img = _decode_slice(f.read(), w, h)   # the pristine original
        else:
            img = d.image.convert("RGBA")             # live == original (never swapped)
        found.append((order[nm], nm, img))
    for _, nm, img in sorted(found):
        out = os.path.join(out_dir, nm + ".png")
        img.save(out)
        made.append(out)
    return made


# ---------------------------------------------------------------- CLI
def _main(argv):
    import argparse
    ap = argparse.ArgumentParser(description="Population: One custom reticle swap")
    ap.add_argument("cmd", choices=["list", "inject", "restore"])
    ap.add_argument("--assets", help="path to sharedassets1.assets (auto if omitted)")
    ap.add_argument("--name", default="scope_crosshair", help="reticle to replace")
    ap.add_argument("--png", help="your reticle PNG (white shape on transparent)")
    ap.add_argument("--keep-colors", action="store_true",
                    help="bake your PNG colours instead of whitening for the in-game tint")
    ap.add_argument("--backup", help="backup folder (default: <assets>/../Reticle Backup)")
    a = ap.parse_args(argv)

    assets = a.assets or find_assets()
    if not assets:
        print("Could not find sharedassets1.assets. Pass --assets.")
        return 2
    bdir = a.backup or os.path.join(os.path.dirname(assets), "Reticle Backup")

    if a.cmd == "list":
        for r in list_reticles(assets):
            print("  %-18s %dx%d  slot=%s bytes @ %s" %
                  (r["name"], r["w"], r["h"], r["size"], r["offset"]))
    elif a.cmd == "restore":
        print("restored:", ", ".join(restore(assets, bdir)) or "(no backup found)")
    elif a.cmd == "inject":
        if not a.png:
            print("--png required")
            return 2
        info = inject(assets, a.name, a.png, whiten=not a.keep_colors, backup_dir=bdir)
        print("injected %(name)s (%(w)dx%(h)d, %(size)d bytes) into %(ress)s" % info)
        print("backup in:", bdir)
    return 0


if __name__ == "__main__":
    import sys
    raise SystemExit(_main(sys.argv[1:]))
