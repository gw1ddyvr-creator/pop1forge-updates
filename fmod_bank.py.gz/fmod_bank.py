# =============================================================================
#  fmod_bank.py  -  POP-1 Skin Forge  -  FMOD Studio bank sound engine
#  Copyright (c) 2026 GW1DDY. All rights reserved.
#
#  Population: ONE ships its audio as FMOD Studio banks in the game's
#  StreamingAssets folder.  Each bank is a RIFF/"FEV " container:
#
#     RIFF "FEV "
#       FMT   (8)
#       LIST  (PROJ metadata: BNKI, per-WAV names ...)
#       SND   (4-byte prefix + an FSB5 sample-data blob)   <- the audio lives here
#       SND   (optional 2nd FSB5 blob)
#
#  The gun sounds are in  Item.assets.bank  ->  FSB5 codec = PCM16 (uncompressed),
#  599 named samples.  Because it's plain PCM there is NO lossy re-encode and no
#  FMOD-Vorbis codebook problem: we can read a sample straight out as a .wav and
#  splice a new PCM16 sample back in losslessly.
#
#  This module is PURE PYTHON for the PCM16 path (extract / preview / rebuild) so
#  the gun-sound pipeline is deterministic and needs no native decoder.  Non-PCM
#  banks (music / env / social hub = FADPCM) are preview-only and decoded with
#  the FMOD engine via fmod_toolkit when available.
#
#  Round-trip verified: re-splicing a sample's own bytes reproduces the original
#  bank byte-for-byte (see  python fmod_bank.py --selftest).
# =============================================================================

import os
import io
import re
import struct
import wave

try:
    import numpy as np
except Exception:                       # numpy is bundled, but degrade gracefully
    np = None

try:
    import fadpcm                        # FMOD FADPCM codec (music / env / hub banks)
except Exception:
    fadpcm = None

REBUILDABLE_CODECS = ("PCM16", "FADPCM")


# ---- the game install -------------------------------------------------------
GAME_SA = (
    r"C:\Program Files\Meta Horizon\Software\Software"
    r"\big-box-vr-inc-battleroyale\PopulationONE_Data\StreamingAssets"
)
# Steam ships the game in a different tree; the layout under PopulationONE_Data is
# identical, only the base differs. Auto-detected if the Meta path is absent.
GAME_SA_STEAM = (
    r"C:\Program Files (x86)\Steam\steamapps\common\PopulationONE"
    r"\PopulationONE_Data\StreamingAssets"
)

# FSB5 sample-rate enum (the 4-bit frequency index in a sample header)
FREQ_TABLE = {1: 8000, 2: 11025, 3: 16000, 4: 22050, 5: 24000,
              6: 32000, 7: 44100, 8: 48000, 9: 96000}
FREQ_REVERSE = {v: k for k, v in FREQ_TABLE.items()}

FSB_CODECS = {0: "NONE", 1: "PCM8", 2: "PCM16", 3: "PCM24", 4: "PCM32",
              5: "PCMFLOAT", 6: "GCADPCM", 7: "IMAADPCM", 8: "VAG", 9: "HEVAG",
              10: "XMA", 11: "MPEG", 12: "CELT", 13: "AT9", 14: "XWMA",
              15: "VORBIS", 16: "FADPCM", 17: "OPUS"}

# extra-chunk types inside a sample header (when the "next" bit is set)
CHUNK_CHANNELS = 1
CHUNK_FREQUENCY = 2
CHUNK_LOOP = 3

# What each Population: ONE bank is, for the "locate the other sounds" view.
# (bank base name -> human description).  ".assets.bank" holds the audio;
# the matching ".bank" is just events/metadata.
BANK_GUIDE = {
    "Item":          "Weapons + items: gunfire, reloads, prime/rack, impacts, grenades, knife, pickups",
    "Music_Loading": "Loading-screen music",
    "Music_Intro":   "Intro / splash music",
    "Music_MainMenu":"Main-menu music",
    "MainMenu":      "Main-menu UI sounds",
    "SocialHub":     "Social Hub / night-club: club music beds, ambience, hub SFX",
    "Character":     "Characters: footsteps, voices, movement, shields",
    "Dialogue":      "Announcer / dialogue lines",
    "DropPod":       "Drop-pod deploy sequence",
    "Destructables": "Destructible objects breaking",
    "Env_Default":   "Environment ambience (default)",
    "Env_Day":       "Environment ambience (day)",
    "Env_Night":     "Environment ambience (night)",
    "Env_Sunset":    "Environment ambience (sunset)",
    "InGameEvents":  "In-match events (zone, circle, announcements)",
    "SinglePlayer":  "Single-player / practice",
    "Tutorial":      "Tutorial",
    "UGC":           "User-generated content mode",
    "UI":            "General UI clicks / menu SFX",
    "Master":        "Master bus (tiny)",
}

# --- "likely looped/sustained" heuristic ------------------------------------
# The real loop info lives in the FMOD event (metadata bank / project), which we
# can't read. This is a NAME/LENGTH guess so the UI can warn: sustained sounds
# (held while an action runs — drinking, charging, a blade hum) must be replaced
# with a clip AT LEAST as long as the original, or the loop can cut to silence.
SUSTAINED_TOKENS = ("eat", "charge", "_active", "drain", "channel", "brew",
                    "revive", "heal", "_hum", "_idle", "_loop", "beam",
                    "engine", "thrust", "_spin", "_whir", "ambient")
ONESHOT_TOKENS = ("fire", "shot", "impact", "reload", "prime", "magin", "magout",
                  "wield", "_pop", "slash", "stab", "swish", "break", "expend",
                  "shell", "distant", "belch", "burp", "drop", "pickup", "crack",
                  "click", "grip", "activate", "deactivate", "release", "wind")


def likely_looped(name, seconds):
    """Best-effort guess: is this a sustained/looped sound (held in-game)?"""
    n = (name or "").lower()
    if any(t in n for t in SUSTAINED_TOKENS):
        return True
    if any(t in n for t in ONESHOT_TOKENS):
        return False
    return seconds >= 2.0


# --- numbered variant grouping (Firing_01 / _02 / _03 = round-robin) ---------
_VARIANT_RE = re.compile(r"_(\d+)$")


def variant_base(name):
    """The name with its trailing _NN stripped, or None if it has no number.
    Samples sharing a base are round-robin variations of the same sound
    (RifleAWP_Firing_01/_02/_03). FiringDistant stays a separate base."""
    m = _VARIANT_RE.search(name or "")
    return name[:m.start()] if m else None


# ---- FSB5 bit-packing helpers ----------------------------------------------
def _unpack_mode(v):
    return {
        "next":  v & 1,
        "freq":  (v >> 1) & 0xF,
        "chans": ((v >> 5) & 0x3) + 1,
        "off32": (v >> 7) & 0x07FFFFFF,     # data offset in 32-byte units
        "nsamp": (v >> 34) & 0x3FFFFFFF,    # length in samples (frames)
    }


def _pack_mode(next_, freq, chans, off32, nsamp):
    return ((next_ & 1)
            | ((freq & 0xF) << 1)
            | (((chans - 1) & 0x3) << 5)
            | ((off32 & 0x07FFFFFF) << 7)
            | ((nsamp & 0x3FFFFFFF) << 34))


class FsbSample:
    __slots__ = ("idx", "name", "freq_idx", "freq", "chans", "offset",
                 "nsamp", "datalen", "hdr_pos", "hdr_size", "loop",
                 "freq_chunk", "chans_chunk")

    def __init__(self):
        self.idx = 0
        self.name = None
        self.freq_idx = 0
        self.freq = 0            # effective Hz (FREQUENCY chunk overrides the enum)
        self.chans = 1
        self.offset = 0          # byte offset within the FSB5 data section
        self.nsamp = 0
        self.datalen = 0
        self.hdr_pos = 0         # absolute file offset of the 8-byte packed header
        self.hdr_size = 8        # 8 + any extra chunks
        self.loop = None         # (chunk_pos, start, end) if a LOOP chunk exists
        self.freq_chunk = None   # byte pos of a FREQUENCY chunk's value, if present
        self.chans_chunk = None  # byte pos of a CHANNELS chunk's value, if present


class Fsb5:
    """One FSB5 blob, parsed in place from the bank buffer."""

    def __init__(self, buf, base):
        self.buf = buf
        self.base = base
        (magic, self.version, self.num, self.sh_size, self.nt_size,
         self.data_size, self.mode) = struct.unpack_from("<4sIIIIII", buf, base)
        if magic != b"FSB5":
            raise ValueError("not an FSB5 at %d" % base)
        self.codec = FSB_CODECS.get(self.mode, "?%d" % self.mode)
        self.hdr_fixed = 60                        # v1 fixed header
        self.sh_start = base + self.hdr_fixed
        self.nt_start = self.sh_start + self.sh_size
        self.data_start = self.nt_start + self.nt_size
        self.total = self.hdr_fixed + self.sh_size + self.nt_size + self.data_size
        self.end = base + self.total
        self.samples = self._parse_samples()
        self._read_names()

    def _parse_samples(self):
        buf = self.buf
        out = []
        p = self.sh_start
        for i in range(self.num):
            v = struct.unpack_from("<Q", buf, p)[0]
            m = _unpack_mode(v)
            s = FsbSample()
            s.idx = i
            s.hdr_pos = p
            s.freq_idx = m["freq"]
            s.freq = FREQ_TABLE.get(m["freq"], 44100)
            s.chans = m["chans"]
            s.offset = m["off32"] * 32
            s.nsamp = m["nsamp"]
            p += 8
            if m["next"]:
                while True:
                    ck = struct.unpack_from("<I", buf, p)[0]
                    more = ck & 1
                    csize = (ck >> 1) & 0xFFFFFF     # 24-bit size
                    ctype = (ck >> 25) & 0x7F        # 7-bit type
                    cpos = p + 4
                    if ctype == CHUNK_FREQUENCY and csize >= 4:
                        s.freq = struct.unpack_from("<I", buf, cpos)[0]
                        s.freq_chunk = cpos
                    elif ctype == CHUNK_CHANNELS and csize >= 1:
                        s.chans = buf[cpos]
                        s.chans_chunk = cpos
                    elif ctype == CHUNK_LOOP and csize >= 8:
                        ls, le = struct.unpack_from("<II", buf, cpos)
                        s.loop = (cpos, ls, le)
                    p += 4 + csize
                    if not more:
                        break
            s.hdr_size = p - s.hdr_pos
            out.append(s)
        # data length of each sample = gap to the next sample's offset
        for i, s in enumerate(out):
            nxt = out[i + 1].offset if i + 1 < len(out) else self.data_size
            s.datalen = nxt - s.offset
        return out

    def _read_names(self):
        if not self.nt_size:
            return
        buf = self.buf
        offs = struct.unpack_from("<%dI" % self.num, buf, self.nt_start)
        for i, o in enumerate(offs):
            q = self.nt_start + o
            e = buf.find(b"\x00", q)
            try:
                self.samples[i].name = buf[q:e].decode("utf-8", "replace")
            except Exception:
                self.samples[i].name = "sample_%d" % i

    def sample_bytes(self, i):
        """Full stored region for sample i (datalen bytes, incl. FMOD padding)."""
        s = self.samples[i]
        start = self.data_start + s.offset
        return self.buf[start:start + s.datalen]

    def sample_audio(self, i):
        """Exact audio for sample i (nsamp*chans*2 bytes for PCM16, no padding)."""
        s = self.samples[i]
        start = self.data_start + s.offset
        n = s.nsamp * s.chans * 2
        return self.buf[start:start + min(n, s.datalen)]


class Bank:
    """An FMOD Studio .bank file with its main FSB5 exposed for edit."""

    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            self.buf = f.read()
        if self.buf[:4] != b"RIFF":
            raise ValueError("not a RIFF/FMOD bank: %s" % path)
        self.riff_size = struct.unpack_from("<I", self.buf, 4)[0]
        self.snd_chunks = self._find_snd_chunks()
        self.fsb = None
        self.fsb_snd = None
        # the audio blob is the first SND chunk that actually holds an FSB5
        for (pos, size, body, body_end) in self.snd_chunks:
            fi = self.buf.find(b"FSB5", body, body_end)
            if fi >= 0:
                self.fsb = Fsb5(self.buf, fi)
                self.fsb_snd = (pos, size, body, body_end)
                break

    def _find_snd_chunks(self):
        """Walk the top-level RIFF chunks, return every 'SND ' chunk."""
        buf = self.buf
        out = []
        p = 12                                      # skip RIFF+size+form ("FEV ")
        n = len(buf)
        while p + 8 <= n:
            cid = buf[p:p + 4]
            size = struct.unpack_from("<I", buf, p + 4)[0]
            body = p + 8
            body_end = body + size
            if cid == b"SND ":
                out.append((p, size, body, body_end))
            p = body_end
            if size & 1:
                p += 1
        return out

    # -- metadata for the UI ------------------------------------------------
    def codec(self):
        return self.fsb.codec if self.fsb else "?"

    def sample_list(self):
        if not self.fsb:
            return []
        # map each variant base -> [indices] so the UI can offer "replace all"
        groups = {}
        for s in self.fsb.samples:
            base = variant_base(s.name or "")
            if base:
                groups.setdefault(base, []).append(s.idx)
        out = []
        for s in self.fsb.samples:
            name = s.name or ("sample_%d" % s.idx)
            seconds = round(s.nsamp / float(s.freq), 3) if s.freq else 0
            base = variant_base(name)
            sibs = groups.get(base, []) if base else []
            out.append({
                "index": s.idx,
                "name": name,
                "freq": s.freq,
                "chans": s.chans,
                "bytes": s.datalen,
                "frames": s.nsamp,
                "seconds": seconds,
                "loop": bool(s.loop),
                "sustained": likely_looped(name, seconds),
                "variants": sibs if len(sibs) > 1 else [],
            })
        return out


class ExtFsb:
    """A raw FSB5 blob (a .fsb file, or an FSB5 found embedded in some other file
    someone sent) wrapped to look like a Bank for read-only sound extraction."""

    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            self.buf = f.read()
        fi = self.buf.find(b"FSB5")
        if fi < 0:
            raise ValueError("no FMOD audio (FSB5) found in %s" % os.path.basename(path))
        self.fsb = Fsb5(self.buf, fi)
        self.fsb_snd = None

    def codec(self):
        return self.fsb.codec if self.fsb else "?"

    def sample_list(self):
        return Bank.sample_list(self)


# ---- PCM16 <-> WAV ----------------------------------------------------------
def pcm16_to_wav(pcm, freq, chans):
    """Wrap raw little-endian PCM16 bytes in a .wav container (no re-encode)."""
    out = io.BytesIO()
    w = wave.open(out, "wb")
    w.setnchannels(chans)
    w.setsampwidth(2)
    w.setframerate(freq)
    w.writeframes(pcm)
    w.close()
    return out.getvalue()


def tile_pcm16(pcm, chans, target_frames):
    """Repeat PCM16 audio to reach target_frames (per channel), trimmed exact.

    For sustained/looped sounds: filling the original slot length with a tiled
    copy of a short clip keeps a held loop continuous instead of dropping into
    the silence a shorter replacement would leave.
    """
    fb_bytes = 2 * chans
    cur = len(pcm) // fb_bytes
    if cur == 0 or cur >= target_frames:
        return pcm
    reps = (target_frames + cur - 1) // cur
    return (pcm * reps)[:target_frames * fb_bytes]


def wav_info(data):
    """(sample_rate, channels, frames) of a PCM WAV, or None if unreadable."""
    try:
        w = wave.open(io.BytesIO(data), "rb")
        return w.getframerate(), w.getnchannels(), w.getnframes()
    except Exception:
        return None


def codec_roundtrip(pcm, codec, chans):
    """Return PCM as it will sound after the slot's codec: PCM16 is lossless
    (unchanged); FADPCM is encoded then decoded so the caller hears the real
    in-game result before installing."""
    if codec == "FADPCM" and fadpcm is not None and pcm:
        nsamp = len(pcm) // (2 * chans)
        try:
            return fadpcm.decode(fadpcm.encode(pcm, chans), chans, nsamp)
        except Exception:
            return pcm
    return pcm


def sample_to_wav(bank, index):
    """Return .wav bytes for one sample. PCM16 -> direct; other codecs via FMOD."""
    s = bank.fsb.samples[index]
    if bank.fsb.codec == "PCM16":
        return pcm16_to_wav(bank.fsb.sample_audio(index), s.freq, s.chans)
    if bank.fsb.codec == "FADPCM" and fadpcm is not None:
        try:
            pcm = fadpcm.decode(bank.fsb.sample_bytes(index), s.chans, s.nsamp)
            return pcm16_to_wav(pcm, s.freq, s.chans)
        except Exception:
            pass
    # any other codec (or FADPCM fallback) -> decode with the FMOD engine
    return _fmod_subsound_wav(bank, index)


# ---- universal input decode (mp3 / ogg / flac / m4a / ... via FMOD) --------
AUDIO_MIME = {
    ".wav": "audio/wav", ".mp3": "audio/mpeg", ".ogg": "audio/ogg",
    ".oga": "audio/ogg", ".opus": "audio/ogg", ".flac": "audio/flac",
    ".m4a": "audio/mp4", ".mp4": "audio/mp4", ".aac": "audio/aac",
    ".aif": "audio/aiff", ".aiff": "audio/aiff", ".wma": "audio/x-ms-wma",
}


def audio_mime(name):
    return AUDIO_MIME.get(os.path.splitext(name or "")[1].lower(), "audio/wav")


def _is_wav(data):
    return len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WAVE"


def _fmod_decode_to_wav(data):
    """Decode any FMOD-supported compressed audio (mp3/ogg/flac/aiff/wma/...) to
    PCM WAV bytes using the bundled FMOD engine. ACCURATETIME so VBR MP3 length
    is exact (no truncation); CREATESAMPLE so the whole thing is decoded."""
    import fmod_toolkit
    from fmod_toolkit.importer import import_pyfmodex
    pf = import_pyfmodex()
    system, lock = fmod_toolkit.get_pyfmodex_system_instance(
        2, pf.flags.INIT_FLAGS.NORMAL)
    with lock:
        mode = (pf.flags.MODE.OPENMEMORY | pf.flags.MODE.CREATESAMPLE
                | pf.flags.MODE.ACCURATETIME)
        snd = system.create_sound(
            bytes(data), mode,
            exinfo=pf.structure_declarations.CREATESOUNDEXINFO(length=len(data)))
        try:
            return fmod_toolkit.subsound_to_wav(snd, True)
        finally:
            snd.release()


def decode_audio_to_wav(data):
    """Return PCM WAV bytes for any supported input (WAV passthrough, else FMOD)."""
    if _is_wav(data):
        return data
    try:
        return _fmod_decode_to_wav(data)
    except Exception as e:
        raise ValueError(
            "Couldn't decode this audio file (%s). Supported: WAV, MP3, OGG, "
            "FLAC, AIFF. For .m4a/.mp4/.aac try MP3 or OGG instead." % type(e).__name__)


def audio_info(data):
    """(sample_rate, channels, seconds) for any supported input, or (0,0,0)."""
    try:
        wav = decode_audio_to_wav(data)
        wi = wav_info(wav)
        if wi:
            fr, ch, nf = wi
            return fr, ch, (round(nf / float(fr), 2) if fr else 0)
    except Exception:
        pass
    return 0, 0, 0


def wav_to_pcm16(wav_bytes, target_freq, target_chans):
    """Decode an audio file, match channel count + sample rate, return PCM16 bytes.

    Accepts plain PCM WAV directly; anything else (MP3/OGG/FLAC/M4A/AIFF/...) is
    decoded with the bundled FMOD engine first. No external tools needed.
    """
    if np is None:
        raise RuntimeError("numpy is required to import audio")
    if not _is_wav(wav_bytes):
        wav_bytes = decode_audio_to_wav(wav_bytes)     # mp3/ogg/flac/... -> WAV
    bio = io.BytesIO(wav_bytes)
    try:
        w = wave.open(bio, "rb")
    except Exception:
        raise ValueError("Could not read the decoded audio. Try a WAV, MP3, OGG or FLAC.")
    nch = w.getnchannels()
    sw = w.getsampwidth()
    fr = w.getframerate()
    nframes = w.getnframes()
    raw = w.readframes(nframes)
    comp = w.getcomptype()
    w.close()
    if comp not in ("NONE", "not compressed"):
        raise ValueError("Compressed WAV not supported. Export as PCM .wav.")

    # -> float32 in [-1, 1], shape (frames, channels)
    if sw == 2:
        a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    elif sw == 1:
        a = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    elif sw == 3:
        b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        v = (b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16))
        v = np.where(v & 0x800000, v - 0x1000000, v)
        a = v.astype(np.float32) / 8388608.0
    elif sw == 4:
        # could be int32 or float32; WAV float uses format tag 3, but `wave`
        # doesn't expose it. Heuristic: floats live in [-1.5,1.5].
        i32 = np.frombuffer(raw, dtype="<i4")
        f32 = np.frombuffer(raw, dtype="<f4")
        a = f32.astype(np.float32) if np.max(np.abs(f32)) <= 1.5 else i32.astype(np.float32) / 2147483648.0
    else:
        raise ValueError("Unsupported WAV bit depth (%d-bit)." % (sw * 8))

    if nch > 1:
        a = a.reshape(-1, nch)
    else:
        a = a.reshape(-1, 1)

    # match channel count
    if a.shape[1] != target_chans:
        if target_chans == 1:
            a = a.mean(axis=1, keepdims=True)
        elif target_chans == 2 and a.shape[1] == 1:
            a = np.repeat(a, 2, axis=1)
        else:
            cols = [a[:, min(c, a.shape[1] - 1)] for c in range(target_chans)]
            a = np.stack(cols, axis=1)

    # resample to the slot's native rate (linear; fine for SFX)
    if fr != target_freq and a.shape[0] > 1:
        n_out = max(1, int(round(a.shape[0] * target_freq / float(fr))))
        xi = np.linspace(0.0, a.shape[0] - 1.0, n_out)
        x0 = np.arange(a.shape[0])
        a = np.stack([np.interp(xi, x0, a[:, c]) for c in range(a.shape[1])], axis=1)

    a = np.clip(a, -1.0, 1.0)
    pcm = (a * 32767.0).astype("<i2")
    return pcm.tobytes()


def wav_to_pcm16_keep(data, slot_freq, slot_chans, keep_chans=True,
                      keep_rate=True, max_chans=2):
    """Like wav_to_pcm16 but PRESERVES the source's own channels (up to
    max_chans) and rate instead of folding to the slot's format -- so a wide
    stereo gunshot stays stereo in-game rather than being mono-folded flat.

    Rate is only kept when it maps to an FSB5 frequency enum (so the header can
    represent it without adding a chunk); otherwise it falls back to the slot
    rate. Returns (pcm16_bytes, freq_hz, chans) at the chosen format.
    """
    sf, sc, _ = audio_info(data)
    chans = min(int(sc), max_chans) if (keep_chans and sc) else slot_chans
    chans = chans or slot_chans
    if keep_rate and sf and sf in FREQ_REVERSE:
        freq = int(sf)
    else:
        freq = slot_freq
    # bit-exact passthrough when the source is already PCM16 at the chosen format
    # (the common case: a 16-bit WAV kept at its own rate/channels) -> truly lossless
    if _is_wav(data):
        try:
            w = wave.open(io.BytesIO(data), "rb")
            if (w.getsampwidth() == 2 and w.getframerate() == freq
                    and w.getnchannels() == chans
                    and w.getcomptype() in ("NONE", "not compressed")):
                raw = w.readframes(w.getnframes())
                w.close()
                return raw, freq, chans
            w.close()
        except Exception:
            pass
    pcm = wav_to_pcm16(data, freq, chans)
    return pcm, freq, chans


def apply_dsp_wav(wav_bytes, pitch_semitones=0.0, bright_db=0.0):
    """Return a PCM16 WAV of `wav_bytes` with optional tweaks, keeping the
    source's own rate + channels:
      * pitch_semitones -- varispeed pitch shift (resample): +12 = one octave up
        and a touch shorter, -12 = down and a touch longer. Varispeed keeps a
        gunshot's transient crisp (a phase-vocoder would smear it) and is what
        "change the pitch" means for a one-shot SFX.
      * bright_db -- zero-phase high-shelf treble tilt hinged ~2.5-4.5 kHz;
        + adds high end (de-muffle), - darkens.
    No-op (returns the input untouched) when both are ~0 or numpy is missing."""
    try:
        p = float(pitch_semitones or 0.0)
        bdb = float(bright_db or 0.0)
    except Exception:
        return wav_bytes
    if abs(p) < 1e-3 and abs(bdb) < 1e-3:
        return wav_bytes
    if np is None:
        return wav_bytes
    if not _is_wav(wav_bytes):
        wav_bytes = decode_audio_to_wav(wav_bytes)
    w = wave.open(io.BytesIO(wav_bytes), "rb")
    nch, fr = max(1, w.getnchannels()), (w.getframerate() or 48000)
    w.close()
    # normalize to 16-bit at the source's OWN rate/channels (no resample here)
    pcm16 = wav_to_pcm16(wav_bytes, fr, nch)
    a = (np.frombuffer(pcm16, dtype="<i2").astype(np.float32) / 32768.0).reshape(-1, nch)
    if abs(p) >= 1e-3 and a.shape[0] > 1:
        ratio = 2.0 ** (p / 12.0)                       # >1 => higher pitch
        n_out = max(1, int(round(a.shape[0] / ratio)))
        xi = np.linspace(0.0, a.shape[0] - 1.0, n_out)
        x0 = np.arange(a.shape[0])
        a = np.stack([np.interp(xi, x0, a[:, c]) for c in range(a.shape[1])], axis=1)
    if abs(bdb) >= 1e-3 and a.shape[0] > 1:
        g = 10.0 ** (bdb / 20.0)
        n = a.shape[0]
        fq = np.fft.rfftfreq(n, 1.0 / fr)
        t = np.clip((fq - 2500.0) / 2000.0, 0.0, 1.0)   # 1.0 below 2.5k -> g above 4.5k
        curve = (1.0 + (g - 1.0) * t).astype(np.float32)
        a = np.stack([np.fft.irfft(np.fft.rfft(a[:, c]) * curve, n=n)
                      for c in range(a.shape[1])], axis=1)
    a = np.clip(a, -1.0, 1.0)
    pcm = (a * 32767.0).astype("<i2").tobytes()
    return pcm16_to_wav(pcm, fr, nch)


# ---- rebuild ----------------------------------------------------------------
def _align32(b):
    pad = (-len(b)) % 32
    return b + (b"\x00" * pad)


def _rebuild_transcode_fadpcm(bank, replacements, out_path, progress=None):
    """Rebuild the whole bank re-encoded to FADPCM. Used to compress the big
    PCM16 weapons bank (~112 MB) down to ~1/3 the size. Every sample is encoded
    to FADPCM (changed ones from the new audio, the rest from the original PCM),
    the FSB5 mode is switched to FADPCM, and offsets/sizes are reflowed.

    progress(done, total): optional callback invoked after each sample encodes."""
    if fadpcm is None:
        raise RuntimeError("FADPCM codec module unavailable in this build")
    fsb = bank.fsb
    buf = bytearray(bank.buf)
    new_data = bytearray()
    new_offsets = []
    new_nsamp = {}
    n = len(fsb.samples)
    new_fmt = {}
    for i, s in enumerate(fsb.samples):
        new_offsets.append(len(new_data))
        rchans = s.chans
        if s.idx in replacements:
            rep = replacements[s.idx]
            if isinstance(rep, dict):
                pcm = bytes(rep["pcm"])
                rchans = int(rep.get("chans") or s.chans)
                new_fmt[s.idx] = (int(rep.get("freq") or s.freq), rchans)
            else:
                pcm = bytes(rep)
            nsamp = len(pcm) // (2 * rchans)
        else:
            pcm = fsb.sample_audio(s.idx)               # original PCM16 audio
            nsamp = s.nsamp
        new_data += _align32(fadpcm.encode(pcm, rchans))
        new_nsamp[s.idx] = nsamp
        if progress:
            try:
                progress(i + 1, n)
            except Exception:
                pass
    new_data_size = len(new_data)

    struct.pack_into("<I", buf, fsb.base + 24, 16)       # FSB5 mode -> FADPCM
    struct.pack_into("<I", buf, fsb.base + 20, new_data_size)   # dataSize
    for i, s in enumerate(fsb.samples):
        v = struct.unpack_from("<Q", buf, s.hdr_pos)[0]
        m = _unpack_mode(v)
        freq_enum = m["freq"]
        chans = s.chans
        if s.idx in new_fmt:
            hz, ch = new_fmt[s.idx]
            chans = ch
            if s.freq_chunk is not None:
                struct.pack_into("<I", buf, s.freq_chunk, hz)
            else:
                freq_enum = FREQ_REVERSE.get(hz, m["freq"])
            if s.chans_chunk is not None:
                buf[s.chans_chunk] = ch & 0xFF
        nv = _pack_mode(m["next"], freq_enum, chans,
                        new_offsets[i] // 32, new_nsamp[s.idx])
        struct.pack_into("<Q", buf, s.hdr_pos, nv)

    delta = new_data_size - fsb.data_size
    snd_pos, snd_size, _, _ = bank.fsb_snd
    struct.pack_into("<I", buf, snd_pos + 4, snd_size + delta)
    struct.pack_into("<I", buf, 4, bank.riff_size + delta)
    out = (bytes(buf[:fsb.data_start]) + bytes(new_data)
           + bytes(buf[fsb.data_start + fsb.data_size:]))
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(out)
    return {"ok": True, "out": out_path, "replaced": sorted(replacements.keys()),
            "delta_bytes": delta, "size": len(out), "compressed": True,
            "codec": "FADPCM"}


def rebuild_bank(bank, replacements, out_path, compress=False, progress=None):
    """Splice new samples into the bank's main FSB5 and write out_path.

    replacements: {index: pcm16_bytes}  (already at the slot's freq/channels).
    compress: for a PCM16 (weapons) bank, re-encode the WHOLE bank to FADPCM so
    the file drops to ~1/3 the size (slightly lossy, like the music banks).
    progress(done, total): optional callback (used by the compress path).

    Returns a dict describing what changed.
    """
    fsb = bank.fsb
    if fsb is None:
        raise RuntimeError("no FSB5 audio blob found in this bank")
    if fsb.codec not in REBUILDABLE_CODECS:
        raise RuntimeError(
            "This bank is %s. Rebuilding is supported for PCM16 (weapons) and "
            "FADPCM (music / hub / env / etc.) banks." % fsb.codec)
    if fsb.codec == "FADPCM" and fadpcm is None:
        raise RuntimeError("FADPCM codec module unavailable in this build")
    if compress and fsb.codec == "PCM16":
        return _rebuild_transcode_fadpcm(bank, replacements, out_path, progress)

    buf = bytearray(bank.buf)

    # 1) build the new data section + record new offsets/lengths.
    #    kept samples reuse their exact original stored bytes (so an empty
    #    replacement reproduces the file byte-for-byte). A replacement that fits
    #    inside the original slot is padded up to the slot size => zero reflow,
    #    every other sample stays exactly where it was. Only a larger sample
    #    grows the section and shifts the ones after it.
    new_data = bytearray()
    new_offsets = []          # byte offset of each sample in the new data section
    new_nsamp = {}
    new_fmt = {}              # idx -> (freq_hz, chans) when a replacement keeps its own format
    for s in fsb.samples:
        new_offsets.append(len(new_data))
        if s.idx in replacements:
            rep = replacements[s.idx]
            # a replacement is either raw PCM16 at the slot's format (bytes), or a
            # dict {"pcm", "freq", "chans"} that keeps the source's own format.
            if isinstance(rep, dict):
                pcm = bytes(rep["pcm"])
                rchans = int(rep.get("chans") or s.chans)
                rfreq = int(rep.get("freq") or s.freq)
                new_fmt[s.idx] = (rfreq, rchans)
            else:
                pcm = bytes(rep)
                rchans = s.chans
            nsamp = len(pcm) // (2 * rchans)
            if fsb.codec == "FADPCM":
                audio = fadpcm.encode(pcm, rchans)   # re-encode to the game's codec
            else:
                audio = pcm                          # PCM16 -> store as-is
            stored = _align32(audio)
            if len(stored) < s.datalen:              # fits -> keep the slot size
                stored = stored + b"\x00" * (s.datalen - len(stored))
            new_data += stored
            new_nsamp[s.idx] = nsamp
        else:
            new_data += fsb.sample_bytes(s.idx)      # exact original slot
    new_data_size = len(new_data)

    # 2) rewrite each sample header (offset for all; nsamp + loop clamp for edited)
    for i, s in enumerate(fsb.samples):
        v = struct.unpack_from("<Q", buf, s.hdr_pos)[0]
        m = _unpack_mode(v)
        nsamp = new_nsamp.get(s.idx, m["nsamp"])
        freq_enum = m["freq"]
        chans = s.chans
        if s.idx in new_fmt:                          # replacement kept its own format
            hz, ch = new_fmt[s.idx]
            chans = ch
            if s.freq_chunk is not None:              # a FREQUENCY chunk rules -> patch it
                struct.pack_into("<I", buf, s.freq_chunk, hz)
            else:
                freq_enum = FREQ_REVERSE.get(hz, m["freq"])
            if s.chans_chunk is not None:             # a CHANNELS chunk rules -> patch it
                buf[s.chans_chunk] = ch & 0xFF
        nv = _pack_mode(m["next"], freq_enum, chans, new_offsets[i] // 32, nsamp)
        struct.pack_into("<Q", buf, s.hdr_pos, nv)
        # keep any loop inside the new length so a shorter replacement can't glitch
        if s.idx in replacements and s.loop:
            cpos, ls, le = s.loop
            ls2 = min(ls, max(0, nsamp - 1))
            le2 = min(le, max(0, nsamp - 1))
            struct.pack_into("<II", buf, cpos, ls2, le2)

    # 3) patch the FSB5 dataSize, then the SND chunk size, then the RIFF size
    delta = new_data_size - fsb.data_size
    struct.pack_into("<I", buf, fsb.base + 20, new_data_size)     # FSB5.dataSize
    snd_pos, snd_size, snd_body, snd_body_end = bank.fsb_snd
    struct.pack_into("<I", buf, snd_pos + 4, snd_size + delta)    # SND chunk size
    struct.pack_into("<I", buf, 4, bank.riff_size + delta)        # RIFF size

    # 4) reassemble: [everything up to the FSB5 data] + new data + [tail after old data]
    old_data_abs = fsb.data_start
    old_tail_start = fsb.data_start + fsb.data_size               # 2nd SND etc.
    out = bytes(buf[:old_data_abs]) + bytes(new_data) + bytes(buf[old_tail_start:])

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(out)

    return {
        "ok": True,
        "out": out_path,
        "replaced": sorted(replacements.keys()),
        "delta_bytes": delta,
        "size": len(out),
    }


# ---- FMOD-engine decode (non-PCM banks, preview only) ----------------------
def _fmod_subsound_wav(bank, index):
    """Decode one subsound of a non-PCM FSB5 (FADPCM/Vorbis/...) to WAV bytes via
    the real FMOD engine (the same pyfmodex path UnityPy uses). Preview-only;
    returns None if FMOD isn't available in this build.
    """
    try:
        import fmod_toolkit
        from fmod_toolkit.importer import import_pyfmodex
        pf = import_pyfmodex()
    except Exception:
        return None
    fsb = bank.fsb
    s = fsb.samples[index]
    blob = bytes(bank.buf[fsb.base:fsb.end])
    try:
        system, lock = fmod_toolkit.get_pyfmodex_system_instance(
            max(1, s.chans), pf.flags.INIT_FLAGS.NORMAL)
        with lock:
            sound = system.create_sound(
                blob, pf.flags.MODE.OPENMEMORY,
                exinfo=pf.structure_declarations.CREATESOUNDEXINFO(
                    length=len(blob),
                    numchannels=max(1, s.chans),
                    defaultfrequency=s.freq or 48000,
                ),
            )
            try:
                ss = sound.get_subsound(index)
                wav = fmod_toolkit.subsound_to_wav(ss)
            finally:
                sound.release()
        return wav
    except Exception:
        return None


# ---- discovery --------------------------------------------------------------
def find_streaming_assets(extra=None):
    """Return the game's StreamingAssets dir, or None. Checks the explicit override
    first, then the Meta and Steam install locations."""
    for c in [extra, GAME_SA, GAME_SA_STEAM]:
        if c and os.path.isdir(c):
            return c
    return None


def list_banks(sa_dir):
    """List every *.assets.bank (the ones holding audio) with a description."""
    out = []
    if not sa_dir or not os.path.isdir(sa_dir):
        return out
    for fn in sorted(os.listdir(sa_dir)):
        if not fn.endswith(".assets.bank"):
            continue
        base = fn[:-len(".assets.bank")]
        p = os.path.join(sa_dir, fn)
        if base in BANK_GUIDE:
            desc = BANK_GUIDE[base]
        elif base.startswith("VO_"):
            desc = "Voice-over / callouts (%s)" % base[3:]
        else:
            desc = "Sound bank"
        out.append({
            "file": fn,
            "base": base,
            "size": os.path.getsize(p),
            "desc": desc,
            "is_weapons": (base == "Item"),
        })
    return out


# ---- self-test (round-trip identity) ---------------------------------------
def _revalidate(out_path, expect_samples):
    """Re-parse a written bank and assert its invariants hold."""
    b = Bank(out_path)
    assert b.fsb is not None, "no FSB5 after rebuild"
    assert b.fsb.num == expect_samples, "sample count changed"
    # RIFF/SND/dataSize consistency
    assert b.riff_size + 8 == len(b.buf), "RIFF size wrong"
    snd_pos, snd_size, snd_body, snd_body_end = b.fsb_snd
    assert snd_body + snd_size == snd_body_end
    # offsets strictly non-decreasing, all 32-aligned, last within dataSize
    prev = -1
    for s in b.fsb.samples:
        assert s.offset % 32 == 0, "offset not 32-aligned"
        assert s.offset >= prev, "offsets not monotonic"
        prev = s.offset
    last = b.fsb.samples[-1]
    assert last.offset + last.datalen == b.fsb.data_size, "dataSize mismatch"
    return b


def _selftest():
    import tempfile
    p = os.path.join(GAME_SA, "Item.assets.bank")
    if not os.path.exists(p):
        print("Item.assets.bank not found; skipping"); return
    b = Bank(p)
    print("codec=%s samples=%d dataSize=%d" % (b.codec(), b.fsb.num, b.fsb.data_size))
    tmp = tempfile.mkdtemp()

    # (1) empty replacement -> must reproduce the file byte-for-byte
    out1 = os.path.join(tmp, "identity.bank")
    rebuild_bank(b, {}, out1)
    a = open(p, "rb").read(); c = open(out1, "rb").read()
    ident = (a == c)
    print("[1] empty-replacement identity:", ident, "(%d vs %d bytes)" % (len(a), len(c)))
    if not ident:
        for i in range(min(len(a), len(c))):
            if a[i] != c[i]:
                print("    first diff at", i); break

    # (2) shorter replacement (fits in slot) -> zero reflow, same file size
    idx = 3
    s = b.fsb.samples[idx]
    short = b"\x00\x00" * (100 * s.chans)                  # 100 frames of silence
    out2 = os.path.join(tmp, "short.bank")
    r2 = rebuild_bank(b, {idx: short}, out2)
    b2 = _revalidate(out2, b.fsb.num)
    print("[2] short replace idx=%d: delta=%d size=%d (fits->delta 0?) new_nsamp=%d"
          % (idx, r2["delta_bytes"], r2["size"], b2.fsb.samples[idx].nsamp))
    # every OTHER sample must be byte-identical to the original
    others_ok = all(b2.fsb.sample_bytes(j) == b.fsb.sample_bytes(j)
                    for j in range(b.fsb.num) if j != idx)
    print("    other samples untouched:", others_ok)

    # (3) longer replacement (grows) -> reflow, re-parse must round-trip the audio
    big_frames = s.nsamp + 5000
    big = (b"\x11\x22" * (big_frames * s.chans))
    out3 = os.path.join(tmp, "big.bank")
    r3 = rebuild_bank(b, {idx: big}, out3)
    b3 = _revalidate(out3, b.fsb.num)
    got = b3.fsb.sample_audio(idx)
    print("[3] grow replace idx=%d: delta=%d nsamp %d->%d audio_roundtrip=%s"
          % (idx, r3["delta_bytes"], s.nsamp, b3.fsb.samples[idx].nsamp, got == big))

    # (4) WAV import path: extract sample -> wav -> back to pcm16 -> lengths sane
    if np is not None:
        wav = sample_to_wav(b, 0)
        pcm = wav_to_pcm16(wav, b.fsb.samples[0].freq, b.fsb.samples[0].chans)
        print("[4] wav import round-trip bytes:", len(pcm),
              "== original audio", len(b.fsb.sample_audio(0)),
              "->", len(pcm) == len(b.fsb.sample_audio(0)))

    import shutil
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        sa = find_streaming_assets()
        print("StreamingAssets:", sa)
        for bk in list_banks(sa):
            print("  %-22s %10d  %s" % (bk["file"], bk["size"], bk["desc"]))
