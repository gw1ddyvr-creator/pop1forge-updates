#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inject_mesh.py  --  POP:1 weapon mesh injector (milestone 1)

Reads a rigid weapon mesh, and can either verify a lossless round-trip, repack
it unchanged, or add a small test spike -- then re-serialises the bundle with
UnityPy (lz4/lz4hc so there's no in-game draw hitch).

SAFETY: it NEVER overwrites the source bundle. Output goes to a new file
"<name>__MODDED.bundle" next to it. And before it ever writes geometry, it runs
a BYTE-EXACT self-check: it decodes the real mesh, re-packs it, and confirms the
bytes match the original. If they don't, it aborts -- so a format mismatch can
never ship a corrupt mesh.

MODES (run in this order the first time):
    python inject_mesh.py --check  "weapon.bundle"   # self-check only, writes nothing
    python inject_mesh.py --noop   "weapon.bundle"   # repack UNCHANGED -> test it loads
    python inject_mesh.py --spike  "weapon.bundle"   # add a visible test spike

Drag-drop: dragging a bundle onto inject_mesh.bat runs --check first.
Needs:  pip install UnityPy
"""

import os
import sys
import json
import struct
import traceback

# ---- vertex format (derived from the mesh, but these are the AKM defaults) ----
FMT_SIZE = {0: 4, 1: 2, 2: 1, 3: 1, 4: 2, 5: 2, 6: 1, 7: 2, 8: 4, 9: 1, 10: 2, 11: 4}
FMT_STRUCT = {0: "f", 1: "e"}          # only float32 / float16 supported for now
CHANNEL_NAME = {0: "Position", 1: "Normal", 2: "Tangent", 3: "Color", 4: "UV0",
                5: "UV1", 6: "UV2", 7: "UV3", 12: "BlendWeight", 13: "BlendIndices"}


def log(msg, tag=""):
    print(("  " if tag != "hdr" else "") + msg)


def align(n, a=16):
    return (n + a - 1) // a * a


def get(d, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and k in d and d[k] is not None:
            return d[k]
    return default


# ---------------------------------------------------------------- UnityPy glue
def find_EBR():
    for modpath in ("UnityPy.streams", "UnityPy.streams.EndianBinaryReader",
                    "UnityPy.helpers.EndianBinaryReader"):
        try:
            mod = __import__(modpath, fromlist=["EndianBinaryReader"])
            return getattr(mod, "EndianBinaryReader")
        except Exception:
            continue
    return None


def raw_bytes(f):
    if f is None:
        return None
    if isinstance(f, (bytes, bytearray, memoryview)):
        return bytes(f)
    v = getattr(f, "bytes", None)
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    if hasattr(f, "read") and hasattr(f, "Length"):
        try:
            pos = getattr(f, "Position", 0); f.Position = 0
            d = f.read(f.Length); f.Position = pos
            return bytes(d)
        except Exception:
            pass
    st = getattr(f, "stream", None)
    if st is not None:
        try:
            p = st.tell(); st.seek(0); d = st.read(); st.seek(p)
            if d:
                return bytes(d)
        except Exception:
            pass
    try:
        return bytes(f)
    except Exception:
        return None


def find_resS_key(env, obj, resS_name):
    target = os.path.basename(resS_name or "")
    holders = []
    sf = getattr(obj, "assets_file", None)
    for h in (getattr(sf, "parent", None), getattr(env, "file", None)):
        if h is not None:
            holders.append(h)
    holders.extend(list(getattr(env, "files", {}).values()))
    for h in holders:
        files = getattr(h, "files", None)
        if isinstance(files, dict):
            # exact match first, then any .resS
            for name in files:
                if os.path.basename(name) == target:
                    return files, name
            for name in files:
                if os.path.basename(name).lower().endswith(".ress"):
                    return files, name
    return None, None


# ------------------------------------------------------------- mesh read/write
def derive_layout(channels):
    """Build [(name,fmt,offset,dim,stream)] and per-stream strides from channels."""
    layout, strides = [], {}
    for i, c in enumerate(channels or []):
        dim = (get(c, "dimension") or 0) & 0x0F
        if not dim:
            continue
        fmt = get(c, "format") or 0
        if fmt not in FMT_STRUCT:
            raise RuntimeError("channel %s uses format %d (not float32/16); "
                               "this weapon needs a wider decoder." % (CHANNEL_NAME.get(i, i), fmt))
        stream = get(c, "stream") or 0
        offset = get(c, "offset") or 0
        layout.append((CHANNEL_NAME.get(i, "ch%d" % i), fmt, offset, dim, stream))
        strides[stream] = max(strides.get(stream, 0), offset + dim * FMT_SIZE[fmt])
    return layout, strides


def stream_offsets(strides, vcount):
    off, cur = {}, 0
    for s in sorted(strides):
        off[s] = cur
        cur = align(cur + strides[s] * vcount, 16)
    return off


def decode_vertices(vbuf, layout, strides, vcount):
    off = stream_offsets(strides, vcount)
    verts = []
    for i in range(vcount):
        v = {}
        for name, fmt, offset, dim, st in layout:
            base = off[st] + i * strides[st] + offset
            v[name] = list(struct.unpack_from("<%d%s" % (dim, FMT_STRUCT[fmt]), vbuf, base))
        verts.append(v)
    return verts, off


def pack_vertices(verts, layout, strides):
    n = len(verts)
    off = stream_offsets(strides, n)
    total = (off[max(strides)] + strides[max(strides)] * n) if strides else 0
    buf = bytearray(total)
    for i, v in enumerate(verts):
        for name, fmt, offset, dim, st in layout:
            base = off[st] + i * strides[st] + offset
            struct.pack_into("<%d%s" % (dim, FMT_STRUCT[fmt]), buf, base, *v[name])
    return bytes(buf), off


def decode_indices(ib_bytes, count):
    return list(struct.unpack_from("<%dH" % count, ib_bytes, 0))


def pack_indices(indices):
    return struct.pack("<%dH" % len(indices), *indices)


def compute_aabb(verts):
    xs = [v["Position"][0] for v in verts]
    ys = [v["Position"][1] for v in verts]
    zs = [v["Position"][2] for v in verts]
    ctr = {"x": (min(xs) + max(xs)) / 2, "y": (min(ys) + max(ys)) / 2, "z": (min(zs) + max(zs)) / 2}
    ext = {"x": (max(xs) - min(xs)) / 2, "y": (max(ys) - min(ys)) / 2, "z": (max(zs) - min(zs)) / 2}
    return ctr, ext


def read_mesh(path):
    import UnityPy
    env = UnityPy.load(path)
    meshes = [o for o in env.objects if getattr(o.type, "name", "") == "Mesh"]
    if not meshes:
        raise RuntimeError("no Mesh object in that bundle")
    obj = meshes[0]
    tt = obj.read_typetree()
    vd = get(tt, "m_VertexData", default={}) or {}
    vcount = get(vd, "m_VertexCount", default=0)
    layout, strides = derive_layout(get(vd, "m_Channels", default=[]))

    sd = get(tt, "m_StreamData", default={}) or {}
    sd_off, sd_size, sd_path = get(sd, "offset", default=0), get(sd, "size", default=0), get(sd, "path", default="")
    files, resS_key = find_resS_key(env, obj, sd_path)
    resS = raw_bytes(files[resS_key]) if resS_key is not None else b""
    # A prior edit may have INLINED the vertex data into m_VertexData.m_DataSize
    # and blanked m_StreamData (the old .resS is left in place but no longer used).
    # Read the inline buffer in that case; otherwise read the .resS at sd_off/size.
    vd_data = get(vd, "m_DataSize", default=None)
    if isinstance(vd_data, (bytes, bytearray)):
        inline = bytes(vd_data)
    elif isinstance(vd_data, list) and vd_data:
        inline = bytes(vd_data)
    else:
        inline = b""
    if inline and not (sd_path and sd_size):
        vbuf = inline
    else:
        if not resS:
            raise RuntimeError("could not locate/read the .resS inside the bundle")
        vbuf = resS[sd_off:sd_off + sd_size] if sd_size else resS

    verts, voff = decode_vertices(vbuf, layout, strides, vcount)

    ib = get(tt, "m_IndexBuffer")
    if isinstance(ib, list):
        ib = bytes(ib)
    total_idx = len(ib) // 2
    indices = decode_indices(ib, total_idx)

    return {"env": env, "obj": obj, "tree": tt, "files": files, "resS_key": resS_key,
            "resS": resS, "vbuf": vbuf, "sd_off": sd_off, "sd_size": sd_size,
            "layout": layout, "strides": strides, "voff": voff,
            "verts": verts, "indices": indices, "vcount": vcount}


def self_check(m):
    """Re-pack the decoded mesh and confirm it matches the original, byte for byte."""
    rebuilt, _ = pack_vertices(m["verts"], m["layout"], m["strides"])
    orig = m["vbuf"]
    ok = True
    if len(rebuilt) != len(orig):
        log("SELF-CHECK FAIL: vertex buffer length %d vs original %d" % (len(rebuilt), len(orig)))
        return False
    if rebuilt != orig:
        # tolerate differences ONLY in the inter-stream alignment padding
        n = m["vcount"]
        pad_ranges = []
        cur = 0
        for s in sorted(m["strides"]):
            raw_end = cur + m["strides"][s] * n
            cur = align(raw_end, 16)
            if cur > raw_end:
                pad_ranges.append((raw_end, cur))
        bad = [i for i in range(len(orig)) if rebuilt[i] != orig[i]
               and not any(a <= i < b for a, b in pad_ranges)]
        if bad:
            log("SELF-CHECK FAIL: %d vertex byte(s) differ, first at offset %d" % (len(bad), bad[0]))
            ok = False
        else:
            log("self-check: vertex bytes match (only alignment padding differs -- fine)")
    else:
        log("self-check: vertex buffer is BYTE-EXACT")
    # indices
    if pack_indices(m["indices"]) != (bytes(m["tree"]["m_IndexBuffer"])
                                      if not isinstance(m["tree"]["m_IndexBuffer"], (bytes, bytearray))
                                      else bytes(m["tree"]["m_IndexBuffer"])):
        log("SELF-CHECK FAIL: index buffer round-trip mismatch"); ok = False
    else:
        log("self-check: index buffer is BYTE-EXACT")
    return ok


def compute_uv_world_scale(verts, indices):
    """World units per UV unit (median over triangle edges) so projected decals
    match the gun's texel density. Skips edges that cross a UV tile boundary."""
    import math
    ratios = []
    n = len(indices)
    step = max(3, (n // 3 // 800) * 3)   # sample up to ~800 triangles
    for t in range(0, n - 2, step):
        a, b = indices[t], indices[t + 1]
        pa, pb = verts[a]["Position"], verts[b]["Position"]
        ua, ub = verts[a]["UV0"], verts[b]["UV0"]
        if math.floor(ua[0]) != math.floor(ub[0]):   # different tile -> skip
            continue
        wl = ((pa[0]-pb[0])**2 + (pa[1]-pb[1])**2 + (pa[2]-pb[2])**2) ** 0.5
        ul = ((ua[0]-ub[0])**2 + (ua[1]-ub[1])**2) ** 0.5
        if ul > 1e-5 and wl > 1e-6:
            ratios.append(wl / ul)
    if not ratios:
        return 1.0
    ratios.sort()
    return ratios[len(ratios) // 2]


def make_spike(verts, indices, aabb_ctr, aabb_ext, uvscale=1.0):
    """Anchor a small stud to a real surface vertex and give each of its
    vertices a PROJECTED UV (seeded at the anchor's UV) so it shows the texture
    pattern flowing across it -- the same projection the Forge greebles use."""
    cx, cy, cz = aabb_ctr["x"], aabb_ctr["y"], aabb_ctr["z"]
    ex, ey, ez = aabb_ext["x"], aabb_ext["y"], aabb_ext["z"]
    existing = len(verts)
    tgt = (cx, cy + ey, cz)

    def d2(p):
        return (p[0]-tgt[0])**2 + (p[1]-tgt[1])**2 + (p[2]-tgt[2])**2
    a_i = min(range(existing), key=lambda i: d2(verts[i]["Position"]))
    P = verts[a_i]["Position"]
    N = verts[a_i]["Normal"][:3]
    nl = (N[0]**2+N[1]**2+N[2]**2) ** 0.5
    N = [N[0]/nl, N[1]/nl, N[2]/nl] if nl > 1e-6 else [0.0, 1.0, 0.0]

    def cross(u, v):
        return [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]

    def unit(v):
        l = (v[0]**2+v[1]**2+v[2]**2) ** 0.5 or 1.0
        return [v[0]/l, v[1]/l, v[2]/l]
    a = (1.0, 0.0, 0.0) if abs(N[0]) < 0.9 else (0.0, 1.0, 0.0)
    T = unit(cross(a, N)); B = unit(cross(N, T))
    s, h = 0.025, 0.06
    log("spike anchored at vertex %d pos=[%.3f,%.3f,%.3f] normal=[%.2f,%.2f,%.2f] uvscale=%.4f"
        % (a_i, P[0], P[1], P[2], N[0], N[1], N[2], uvscale))

    def pt(du, dv, dn):
        return (P[0]+T[0]*du+B[0]*dv+N[0]*dn, P[1]+T[1]*du+B[1]*dv+N[1]*dn, P[2]+T[2]*du+B[2]*dv+N[2]*dn)
    base = [pt(-s, -s, 0), pt(s, -s, 0), pt(s, s, 0), pt(-s, s, 0)]
    apex = pt(0, 0, h)
    tris = [(base[0], base[1], apex), (base[1], base[2], apex),
            (base[2], base[3], apex), (base[3], base[0], apex),
            (base[0], base[2], base[1]), (base[0], base[3], base[2])]

    a_uv0 = verts[a_i]["UV0"]; a_uv1 = verts[a_i]["UV1"]
    a_uv2 = verts[a_i]["UV2"]; a_uv3 = verts[a_i]["UV3"]
    scl = uvscale or 1.0

    def project_uv0(p):
        d = (p[0]-P[0], p[1]-P[1], p[2]-P[2])
        du = d[0]*T[0]+d[1]*T[1]+d[2]*T[2]
        dv = d[0]*B[0]+d[1]*B[1]+d[2]*B[2]
        return [a_uv0[0] + du/scl, a_uv0[1] + dv/scl, a_uv0[2], a_uv0[3]]

    def fnorm(x, y, z):
        return unit(cross([y[0]-x[0], y[1]-x[1], y[2]-x[2]], [z[0]-x[0], z[1]-x[1], z[2]-x[2]])) + [0.0]

    start = len(verts); added = 0
    for tri in tris:
        nrm = fnorm(*tri)
        for p in tri:
            verts.append({"Position": [p[0], p[1], p[2]], "Normal": nrm,
                          "Tangent": [1.0, 0.0, 0.0, -1.0], "UV0": project_uv0(p),
                          "UV1": list(a_uv1), "UV2": list(a_uv2), "UV3": list(a_uv3)})
        indices.extend([start+added, start+added+1, start+added+2])
        added += 3
    return len(tris)


def write_bundle(m, out_path):
    tree, obj = m["tree"], m["obj"]
    verts, indices = m["verts"], m["indices"]
    n = len(verts)

    new_vbuf, _ = pack_vertices(verts, m["layout"], m["strides"])
    new_ib = pack_indices(indices)
    ctr, ext = compute_aabb(verts)

    # INLINE the vertex data into the object and drop the external stream.
    # (Replacing the .resS file node trips a UnityPy save bug -- '.flags' -- so
    #  we move the bytes inline instead and never touch the .resS node.)
    tree["m_VertexData"]["m_VertexCount"] = n
    tree["m_VertexData"]["m_DataSize"] = new_vbuf
    tree["m_StreamData"] = {"offset": 0, "size": 0, "path": ""}
    tree["m_IndexBuffer"] = new_ib
    sub = tree["m_SubMeshes"][0]
    sub["indexCount"] = len(indices)
    sub["vertexCount"] = n
    sub["firstVertex"] = 0
    sub["baseVertex"] = 0
    if "localAABB" in sub:
        sub["localAABB"] = {"m_Center": ctr, "m_Extent": ext}
    tree["m_LocalAABB"] = {"m_Center": ctr, "m_Extent": ext}

    try:
        obj.save_typetree(tree)
    except Exception as e:
        raise RuntimeError("save_typetree failed: %s" % e)

    bundle = getattr(m["env"], "file", None)

    # --- workaround for the UnityPy save bug on this bundle/version ---
    # bundle.save() reads .flags on every inner file node, but the resource
    # (.resS) reader is a memoryview reader that lacks it. Give the flagless
    # ones flags=0 (raw resource) so the serializer writes them as-is.
    patched = 0
    for name, f in list(getattr(bundle, "files", {}).items()):
        if not hasattr(f, "flags"):
            try:
                f.flags = 0
                patched += 1
            except Exception:
                pass
    if patched:
        log("save-fix: set flags on %d resource node(s)" % patched)

    data, last = None, None
    for kw in ({"packer": "original"}, {"packer": "lz4"}, {}, {"packer": "none"}):
        try:
            data = bundle.save(**kw)
            if data:
                log("repack: UnityPy re-serialise (packer=%s)" % kw.get("packer", "default"))
                break
        except Exception as e:
            last = e
    if not data:
        # dump what UnityPy's objects look like so the save path can be fixed precisely
        log("bundle.save still failing. Diagnostics:")
        try:
            import UnityPy
            log("  UnityPy version: %s" % getattr(UnityPy, "__version__", "?"))
        except Exception:
            pass
        log("  bundle type: %s" % type(bundle).__name__)
        battrs = [a for a in dir(bundle) if any(k in a.lower() for k in ("dir", "node", "file", "flag", "block", "save"))]
        log("  bundle attrs: %s" % ", ".join(battrs))
        for name, f in list(getattr(bundle, "files", {}).items())[:6]:
            log("    file %r -> %s  hasflags=%s" % (os.path.basename(name), type(f).__name__, hasattr(f, "flags")))
        raise RuntimeError("bundle.save failed for every packer. Last: %r" % last)
    with open(out_path, "wb") as f:
        f.write(data)
    log("wrote %s (%d bytes, vertex data inlined)" % (os.path.basename(out_path), len(data)))


def process(path, mode):
    log("reading %s" % os.path.basename(path), "hdr")
    m = read_mesh(path)
    log("mesh: %d verts, %d indices, strides=%s" % (m["vcount"], len(m["indices"]), m["strides"]))

    if not self_check(m):
        log("ABORT: the mesh did not round-trip byte-exactly, so I won't write anything.")
        log("Send me the console output above and I'll fix the decoder.")
        return False
    log("self-check PASSED -- read/repack is byte-exact on the real data.")

    if mode == "check":
        log("check-only mode: nothing written. Re-run with --noop to test repacking.")
        return True

    stem = os.path.splitext(path)[0]
    out_path = stem + "__MODDED.bundle"

    if mode == "spike":
        ctr, ext = compute_aabb(m["verts"])
        uvscale = compute_uv_world_scale(m["verts"], m["indices"])
        ntri = make_spike(m["verts"], m["indices"], ctr, ext, uvscale)
        log("added a test spike: +%d tris, +%d verts (now %d verts, %d tris)"
            % (ntri, len(m["verts"]) - m["vcount"], len(m["verts"]), len(m["indices"]) // 3))

    write_bundle(m, out_path)
    log("DONE. Copy %s into the game (as the original's replacement) and check it loads."
        % os.path.basename(out_path))
    return True


def main(argv):
    mode = "check"
    for a in list(argv):
        if a == "--noop":
            mode = "noop"; argv.remove(a)
        elif a == "--spike":
            mode = "spike"; argv.remove(a)
        elif a == "--check":
            mode = "check"; argv.remove(a)
    paths = [a for a in argv[1:] if not a.startswith("--")]
    if not paths:
        print(__doc__)
        try:
            e = input("Drag the LOD0 bundle here, then Enter: ").strip().strip('"').strip("'")
        except EOFError:
            e = ""
        if e:
            paths = [e]
        else:
            return 1
    try:
        import UnityPy  # noqa
    except ImportError:
        print("UnityPy is not installed. Run:  pip install UnityPy"); return 2
    ok = True
    for p in paths:
        if not os.path.isfile(p):
            print("!! not found:", p); ok = False; continue
        try:
            process(p, mode)
        except Exception:
            print("!! error on %s:\n%s" % (p, traceback.format_exc())); ok = False
    return 0 if ok else 3


if __name__ == "__main__":
    code = 1
    try:
        code = main(sys.argv)
    except Exception:
        print("\n!! Unexpected error:\n"); traceback.print_exc(); code = 4
    try:
        input("\nPress Enter to close this window...")
    except Exception:
        pass
    sys.exit(code)
