#!/usr/bin/env python3
# =============================================================================
#  SKIN SWAPPER  (portable build)
#  by GW1DDY  -  Copyright (c) 2026 GW1DDY. All rights reserved.
#
#  Builds the patched .resS for a Texture2DArray swap from two PNGs.
#     PNGs -> texconv -> build (diff=0) -> inject into a clean .resS
#  Output: a patched .resS ready to Import in UABEA.
#
#  Self-contained: no fixed install folder. It remembers where texconv.exe
#  and your clean .resS live (Settings panel), and auto-detects them if they
#  sit next to the app or are bundled into the .exe at build time.
#
#  Run as a script:   python skin_swapper.py
#  Build a .exe:       see build_exe.bat / README.txt
#  This software is the work of GW1DDY and is not for redistribution. See LICENSE.
# =============================================================================

import os, sys, json, struct, subprocess, tempfile, threading, traceback
import hashlib, platform, uuid
import urllib.request, urllib.error
import tkinter as tk
from tkinter import filedialog, messagebox

try:
    from PIL import Image, ImageTk        # for reference-texture preview/split/flip
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

APP_NAME = "SkinSwapper"
AUTHOR   = "GW1DDY"
YEAR     = "2026"
VERSION  = "3.7"

# >>> EDIT THIS: the email shown on the Contact window <<<
CONTACT_EMAIL = "REPLACE-WITH-YOUR-EMAIL@example.com"

# ---------------------------------------------------------------------------
# LICENSE KILL-SWITCH  +  UPDATE NOTICE
#   Leave LICENSE_URL = "" to DISABLE both (handy while testing).
#   To turn ON: host a small JSON file somewhere public and paste its URL.
#   That file (see keys.json) can look like:
#       {
#         "enabled": true,
#         "keys": ["KEY-ALICE-0001", "KEY-BOB-0002"],
#         "latest_version": "2.7",
#         "download_url": "https://your-link-to-the-new-folder-or-exe"
#       }
#   - Give each person their own key; the first-run window makes them enter it.
#   - To REVOKE someone: delete their key from that file.
#   - To kill EVERY copy at once: set "enabled": false.
#   - To announce an UPDATE: bump "latest_version" and set "download_url";
#     older copies show an "update available" notice with the link.
#   The block takes effect the next run (the app re-checks every START).
#   Needs internet at run time; if it can't verify, it refuses.
# ---------------------------------------------------------------------------
LICENSE_URL = "https://gist.githubusercontent.com/gw1ddyvr-creator/f637fcb738df6762a7d1356e9d616d91/raw/keys.json"

# Terms shown in the first-run gate and the Terms button.
TERMS = """SKIN SWAPPER - TERMS OF USE
Copyright (c) 2026 GW1DDY. All rights reserved.

By entering your access key and using this software, you agree to ALL of the
following terms:

1. AUTHORSHIP
   This software was created by GW1DDY. You may not claim authorship of it,
   nor remove, hide, or alter the "by GW1DDY" credit or these terms.

2. ACCESS IS PERSONAL
   Your access key is granted to YOU. It is not to be shared, given away,
   sold, or transferred to anyone else.

3. NO REDISTRIBUTION
   You may not share, upload, repost, sell, rent, sublicense, or otherwise
   distribute this software or its files - in whole or in part - to anyone
   without GW1DDY's prior written permission.

4. CONSEQUENCES
   If this software is distributed or shared without GW1DDY's permission,
   your access will be REVOKED - possibly permanently - and access may be
   revoked for everyone. Access is controlled by GW1DDY and may be withdrawn
   at any time, for any reason.

5. RISK & DISCLAIMER
   This software is provided "AS IS", with no warranty of any kind. GW1DDY is
   not responsible for any damage or loss arising from its use, including any
   effect on a game, file, software, hardware, or account.

   Modifying a game's files may violate that game's Terms of Service and could
   result in penalties up to and including an account ban. You use this
   software entirely at your own risk.

Entering your key confirms that you have read, understood, and AGREE to these
terms."""

# Default texture spec = CCC_1p_tarray (from the cheat sheet). Editable in the
# Settings panel and saved per-user, so MGE / NNN / new weapons need no code edit.
DEFAULT = {
    "texconv_path": "",
    "bundle_path": "",
    "clean_ress_path": "",
    "uabea_path": "",
    "out_dir": "",
    "license_key": "",
    "spec": {
        "name": "CCC_1p_tarray",
        "texconv_fmt": "BC3_UNORM_SRGB",   # m_Format 100
        "width": 2048,
        "height": 2048,
        "slices": 2,                       # m_Depth
        "per_slice": 5592432,              # m_DataSize / m_Depth
        "total": 11184864,                 # m_DataSize
        "stream_offset": 0,                # m_StreamData offset
        "ress_name": "CAB-f03855fbd0ad39146e1b57c984ff11d8.resS",
        "bundle_name": "awp_001_base_assets_pbr_firstperson.mat_31c1d7bf45fcd0a7d1cb359a79f473f1.bundle",
    },
}


# ----------------------------- paths / settings -----------------------------
def app_dir():
    if getattr(sys, "frozen", False):           # running as a PyInstaller .exe
        d = os.path.dirname(sys.executable)
        # A onefile build lands in <project>\dist\, but the working files
        # (Library, textures, owner.key, Billboards, ...) live in <project>\.
        # If we were launched from that 'dist' folder, use its parent so the exe
        # runs fine straight out of dist without being copied next to the files.
        parent = os.path.dirname(d)
        if os.path.basename(d).lower() == "dist" and os.path.isfile(os.path.join(parent, "owner.key")):
            return parent
        return d
    return os.path.dirname(os.path.abspath(__file__))


def bundled(name):
    """Find a file bundled into the .exe (--add-data) or sitting next to the app."""
    base = getattr(sys, "_MEIPASS", None)
    if base:
        p = os.path.join(base, name)
        if os.path.exists(p):
            return p
    p = os.path.join(app_dir(), name)
    return p if os.path.exists(p) else None


def settings_path():
    base = os.environ.get("APPDATA") if os.name == "nt" else os.path.expanduser("~")
    d = os.path.join(base or app_dir(), APP_NAME)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "settings.json")


def find_uabea(start):
    """Locate UABEAvalonia.exe next to the app or one folder deep."""
    cands = [os.path.join(start, "UABEAvalonia.exe"),
             os.path.join(start, "UABEA", "UABEAvalonia.exe")]
    for c in cands:
        if os.path.exists(c):
            return c
    try:
        for entry in os.listdir(start):
            sub = os.path.join(start, entry)
            if os.path.isdir(sub):
                p = os.path.join(sub, "UABEAvalonia.exe")
                if os.path.exists(p):
                    return p
    except Exception:
        pass
    return ""


def library_dir():
    return os.path.join(app_dir(), "Library")


def textures_dir():
    return os.path.join(app_dir(), "textures")


def reference_textures(name, spec):
    """Return (slice0_img, slice1_img) PIL Images for a weapon's reference
    texture from textures/<name>/. A stacked Texture2DArray (one tall image)
    is split top/bottom and each slice is vertically flipped to match the
    import slots. Either image may be None."""
    if not HAVE_PIL:
        return None, None
    folder = os.path.join(textures_dir(), name)
    if not os.path.isdir(folder):
        return None, None
    pngs = [os.path.join(folder, f) for f in sorted(os.listdir(folder))
            if f.lower().endswith(".png")]
    if not pngs:
        return None, None
    slices = int(spec.get("slices", 2) or 2)
    flip = lambda im: im.transpose(Image.FLIP_TOP_BOTTOM)

    # Two explicit slice files (slice0.png / slice1.png)?
    p0 = next((p for p in pngs if "slice0" in os.path.basename(p).lower()), None)
    p1 = next((p for p in pngs if "slice1" in os.path.basename(p).lower()), None)
    if p0:
        i0 = flip(Image.open(p0).convert("RGBA"))
        i1 = flip(Image.open(p1).convert("RGBA")) if p1 else None
        return i0, i1

    img = Image.open(pngs[0]).convert("RGBA")
    w, h = img.size
    if slices >= 2 and h >= int(w * 1.5):          # stacked: slice0 top, slice1 bottom
        half = h // 2
        top = flip(img.crop((0, 0, w, half)))
        bot = flip(img.crop((0, half, w, h)))
        return top, bot
    return flip(img), None                         # single-slice reference


def scan_library():
    """Return the names of the weapon/item subfolders inside Library/."""
    items = []
    try:
        for entry in sorted(os.listdir(library_dir())):
            if os.path.isdir(os.path.join(library_dir(), entry)):
                items.append(entry)
    except Exception:
        pass
    return items


def library_files(name):
    """Find the clean bundle and .resS inside a Library/<name> subfolder."""
    folder = os.path.join(library_dir(), name)
    bundle = ress = None
    try:
        for f in sorted(os.listdir(folder)):
            full = os.path.join(folder, f)
            if not os.path.isfile(full):
                continue
            low = f.lower()
            if (low.endswith(".bundle") or low.endswith(".bin")) and not bundle:
                bundle = full
            elif low.endswith(".ress") and not ress:
                ress = full
    except Exception:
        pass
    return bundle, ress


_FMT_MAP = {100: "BC3_UNORM_SRGB", 101: "BC3_UNORM",
            108: "BC7_UNORM_SRGB", 109: "BC7_UNORM"}


def detect_spec_from_bundle(bundle_path, log):
    """Read the bundle's Texture2DArrays and return a spec dict for the sRGB
    albedo (the color texture you actually skin). Returns None if unreadable."""
    try:
        import UnityPy
    except ImportError:
        log("  auto-detect: UnityPy not installed.")
        return None
    try:
        env = UnityPy.load(bundle_path)
    except Exception as e:
        log(f"  auto-detect: couldn't open bundle ({e})")
        return None

    arrays = []
    for obj in getattr(env, "objects", []):
        try:
            if getattr(obj.type, "name", "") != "Texture2DArray":
                continue
        except Exception:
            continue
        tree = None
        try:
            tree = obj.read_typetree()
        except Exception:
            try:                                  # fall back to typed read
                d = obj.read()
                tree = {k: getattr(d, k, None) for k in
                        ("m_Name", "m_Format", "m_ColorSpace",
                         "m_Width", "m_Height", "m_Depth", "m_DataSize")}
                sd = getattr(d, "m_StreamData", None)
                if sd is not None:
                    tree["m_StreamData"] = {"offset": getattr(sd, "offset", 0),
                                            "size": getattr(sd, "size", 0),
                                            "path": getattr(sd, "path", "")}
            except Exception:
                tree = None
        if isinstance(tree, dict) and tree.get("m_Format") is not None:
            arrays.append(tree)

    if not arrays:
        log("  auto-detect: no readable Texture2DArray (type tree may be stripped).")
        return None

    def is_albedo(t):
        return t.get("m_ColorSpace") == 1 or t.get("m_Format") in (100, 108)

    a = next((t for t in arrays if is_albedo(t)), arrays[0])
    sd = a.get("m_StreamData") or {}
    fmt = a.get("m_Format")
    depth = int(a.get("m_Depth") or 1)
    size = int(sd.get("size") or a.get("m_DataSize") or 0)

    spec = {
        "name": a.get("m_Name") or "auto",
        "width": int(a.get("m_Width") or 2048),
        "height": int(a.get("m_Height") or 2048),
        "slices": depth,
        "total": size,
        "per_slice": int(size // depth) if depth else size,
        "stream_offset": int(sd.get("offset") or 0),
    }
    tf = _FMT_MAP.get(fmt)
    if tf:
        spec["texconv_fmt"] = tf
    else:
        log(f"  auto-detect: unrecognized m_Format {fmt}; left format unchanged.")
    path = sd.get("path") or ""
    if path:
        spec["ress_name"] = os.path.basename(path)
    log(f"  auto-detect: '{a.get('m_Name')}' fmt={fmt} offset={sd.get('offset')} "
        f"size={size} ({len(arrays)} arrays in bundle)")
    return spec


def load_settings():
    cfg = json.loads(json.dumps(DEFAULT))  # deep copy
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            saved = json.load(f)
        cfg.update({k: v for k, v in saved.items() if k != "spec"})
        if isinstance(saved.get("spec"), dict):
            cfg["spec"].update(saved["spec"])
    except Exception:
        pass

    # Auto-detect anything still unset (bundled or next to the app).
    if not cfg["texconv_path"] or not os.path.exists(cfg["texconv_path"]):
        cfg["texconv_path"] = bundled("texconv.exe") or cfg["texconv_path"]
    if not cfg["bundle_path"] or not os.path.exists(cfg["bundle_path"]):
        for nm in (cfg["spec"].get("bundle_name", ""),
                   "original_bundle.bin", "original_bundle", "clean_bundle.bin"):
            b = bundled(nm) if nm else None
            if b:
                cfg["bundle_path"] = b
                break
    if not cfg["clean_ress_path"] or not os.path.exists(cfg["clean_ress_path"]):
        cfg["clean_ress_path"] = (bundled(cfg["spec"]["ress_name"])
                                  or bundled("clean.resS")
                                  or cfg["clean_ress_path"])
    # out_dir intentionally left blank = "auto" (next to the app, resolved at
    # run time). Baking app_dir() here would freeze the path if the app moves.
    # Un-bake an older auto-default (Desktop or the app folder) so it follows
    # the app again instead of being stuck where it was first run.
    _desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    _od = os.path.normpath(cfg.get("out_dir") or "")
    if _od and _od in (os.path.normpath(_desktop), os.path.normpath(app_dir())):
        cfg["out_dir"] = ""
    if not cfg.get("uabea_path") or not os.path.exists(cfg["uabea_path"]):
        cfg["uabea_path"] = find_uabea(app_dir()) or cfg.get("uabea_path", "")
    return cfg


def save_settings(cfg):
    with open(settings_path(), "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


# ----------------------------- pipeline core --------------------------------
class SwapError(Exception):
    pass


def machine_id():
    """A stable, unique-per-PC id (short hash). Windows uses MachineGuid."""
    raw = ""
    if os.name == "nt":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                               r"SOFTWARE\Microsoft\Cryptography")
            raw, _ = winreg.QueryValueEx(k, "MachineGuid")
            winreg.CloseKey(k)
        except Exception:
            raw = ""
    if not raw:
        raw = platform.node() + "-" + str(uuid.getnode())
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:16].upper()


def check_license(cfg):
    """Returns (ok, message, code). Validates the key against the hosted list,
    and - if require_device is on - that the key is bound to THIS machine."""
    if not LICENSE_URL:
        return True, "license check OFF (no URL configured)", "no_url"
    key = (cfg.get("license_key") or "").strip()
    if not key:
        return False, "No license key entered. Open Settings and paste your key.", "no_key"
    try:
        req = urllib.request.Request(LICENSE_URL, headers={"Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        return False, f"Couldn't verify license (no internet?): {e}", "net"
    if data.get("enabled") is False:
        return False, "Access has been disabled by the author.", "disabled"

    # keys may be plain strings or {"key": ..., "device": ...}
    matched = None
    for e in data.get("keys", []):
        if isinstance(e, str) and e == key:
            matched = {"key": e}
            break
        if isinstance(e, dict) and e.get("key") == key:
            matched = e
            break
    if matched is None:
        return False, "This license key is not recognized or has been revoked.", "unknown_key"

    if data.get("require_device"):
        mine = machine_id()
        bound = (matched.get("device") or "").strip().upper()
        if not bound:
            return (False,
                    f"Not activated on this PC yet.\nYour Machine ID:  {mine}\n"
                    f"Send this ID to {AUTHOR} to activate your key.", "unactivated")
        if bound != mine:
            return (False,
                    f"This key is locked to a different PC.\nYour Machine ID:  {mine}\n"
                    f"Contact {AUTHOR} if you changed computers.", "wrong_device")

    return True, "License verified.", "ok"


def _ver_tuple(s):
    out = []
    for part in str(s).split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out)


def check_update(cfg):
    """Returns (latest, url) if the hosted file advertises a newer version."""
    if not LICENSE_URL:
        return None
    try:
        req = urllib.request.Request(LICENSE_URL, headers={"Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return None
    latest = data.get("latest_version")
    if latest and _ver_tuple(latest) > _ver_tuple(VERSION):
        return latest, data.get("download_url", "")
    return None


def png_dimensions(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        raise SwapError(f"{os.path.basename(path)} is not a valid PNG.")
    return struct.unpack(">II", head[16:24])


def encode(texconv, fmt, png_path, tmpdir, log):
    base = os.path.basename(png_path)
    log(f"  texconv  {base}  ->  {fmt}")
    cmd = [texconv, "-f", fmt, "-m", "0", "-y", "-o", tmpdir, png_path]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise SwapError("texconv failed:\n" + (res.stdout or "") + (res.stderr or ""))
    stem = os.path.splitext(base)[0]
    for ext in (".dds", ".DDS"):
        cand = os.path.join(tmpdir, stem + ext)
        if os.path.exists(cand):
            return cand
    raise SwapError(f"texconv produced no .dds for {stem}")


def raw_payload(dds_path, per_slice):
    data = open(dds_path, "rb").read()
    if data[:4] != b"DDS ":
        raise SwapError(f"{os.path.basename(dds_path)} has no DDS magic.")
    header = 148 if data[84:88] == b"DX10" else 128
    payload = data[header:]
    if len(payload) != per_slice:
        raise SwapError(
            f"{os.path.basename(dds_path)} payload is {len(payload):,} bytes, "
            f"expected {per_slice:,}. Wrong dimensions, missing mips (-m 0), "
            f"or wrong format.")
    return payload


def _reader_bytes(f):
    """Pull raw bytes out of whatever UnityPy hands back for a file node."""
    if isinstance(f, (bytes, bytearray)):
        return bytes(f)
    v = getattr(f, "bytes", None)
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    # EndianBinaryReader-like object
    if hasattr(f, "read") and hasattr(f, "Length"):
        try:
            pos = getattr(f, "Position", 0)
            f.Position = 0
            d = f.read(f.Length)
            f.Position = pos
            return bytes(d)
        except Exception:
            return None
    return None


def extract_ress_from_bundle(bundle_path, ress_name, log):
    """Read the clean .resS straight out of a (clean) Unity bundle. Read-only."""
    try:
        import UnityPy
    except ImportError:
        raise SwapError("UnityPy is needed to read the bundle.\n"
                        "Run:  pip install UnityPy\n"
                        "...or set a clean .resS file instead in Settings.")
    try:
        env = UnityPy.load(bundle_path)
    except Exception as e:
        raise SwapError(f"Couldn't open bundle: {e}")

    target = os.path.basename(ress_name)
    candidates = {}
    fobj = getattr(env, "file", None)
    if isinstance(getattr(fobj, "files", None), dict):
        candidates.update(fobj.files)
    if isinstance(getattr(env, "files", None), dict):
        candidates.update(env.files)

    # exact name first, then any .resS
    order = sorted(candidates.items(),
                   key=lambda kv: 0 if os.path.basename(kv[0]) == target else 1)
    for name, f in order:
        base = os.path.basename(name)
        if base == target or base.endswith(".resS"):
            data = _reader_bytes(f)
            if data:
                log(f"  extracted {base} from bundle ({len(data):,} bytes)")
                return data
    raise SwapError("Couldn't find a .resS inside that bundle. Make sure it's the "
                    "ORIGINAL clean bundle, or set a clean .resS file in Settings.")


def get_clean_ress_bytes(cfg, log):
    bp = cfg.get("bundle_path", "")
    if bp and os.path.exists(bp):
        log(f"  clean source: bundle  ({os.path.basename(bp)})")
        return extract_ress_from_bundle(bp, cfg["spec"]["ress_name"], log)
    rp = cfg.get("clean_ress_path", "")
    if rp and os.path.exists(rp):
        log(f"  clean source: file  ({os.path.basename(rp)})")
        return open(rp, "rb").read()
    raise SwapError("No clean source set. In Settings, pick the original bundle "
                    "(preferred) or a clean .resS file.")


def inject(blob, clean_bytes, stream_offset, out_dir, ress_name, log):
    ress = bytearray(clean_bytes)
    end = stream_offset + len(blob)
    if end > len(ress):
        raise SwapError(f".resS too small ({len(ress):,} bytes) for inject.")
    ress[stream_offset:end] = blob
    os.makedirs(out_dir, exist_ok=True)
    out_ress = os.path.join(out_dir, ress_name)
    open(out_ress, "wb").write(ress)
    log(f"  inject: wrote {len(ress):,} bytes -> {ress_name}")
    return out_ress, bytes(ress)


def _probe_bundle(raw):
    """Report a Unity bundle's type + blocksInfo compression so we know what we face."""
    try:
        if raw[:7] != b"UnityFS":
            return f"signature={raw[:8]!r} (not UnityFS — may be raw/UnityWeb)"
        p = raw.index(b"\x00") + 1
        ver = struct.unpack(">i", raw[p:p + 4])[0]; p += 4
        e1 = raw.index(b"\x00", p); p = e1 + 1            # unity version
        e2 = raw.index(b"\x00", p); urev = raw[p:e2].decode("ascii", "replace"); p = e2 + 1
        p += 8                                            # size (int64)
        p += 8                                            # ci/ui blocksInfo sizes
        flags = struct.unpack(">i", raw[p:p + 4])[0]
        comp = {0: "none", 1: "lzma", 2: "lz4", 3: "lz4hc"}.get(flags & 0x3F, f"?{flags & 0x3F}")
        return f"UnityFS v{ver} unity={urev} blocksInfo={comp} flags=0x{flags:X}"
    except Exception as e:
        return f"(couldn't parse header: {e})"


def _find_EBR():
    """Locate UnityPy's EndianBinaryReader across versions."""
    for modpath in ("UnityPy.streams", "UnityPy.streams.EndianBinaryReader",
                    "UnityPy.helpers.EndianBinaryReader"):
        try:
            mod = __import__(modpath, fromlist=["EndianBinaryReader"])
            return getattr(mod, "EndianBinaryReader")
        except Exception:
            continue
    return None


def _repack_unitypy(bundle_path, ress_name, patched_bytes, out_dir, out_name, log):
    """Fallback repack: replace the .resS via UnityPy and re-serialize the bundle."""
    try:
        import UnityPy
    except ImportError:
        raise SwapError("UnityPy not available to repack. Use the .resS in UABEA.")

    env = UnityPy.load(bundle_path)
    bundle = getattr(env, "file", None)
    files = getattr(bundle, "files", None)
    if not isinstance(files, dict):
        raise SwapError(f"Unexpected bundle layout ({type(bundle).__name__}); use UABEA.")

    target = os.path.basename(ress_name)
    key = next((n for n in files if os.path.basename(n) == target), None) \
        or next((n for n in files if os.path.basename(n).endswith(".resS")), None)
    if key is None:
        raise SwapError("resS not found in bundle to repack; use UABEA.")

    # Replace content. UnityPy's serializer expects an EndianBinaryReader for a
    # resource file, NOT raw bytes — wrap it (raw-dict assignment never errors,
    # which is exactly what silently broke before).
    EBR = _find_EBR()
    if EBR is not None:
        try:
            files[key] = EBR(patched_bytes)
        except Exception as e:
            log(f"  (EndianBinaryReader wrap failed: {e}; trying raw bytes)")
            files[key] = patched_bytes
    else:
        log("  (couldn't import EndianBinaryReader; trying raw bytes)")
        files[key] = patched_bytes

    # Re-serialize, surfacing the FIRST real error if every packer fails.
    last_err = None
    data = None
    for kw in ({}, {"packer": "original"}, {"packer": "lz4"}, {"packer": "none"}):
        try:
            data = bundle.save(**kw)
            if data:
                tag = kw.get("packer", "default")
                log(f"  repack: UnityPy re-serialize (packer={tag})")
                break
        except Exception as e:
            last_err = e
    if not data:
        raise SwapError(f"Bundle re-serialize failed. Real error: "
                        f"{type(last_err).__name__}: {last_err}")
    outp = os.path.join(out_dir, out_name)
    with open(outp, "wb") as f:
        f.write(data)
    log(f"  repack: wrote {len(data):,} bytes -> {out_name}", "ok")
    return outp


def _cstr(buf, pos):
    end = buf.index(b"\x00", pos)
    return buf[pos:end].decode("utf-8", "replace"), end + 1


def _lz4_decompress_py(src, dst_size):
    """Pure-Python LZ4 block decompressor (fallback if the lz4 lib is absent)."""
    out = bytearray()
    i, n = 0, len(src)
    while i < n:
        token = src[i]; i += 1
        lit = token >> 4
        if lit == 15:
            while True:
                b = src[i]; i += 1
                lit += b
                if b != 255:
                    break
        out += src[i:i + lit]; i += lit
        if len(out) >= dst_size or i >= n:
            break
        off = src[i] | (src[i + 1] << 8); i += 2
        ml = (token & 0x0F) + 4
        if (token & 0x0F) == 15:
            while True:
                b = src[i]; i += 1
                ml += b
                if b != 255:
                    break
        s = len(out) - off
        if off >= ml:
            out += out[s:s + ml]
        else:
            for j in range(ml):
                out.append(out[s + j])
    return bytes(out)


def _block_decompress(ctype, data, usize):
    if ctype == 0:
        return bytes(data)
    if ctype in (2, 3):                       # lz4 / lz4hc
        try:
            import lz4.block
            return lz4.block.decompress(bytes(data), uncompressed_size=usize)
        except Exception:
            return _lz4_decompress_py(bytes(data), usize)
    if ctype == 1:                            # LZMA (5 props + raw stream)
        import lzma
        data = bytes(data)
        full = data[:5] + struct.pack("<Q", usize) + data[5:]   # rebuild ALONE header
        return lzma.decompress(full, format=lzma.FORMAT_ALONE)
    raise SwapError(f"block compression type {ctype} not supported by native repacker")


def _unity_lzma_compress(data, preset=6):
    """LZMA in Unity's bundle layout: 5 properties bytes + raw stream (the
    uncompressed size is carried by the block header, not embedded)."""
    import lzma
    c = lzma.compress(bytes(data), format=lzma.FORMAT_ALONE, preset=preset)
    return c[:5] + c[13:]                     # drop ALONE's 8-byte size field


def repack_unityfs_native(bundle_path, patched_ress, ress_name, out_path, log,
                          compression="lz4hc"):
    """Rebuild a UnityFS bundle with the .resS replaced, no UnityPy.
    compression='lz4hc' matches what the game shipped (fast to decompress in
    game, so no draw hitch); 'none' stores it uncompressed; 'lzma' is smallest
    on disk but decompresses slowly in game (causes a draw lag spike)."""
    raw = open(bundle_path, "rb").read()
    if raw[:8] != b"UnityFS\x00":
        raise SwapError("not a UnityFS bundle")
    pos = 8
    version = struct.unpack_from(">I", raw, pos)[0]; pos += 4
    unity_ver, pos = _cstr(raw, pos)
    unity_rev, pos = _cstr(raw, pos)
    pos += 8                                          # total size (recomputed)
    ci = struct.unpack_from(">I", raw, pos)[0]; pos += 4
    ui = struct.unpack_from(">I", raw, pos)[0]; pos += 4
    flags = struct.unpack_from(">I", raw, pos)[0]; pos += 4

    if version >= 7:
        pos = (pos + 15) & ~15
    if flags & 0x80:                                  # blocksInfo at end of file
        blocks_comp = raw[len(raw) - ci:len(raw)]
        data_start = pos
    else:
        blocks_comp = raw[pos:pos + ci]
        data_start = pos + ci
    binfo = _block_decompress(flags & 0x3F, blocks_comp, ui)

    bp = 0
    data_hash = binfo[bp:bp + 16]; bp += 16
    nblocks = struct.unpack_from(">i", binfo, bp)[0]; bp += 4
    blocks = []
    for _ in range(nblocks):
        u = struct.unpack_from(">I", binfo, bp)[0]; bp += 4
        c = struct.unpack_from(">I", binfo, bp)[0]; bp += 4
        bf = struct.unpack_from(">H", binfo, bp)[0]; bp += 2
        blocks.append((u, c, bf))
    nnodes = struct.unpack_from(">i", binfo, bp)[0]; bp += 4
    nodes = []
    for _ in range(nnodes):
        off = struct.unpack_from(">q", binfo, bp)[0]; bp += 8
        sz = struct.unpack_from(">q", binfo, bp)[0]; bp += 8
        nf = struct.unpack_from(">I", binfo, bp)[0]; bp += 4
        name, bp = _cstr(binfo, bp)
        nodes.append([off, sz, nf, name])

    # reconstruct the full uncompressed data stream
    data = bytearray()
    dp = data_start
    if flags & 0x200:                                 # padding before data
        dp = (dp + 15) & ~15
    for (u, c, bf) in blocks:
        data += _block_decompress(bf & 0x3F, raw[dp:dp + c], u); dp += c

    # find and replace the .resS node
    target = os.path.basename(ress_name)
    node = next((nd for nd in nodes if os.path.basename(nd[3]) == target), None) \
        or next((nd for nd in nodes if nd[3].lower().endswith(".ress")), None)
    if node is None:
        raise SwapError("resS node not found inside bundle")
    off, sz = node[0], node[1]
    if sz != len(patched_ress):
        raise SwapError(f"resS size mismatch ({sz} vs {len(patched_ress)})")
    data[off:off + sz] = patched_ress

    # Build the data section + block descriptors per the chosen compression.
    if compression == "lz4hc":
        import lz4.block
        log("  repack: compressing data (LZ4HC) — fast in-game, like the original…")
        block_descs, data_section, dp = [], bytearray(), 0
        for (u, c, bf) in blocks:                      # reuse original block sizes
            chunk = bytes(data[dp:dp + u]); dp += u
            comp = lz4.block.compress(chunk, mode="high_compression",
                                      compression=9, store_size=False)
            if len(comp) < u:
                block_descs.append((u, len(comp), 3))  # 3 = lz4hc
                data_section += comp
            else:                                      # incompressible block → raw
                block_descs.append((u, u, 0))
                data_section += chunk
        data_section = bytes(data_section)
        log(f"  repack: LZ4HC {len(data):,} -> {len(data_section):,} bytes")
    elif compression == "lzma":
        log("  repack: compressing data (LZMA) — this can take a few seconds…")
        comp = _unity_lzma_compress(bytes(data))
        block_descs = [(len(data), len(comp), 1)]     # one LZMA block (flags 1)
        data_section = comp
        log(f"  repack: LZMA {len(data):,} -> {len(comp):,} bytes")
    else:
        # uncompressed: keep the original block boundaries, flags 0
        block_descs, data_section, dp = [], bytearray(), 0
        for (u, c, bf) in blocks:
            block_descs.append((u, u, 0))
            data_section += bytes(data[dp:dp + u]); dp += u
        data_section = bytes(data_section)

    nb = bytearray()
    nb += data_hash
    nb += struct.pack(">i", len(block_descs))
    for (u, c, fl) in block_descs:
        nb += struct.pack(">I", u)                    # uncompressed size
        nb += struct.pack(">I", c)                    # compressed size
        nb += struct.pack(">H", fl)
    nb += struct.pack(">i", len(nodes))
    for (o, s, nf, name) in nodes:
        nb += struct.pack(">q", o)
        nb += struct.pack(">q", s)
        nb += struct.pack(">I", nf)
        nb += name.encode("utf-8") + b"\x00"

    out = bytearray()
    out += b"UnityFS\x00"
    out += struct.pack(">I", version)
    out += unity_ver.encode("utf-8") + b"\x00"
    out += unity_rev.encode("utf-8") + b"\x00"
    size_pos = len(out)
    out += struct.pack(">q", 0)
    out += struct.pack(">I", len(nb))                 # blocksInfo stored uncompressed
    out += struct.pack(">I", len(nb))                 # so compressed == uncompressed
    out += struct.pack(">I", 0x40)                    # combined, uncompressed info, after header
    if version >= 7:
        while len(out) % 16 != 0:
            out += b"\x00"
    out += nb
    out += data_section
    struct.pack_into(">q", out, size_pos, len(out))

    with open(out_path, "wb") as f:
        f.write(out)
    log(f"  repack: native rebuild ({compression}) -> "
        f"{os.path.basename(out_path)} ({len(out):,} bytes)")
    return out_path


def _validate_bundle(path, ress_name, expected_len, log):
    """Confirm the rebuilt bundle re-opens and the .resS is intact (UnityPy as a
    reference reader). If UnityPy can read it, the game very likely can too."""
    try:
        import UnityPy
        env = UnityPy.load(path)
        files = getattr(getattr(env, "file", None), "files", {}) or {}
        target = os.path.basename(ress_name)
        for name, f in files.items():
            base = os.path.basename(name)
            if base == target or base.lower().endswith(".ress"):
                b = _reader_bytes(f)
                if b is not None and len(b) == expected_len:
                    return True
        return False
    except Exception as e:
        log(f"  repack: validation couldn't run ({e})")
        return False


def repack_bundle(bundle_path, clean_bytes, patched_bytes, ress_name,
                  out_dir, out_name, log):
    """In-place patch (uncompressed resS) -> native rebuild -> UnityPy."""
    raw = open(bundle_path, "rb").read()
    log("  bundle: " + _probe_bundle(raw))
    outp = os.path.join(out_dir, out_name)

    # 1) byte-exact in-place patch (works only if the resS is stored uncompressed)
    L = len(clean_bytes)
    Q = L // 2
    needle = clean_bytes[Q:Q + 8192]
    start = 0
    while needle:
        idx = raw.find(needle, start)
        if idx == -1:
            break
        cand = idx - Q
        if cand >= 0 and raw[cand:cand + L] == clean_bytes:
            out = bytearray(raw)
            out[cand:cand + len(patched_bytes)] = patched_bytes
            with open(outp, "wb") as f:
                f.write(out)
            log(f"  repack: in-place patch @0x{cand:X} (uncompressed) -> {out_name}", "ok")
            return outp
        start = idx + 1

    # 2) native UnityFS rebuild — LZMA first (compact), uncompressed as fallback
    for mode in ("lz4hc", "none"):
        log(f"  repack: rebuilding natively ({mode})…")
        try:
            repack_unityfs_native(bundle_path, patched_bytes, ress_name, outp, log,
                                  compression=mode)
            if _validate_bundle(outp, ress_name, len(patched_bytes), log):
                log(f"  repack: native rebuild validated ({mode}) -> {out_name}", "ok")
                return outp
            log(f"  repack: {mode} output didn't validate; trying next method…")
        except Exception as e:
            log(f"  repack: native {mode} error ({e}); trying next method…")

    # 3) UnityPy fallback
    return _repack_unitypy(bundle_path, ress_name, patched_bytes, out_dir, out_name, log)


def safe_folder_name(name):
    """Make a user-typed label safe to use as a Windows folder name."""
    name = (name or "").strip()
    bad = '<>:"/\\|?*'
    out = "".join(c for c in name if c not in bad and ord(c) >= 32).strip()
    out = out.rstrip(". ")          # Windows dislikes trailing dot/space
    return out[:80]


def run_pipeline(cfg, png0, png1, swap_order, do_repack, single_slice, create_name, log,
                 extra_layers=None):
    s = cfg["spec"]
    texconv = cfg["texconv_path"]
    if not texconv or not os.path.exists(texconv):
        raise SwapError("texconv.exe not set. Open Settings and pick it.")

    safe = safe_folder_name(create_name)
    if not safe:
        raise SwapError("Enter a name for this skin before starting.")

    if single_slice:
        log("  single-slice texture (1 PNG)")
        w, h = png_dimensions(png0)
        log(f"  slice0: {os.path.basename(png0)}  {w}x{h}")
        if (w, h) != (s["width"], s["height"]):
            raise SwapError(f"PNG is {w}x{h}, must be {s['width']}x{s['height']}.")
    else:
        for tag, p in (("slice0", png0), ("slice1", png1)):
            w, h = png_dimensions(p)
            log(f"  {tag}: {os.path.basename(p)}  {w}x{h}")
            if (w, h) != (s["width"], s["height"]):
                raise SwapError(f"{tag} is {w}x{h}, must be {s['width']}x{s['height']}.")
        if swap_order:
            png0, png1 = png1, png0
            log("  (slice order swapped)")

    # Each creation gets its own folder:  <out_base>/Bundle Output/<name>/
    # out_base is the user's chosen folder, or (default) right next to the app.
    out_base = (cfg.get("out_dir") or "").strip()
    if not out_base or not os.path.isdir(out_base):
        out_base = app_dir()
    final_dir = os.path.join(out_base, "Bundle Output", safe)
    try:
        os.makedirs(final_dir, exist_ok=True)
    except OSError:
        # app folder wasn't writable (e.g. Program Files) — use the home folder.
        final_dir = os.path.join(os.path.expanduser("~"), APP_NAME,
                                 "Bundle Output", safe)
        os.makedirs(final_dir, exist_ok=True)
    log(f"  saving to: {final_dir}")

    with tempfile.TemporaryDirectory(prefix="skinswap_") as tmp:
        log("[1/3] encode")
        dds0 = encode(texconv, s["texconv_fmt"], png0, tmp, log)
        if single_slice:
            blob = raw_payload(dds0, s["per_slice"])
            expected = s["per_slice"]
        else:
            dds1 = encode(texconv, s["texconv_fmt"], png1, tmp, log)
            blob = raw_payload(dds0, s["per_slice"]) + raw_payload(dds1, s["per_slice"])
            expected = s["total"]
        log("[2/3] build")
        diff = len(blob) - expected
        log(f"  diff = {diff}   ({len(blob):,} / {expected:,})")
        if diff != 0:
            raise SwapError(f"diff = {diff} (must be 0). Build aborted.")
        log("[3/3] inject")
        clean = get_clean_ress_bytes(cfg, log)
        out_ress, patched = inject(blob, clean, s["stream_offset"],
                                   final_dir, s["ress_name"], log)

        # extra texture layers (e.g. MGE shine/reflectivity) patched into the SAME
        # .resS at their own offsets, so one bundle carries colour + shine together.
        for layer in (extra_layers or []):
            ls = layer["spec"]
            lp0 = layer.get("png0"); lp1 = layer.get("png1")
            lslices = int(ls.get("slices", 2))
            log("[+] layer: %s  -> %s" % (ls.get("name", "extra"), ls["texconv_fmt"]))
            ldds0 = encode(texconv, ls["texconv_fmt"], lp0, tmp, log)
            if bool(layer.get("single")) or lslices <= 1:
                lblob = raw_payload(ldds0, ls["per_slice"])
            elif lp1 and lp1 != lp0:
                ldds1 = encode(texconv, ls["texconv_fmt"], lp1, tmp, log)
                lblob = raw_payload(ldds0, ls["per_slice"]) + raw_payload(ldds1, ls["per_slice"])
            else:                                  # uniform: encode once, repeat per slice
                lblob = raw_payload(ldds0, ls["per_slice"]) * lslices
            lexp = int(ls.get("total") or ls["per_slice"] * max(1, lslices))
            ldiff = len(lblob) - lexp
            log("  diff = %d   (%d / %d)" % (ldiff, len(lblob), lexp))
            if ldiff != 0:
                raise SwapError("layer %s diff = %d (must be 0). Build aborted."
                                % (ls.get("name", "extra"), ldiff))
            out_ress, patched = inject(lblob, patched, ls["stream_offset"],
                                       final_dir, s["ress_name"], log)

    out_bundle = None
    have_bundle = bool(cfg.get("bundle_path") and os.path.exists(cfg["bundle_path"]))
    if do_repack and have_bundle:
        out_name = s.get("bundle_name") or os.path.basename(cfg["bundle_path"])
        log("[repack] writing .resS back into the bundle")
        try:
            out_bundle = repack_bundle(cfg["bundle_path"], clean, patched,
                                       s["ress_name"], final_dir, out_name, log)
        except SwapError as e:
            log("  " + str(e), "er")

    log("")
    if out_bundle:
        # the loose .resS was only an intermediate (and a UABEA fallback); the rebuilt
        # bundle is self-contained, so remove it and leave just the .bundle behind.
        try:
            if out_ress and os.path.isfile(out_ress):
                os.remove(out_ress)
                log("  removed intermediate .resS (bundle is self-contained)")
        except Exception:
            pass
        log("DONE. Ready-to-use bundle (no UABEA needed):", "ok")
        log(f"  {out_bundle}", "ok")
        log("Close the game + Meta/Oculus app, then copy this bundle into the")
        log("game folder and approve the admin prompt.")
    else:
        log("DONE. Patched .resS is ready:", "ok")
        log(f"  {out_ress}", "ok")
        log("In UABEA: open the bundle -> select the .resS -> Import this file ->")
        log("File > Save the bundle, then copy it into the game folder with the")
        log("game + Meta/Oculus app fully closed (approve the admin prompt).")


# ============================== Settings dialog ==============================
class Settings(tk.Toplevel):
    def __init__(self, master, cfg, on_save):
        super().__init__(master)
        self.cfg, self.on_save = cfg, on_save
        self.title("Settings")
        self.configure(bg="#15171c")
        self.resizable(False, False)
        f = ("Consolas", 10)
        pad = {"padx": 14, "pady": 4}

        self.v = {}

        def row(r, label, key, browse=None):
            tk.Label(self, text=label, bg="#15171c", fg="#9a9eaa",
                     font=f, anchor="w").grid(row=r, column=0, sticky="w", **pad)
            var = tk.StringVar(value=str(self._get(key)))
            self.v[key] = var
            e = tk.Entry(self, textvariable=var, width=46, font=("Consolas", 9),
                         bg="#22252c", fg="#d6d8de", insertbackground="#fff",
                         relief="flat")
            e.grid(row=r, column=1, sticky="we", **pad)
            if browse:
                tk.Button(self, text="…", font=f, command=lambda: browse(var),
                          bg="#2c2f38", fg="#d6d8de", relief="flat", width=3
                          ).grid(row=r, column=2, **pad)

        tk.Label(self, text="PATHS", bg="#15171c", fg="#ffae3b",
                 font=("Consolas", 10, "bold")).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 0))
        row(1, "texconv.exe", "texconv_path", self._pick_file)
        row(2, "original bundle", "bundle_path", self._pick_file)
        row(3, "clean .resS (fallback)", "clean_ress_path", self._pick_file)
        row(4, "UABEAvalonia.exe", "uabea_path", self._pick_file)
        row(5, "output folder", "out_dir", self._pick_dir)
        tk.Label(self, text="Clean source = the ORIGINAL clean bundle (preferred). "
                            "The clean .resS is pulled from it fresh each run, so "
                            "nothing goes stale. The .resS file is only a fallback.",
                 bg="#15171c", fg="#6b6f7a", font=("Consolas", 8),
                 wraplength=540, justify="left").grid(row=6, column=0, columnspan=3,
                                                      sticky="w", padx=14)

        tk.Label(self, text="TEXTURE SPEC", bg="#15171c", fg="#ffae3b",
                 font=("Consolas", 10, "bold")).grid(row=7, column=0, sticky="w", padx=14, pady=(12, 0))
        row(8, "texconv format", "spec.texconv_fmt")
        row(9, "width", "spec.width")
        row(10, "height", "spec.height")
        row(11, "slices (m_Depth)", "spec.slices")
        row(12, "per-slice bytes", "spec.per_slice")
        row(13, "total bytes", "spec.total")
        row(14, "stream offset", "spec.stream_offset")
        row(15, ".resS filename", "spec.ress_name")
        row(16, ".bundle name (target)", "spec.bundle_name")

        tk.Label(self, text="LICENSE", bg="#15171c", fg="#ffae3b",
                 font=("Consolas", 10, "bold")).grid(row=17, column=0, sticky="w", padx=14, pady=(12, 0))
        row(18, "license key", "license_key")

        tk.Label(self, text="Machine ID (this PC):", bg="#15171c", fg="#9a9eaa",
                 font=f).grid(row=19, column=0, sticky="w", **pad)
        mid = machine_id()
        mvar = tk.StringVar(value=mid)
        me = tk.Entry(self, textvariable=mvar, font=("Consolas", 9), bg="#22252c",
                      fg="#7fe787", relief="flat", state="readonly")
        me.grid(row=19, column=1, sticky="we", **pad)
        tk.Button(self, text="copy", font=f,
                  command=lambda: (self.clipboard_clear(), self.clipboard_append(mid)),
                  bg="#2c2f38", fg="#d6d8de", relief="flat", width=4
                  ).grid(row=19, column=2, **pad)

        tk.Button(self, text="SAVE", font=("Consolas", 11, "bold"),
                  command=self._save, bg="#ffae3b", fg="#000",
                  relief="flat", pady=6).grid(row=20, column=0, columnspan=3,
                                              sticky="we", padx=14, pady=12)
        self.columnconfigure(1, weight=1)
        self.transient(master)
        self.grab_set()

    def _get(self, key):
        if key.startswith("spec."):
            return self.cfg["spec"][key[5:]]
        return self.cfg[key]

    def _pick_file(self, var):
        p = filedialog.askopenfilename()
        if p:
            var.set(p)

    def _pick_dir(self, var):
        d = filedialog.askdirectory()
        if d:
            var.set(d)

    def _save(self):
        try:
            ints = {"spec.width", "spec.height", "spec.slices",
                    "spec.per_slice", "spec.total", "spec.stream_offset"}
            for key, var in self.v.items():
                val = var.get().strip()
                if key in ints:
                    val = int(val)
                if key.startswith("spec."):
                    self.cfg["spec"][key[5:]] = val
                else:
                    self.cfg[key] = val
            save_settings(self.cfg)
            self.on_save()
            self.destroy()
        except ValueError:
            messagebox.showerror("Settings", "Numeric fields must be whole numbers.")


# =============================== First-run gate ==============================
class LicenseGate(tk.Toplevel):
    """Blocking first-run window: shows the Terms and requires a valid key.
    Closing it without a valid key exits the app."""
    def __init__(self, master, cfg, on_pass, locked_info=None):
        super().__init__(master)
        self.cfg, self.on_pass = cfg, on_pass
        self.title("Skin Swapper - Access & Terms")
        self.configure(bg="#15171c")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._refuse)

        tk.Label(self, text="ACCESS REQUIRED", bg="#15171c", fg="#ffae3b",
                 font=("Consolas", 14, "bold")).pack(pady=(14, 2), padx=18)
        tk.Label(self, text=f"Skin Swapper v{VERSION}  ·  by {AUTHOR}",
                 bg="#15171c", fg="#6b6f7a", font=("Consolas", 9)).pack(padx=18)

        box = tk.Text(self, bg="#0e0f12", fg="#c7cad1", font=("Consolas", 9),
                      relief="flat", wrap="word", width=74, height=22,
                      padx=10, pady=8)
        box.insert("1.0", TERMS)
        box.config(state="disabled")
        box.pack(padx=18, pady=10)

        tk.Label(self, text="Enter the access key GW1DDY gave you:",
                 bg="#15171c", fg="#9a9eaa",
                 font=("Consolas", 10)).pack(anchor="w", padx=18)
        self.key = tk.StringVar()
        ent = tk.Entry(self, textvariable=self.key, font=("Consolas", 11),
                       bg="#22252c", fg="#d6d8de", insertbackground="#fff",
                       relief="flat")
        ent.pack(fill="x", padx=18, ipady=5, pady=(3, 4))
        ent.focus_set()

        # --- Machine ID with a Copy button (send this to GW1DDY to activate) ---
        self._mid = machine_id()
        tk.Label(self, text="Your Machine ID (send this to GW1DDY to activate):",
                 bg="#15171c", fg="#9a9eaa",
                 font=("Consolas", 9)).pack(anchor="w", padx=18, pady=(6, 0))
        idrow = tk.Frame(self, bg="#15171c")
        idrow.pack(fill="x", padx=18, pady=(2, 4))
        mide = tk.Entry(idrow, font=("Consolas", 10), bg="#22252c", fg="#ffae3b",
                        relief="flat", readonlybackground="#22252c",
                        insertbackground="#fff")
        mide.insert(0, self._mid)
        mide.config(state="readonly")
        mide.pack(side="left", fill="x", expand=True, ipady=4)
        self._copy_btn = tk.Button(idrow, text="Copy", font=("Consolas", 9),
                                   command=self._copy_id, bg="#2c2f38", fg="#d6d8de",
                                   activebackground="#3a3e49", relief="flat", padx=14)
        self._copy_btn.pack(side="right", fill="y", padx=(6, 0))

        self.msg = tk.Label(self, text="", bg="#15171c", fg="#ff6b6b",
                            font=("Consolas", 9), wraplength=520, justify="left")
        self.msg.pack(padx=18)

        self._agree_btn = tk.Button(self, text="I AGREE  &  CONTINUE",
                                    font=("Consolas", 11, "bold"),
                                    command=self._agree, bg="#ffae3b", fg="#000",
                                    relief="flat", pady=8)
        self._agree_btn.pack(fill="x", padx=18, pady=(6, 14))

        # Reopened without being verified: pre-fill the saved key, explain the lock,
        # and let "I AGREE & CONTINUE" re-check (e.g. after the author activates them).
        if locked_info:
            m, code = locked_info
            self.key.set((cfg.get("license_key") or "").strip())
            warm = code in ("unactivated", "net")
            self._agree_btn.config(text="RE-CHECK ACCESS")
            self.msg.config(
                text=m + (f"\n\nCopy your Machine ID above, send it to {AUTHOR}, "
                          "then press RE-CHECK once it's activated." if warm else ""),
                fg="#ffae3b" if warm else "#ff6b6b")

        self.transient(master)
        self.grab_set()
        self.lift()
        self.focus_force()

    def _copy_id(self):
        try:
            self.clipboard_clear()
            self.clipboard_append(self._mid)
            self.update()
            self._copy_btn.config(text="Copied!")
            self.after(1200, lambda: self._copy_btn.config(text="Copy"))
        except Exception:
            pass

    def _refuse(self):
        self.master.destroy()        # closing without a valid key exits the app

    def _agree(self):
        k = self.key.get().strip()
        if not k:
            self.msg.config(text="Please enter your access key to continue.", fg="#ff6b6b")
            return
        self.msg.config(text="Verifying key…", fg="#ffae3b")
        self.update_idletasks()
        self.cfg["license_key"] = k
        ok, m, code = check_license(self.cfg)
        if ok:
            save_settings(self.cfg)
            self.grab_release()
            self.destroy()
            self.on_pass()
        elif code == "unactivated":
            # key is real and they've agreed; remember it so reopening skips
            # the gate. They still can't run until you bind their Machine ID.
            save_settings(self.cfg)
            self.msg.config(
                text=m + f"\n\nClose the app, send your Machine ID to {AUTHOR}, "
                         "then reopen once it's activated.", fg="#ffae3b")
        else:
            self.cfg["license_key"] = ""
            self.msg.config(text=m, fg="#ff6b6b")


# ================================== Main GUI =================================
class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_settings()
        self.png0 = self.png1 = None
        self._ref0 = self._ref1 = None         # split+flipped reference slices (PIL)

        root.title(f"Skin Swapper {VERSION}  ·  by {AUTHOR}")
        root.configure(bg="#15171c")
        root.geometry("680x820")
        accent = "#ffae3b"
        f = ("Consolas", 10)

        top = tk.Frame(root, bg="#15171c")
        top.pack(fill="x", pady=(16, 0))
        tk.Label(top, text="SKIN SWAPPER", bg="#15171c", fg=accent,
                 font=("Consolas", 18, "bold")).pack(side="left", padx=(20, 6))
        tk.Label(top, text=f"by {AUTHOR}", bg="#15171c", fg="#6b6f7a",
                 font=("Consolas", 10, "italic")).pack(side="left", anchor="s", pady=(0, 4))
        tk.Button(top, text="⚙ Settings", font=f, command=self.open_settings,
                  bg="#22252c", fg="#d6d8de", relief="flat", padx=10, pady=4
                  ).pack(side="right", padx=(6, 20))
        tk.Button(top, text="Terms", font=f, command=self.open_terms,
                  bg="#22252c", fg="#d6d8de", relief="flat", padx=10, pady=4
                  ).pack(side="right", padx=6)
        tk.Button(top, text="Contact", font=f, command=self.open_contact,
                  bg="#22252c", fg="#d6d8de", relief="flat", padx=10, pady=4
                  ).pack(side="right", padx=6)

        self.spec_lbl = tk.Label(root, bg="#15171c", fg="#6b6f7a", font=f)
        self.spec_lbl.pack(pady=(0, 4))
        self.status = tk.Label(root, bg="#15171c", font=("Consolas", 9))
        self.status.pack(pady=(0, 6))

        # Library dropdown - pick a weapon/item; loads its clean files
        lib = tk.Frame(root, bg="#15171c")
        lib.pack(fill="x", padx=20, pady=(0, 6))
        tk.Label(lib, text="Library", bg="#15171c", fg="#6b6f7a",
                 font=("Consolas", 9)).pack(anchor="w")
        librow = tk.Frame(lib, bg="#15171c")
        librow.pack(fill="x", pady=(2, 0))
        self.library_var = tk.StringVar(value="— select weapon / item —")
        self.lib_menu = tk.OptionMenu(librow, self.library_var, "")
        self.lib_menu.config(bg="#22252c", fg="#d6d8de", activebackground="#2c2f38",
                             relief="flat", highlightthickness=0, font=f, anchor="w")
        self.lib_menu["menu"].config(bg="#22252c", fg="#d6d8de",
                                     activebackground="#ffae3b", activeforeground="#000")
        self.lib_menu.pack(side="left", fill="x", expand=True)
        tk.Button(librow, text="↻", font=f, command=self._reload_library,
                  bg="#22252c", fg="#d6d8de", relief="flat", width=3
                  ).pack(side="right", padx=(6, 0))

        # target bundle name + copy
        tgt = tk.Frame(root, bg="#15171c")
        tgt.pack(fill="x", padx=20, pady=(0, 8))
        tk.Label(tgt, text="Target bundle", bg="#15171c", fg="#6b6f7a",
                 font=("Consolas", 9)).pack(anchor="w")
        row2 = tk.Frame(tgt, bg="#0e0f12")
        row2.pack(fill="x", pady=(2, 0))
        self.bundle_name_lbl = tk.Label(row2, text="", bg="#0e0f12", fg="#d6d8de",
                                        font=("Consolas", 8), anchor="w",
                                        wraplength=540, justify="left", padx=8, pady=6)
        self.bundle_name_lbl.pack(side="left", fill="x", expand=True)
        tk.Button(row2, text="Copy", font=("Consolas", 9), command=self.copy_bundle_name,
                  bg="#22252c", fg="#ffae3b", relief="flat", padx=10
                  ).pack(side="right", fill="y")

        r0 = tk.Frame(root, bg="#15171c")
        r0.pack(fill="x", padx=20, pady=4)
        self.b0 = tk.Button(r0, text="① Choose  slice0  PNG", font=f, anchor="w",
                            command=self.pick0, bg="#22252c", fg="#d6d8de",
                            activebackground="#2c2f38", relief="flat", padx=12, pady=8)
        self.b0.pack(side="left", fill="x", expand=True)
        self.thumb0 = tk.Label(r0, bg="#15171c", bd=1, relief="flat")
        self.thumb0.pack(side="left", padx=(6, 0))
        self.dl0 = tk.Button(r0, text="Download", font=("Consolas", 9),
                             command=lambda: self._download_slice(0), state="disabled",
                             bg="#2c2f38", fg="#5a5d66", activebackground="#3a3e49",
                             relief="flat", padx=10)
        self.dl0.pack(side="left", fill="y", padx=(6, 0))

        r1 = tk.Frame(root, bg="#15171c")
        r1.pack(fill="x", padx=20, pady=4)
        self.b1 = tk.Button(r1, text="② Choose  slice1  PNG", font=f, anchor="w",
                            command=self.pick1, bg="#22252c", fg="#d6d8de",
                            activebackground="#2c2f38", relief="flat", padx=12, pady=8)
        self.b1.pack(side="left", fill="x", expand=True)
        self.thumb1 = tk.Label(r1, bg="#15171c", bd=1, relief="flat")
        self.thumb1.pack(side="left", padx=(6, 0))
        self.dl1 = tk.Button(r1, text="Download", font=("Consolas", 9),
                             command=lambda: self._download_slice(1), state="disabled",
                             bg="#2c2f38", fg="#5a5d66", activebackground="#3a3e49",
                             relief="flat", padx=10)
        self.dl1.pack(side="left", fill="y", padx=(6, 0))

        self.single = tk.BooleanVar(value=False)
        tk.Checkbutton(
            root,
            text="Single-slice texture — 1 PNG  "
                 "(banana, sodacan, grenade, harmonica, shielddrink, shieldshaker)",
            variable=self.single, command=self._toggle_single,
            bg="#15171c", fg="#9a9eaa", selectcolor="#22252c",
            activebackground="#15171c", font=f, wraplength=560, justify="left",
            anchor="w").pack(anchor="w", fill="x", padx=20, pady=(2, 0))

        nm = tk.Frame(root, bg="#15171c")
        nm.pack(fill="x", padx=20, pady=(6, 2))
        tk.Label(nm, text="Name this skin (creates its own folder):",
                 bg="#15171c", fg="#9a9eaa", font=f).pack(anchor="w")
        self.name_var = tk.StringVar()
        tk.Entry(nm, textvariable=self.name_var, font=("Consolas", 10),
                 bg="#22252c", fg="#d6d8de", insertbackground="#fff",
                 relief="flat").pack(fill="x", ipady=5, pady=(3, 0))

        self.swap = tk.BooleanVar()
        self.swap_cb = tk.Checkbutton(root, text="Swap slice order (fix: art on wrong parts)",
                                      variable=self.swap, bg="#15171c", fg="#9a9eaa",
                                      selectcolor="#22252c", activebackground="#15171c",
                                      font=f)
        self.swap_cb.pack(anchor="w", padx=20, pady=(2, 0))

        self.repack = tk.BooleanVar(value=True)
        tk.Checkbutton(root, text="Repack bundle automatically (skip UABEA)",
                       variable=self.repack, bg="#15171c", fg="#9a9eaa",
                       selectcolor="#22252c", activebackground="#15171c",
                       font=f).pack(anchor="w", padx=20, pady=(0, 8))

        self.start = tk.Button(root, text="START", font=("Consolas", 13, "bold"),
                               command=self.go, bg=accent, fg="#000",
                               activebackground="#ffbf63", relief="flat", pady=10)
        self.start.pack(fill="x", padx=20, pady=(4, 2))

        tk.Button(root, text="Open UABEA ↗", font=f, command=self.open_uabea,
                  bg="#22252c", fg="#d6d8de", activebackground="#2c2f38",
                  relief="flat", pady=6).pack(fill="x", padx=20, pady=(0, 4))

        self.log = tk.Text(root, bg="#000", fg="#8b8f9a", insertbackground="#fff",
                           font=("Consolas", 9), relief="flat", height=15,
                           wrap="word", padx=10, pady=8)
        self.log.pack(fill="both", expand=True, padx=20, pady=12)
        self.log.tag_config("ok", foreground="#7fe787")
        self.log.tag_config("er", foreground="#ff6b6b")

        self.refresh_status()
        self._reload_library()
        self._log(f"SkinSwapper v{VERSION}  ·  by {AUTHOR}  ·  (c) {YEAR} {AUTHOR}", "ok")
        self._log("Ready. Pick both PNGs, then press START.")
        self._log("Tip: ⚙ Settings holds your paths, texture spec, and license key.")

        saved_key = (self.cfg.get("license_key") or "").strip()
        if LICENSE_URL and not saved_key:
            # First run with the kill-switch on: show the blocking Terms+key gate.
            self.root.after(60, lambda: LicenseGate(self.root, self.cfg, self._post_gate))
        elif LICENSE_URL and saved_key:
            # Reopen: verify the device EVERY launch. If it isn't verified, the
            # gate comes back (locked) so a saved key can't bypass activation.
            threading.Thread(target=self._verify_or_gate, daemon=True).start()
        else:
            threading.Thread(target=self._startup_checks, args=(True,), daemon=True).start()

    def _verify_or_gate(self):
        ok, msg, code = check_license(self.cfg)

        def decide():
            self._log("license: " + msg, "ok" if ok else "er")
            if ok:
                threading.Thread(target=self._startup_checks,
                                 args=(False,), daemon=True).start()
            else:
                LicenseGate(self.root, self.cfg, self._post_gate,
                            locked_info=(msg, code))
        self.root.after(0, decide)

    def _post_gate(self):
        self.refresh_status()
        self._log("license: verified — welcome.", "ok")
        threading.Thread(target=self._startup_checks, args=(False,), daemon=True).start()

    def _startup_checks(self, do_license):
        if do_license and LICENSE_URL:
            ok, msg, _ = check_license(self.cfg)
            self.root.after(0, self._log, "license: " + msg, ("ok" if ok else "er"))
        upd = check_update(self.cfg)
        if upd:
            self.root.after(0, self._notify_update, upd[0], upd[1])

    def _notify_update(self, latest, url):
        self._log(f"UPDATE AVAILABLE: v{latest}  (you have v{VERSION})", "ok")
        if url:
            self._log(f"  download: {url}", "ok")
        messagebox.showinfo(
            "Update available",
            f"A newer version (v{latest}) is available.\nYou have v{VERSION}."
            + (f"\n\nDownload:\n{url}" if url else ""))

    # -- status / settings --
    def refresh_status(self):
        s = self.cfg["spec"]
        self.spec_lbl.config(
            text=f"{s['name']} · {s['texconv_fmt']} · {s['width']}x{s['height']} · {s['slices']} slices")
        self.bundle_name_lbl.config(text=s.get("bundle_name", "(set in Settings)"))
        tc = bool(self.cfg["texconv_path"] and os.path.exists(self.cfg["texconv_path"]))
        bd = bool(self.cfg.get("bundle_path") and os.path.exists(self.cfg["bundle_path"]))
        rs = bool(self.cfg.get("clean_ress_path") and os.path.exists(self.cfg["clean_ress_path"]))
        src = bd or rs
        ok = tc and src
        if ok:
            txt = "✓ texconv + clean source detected" + (" (bundle)" if bd else " (.resS)")
        else:
            need = ([] if tc else ["texconv.exe"]) + \
                   ([] if src else ["original bundle or clean .resS"])
            txt = "⚠ set " + " & ".join(need) + " in Settings"
        self.status.config(text=txt, fg=("#7fe787" if ok else "#ff6b6b"))

    def open_settings(self):
        Settings(self.root, self.cfg, self.refresh_status)

    def open_terms(self):
        w = tk.Toplevel(self.root)
        w.title("Terms of Use")
        w.configure(bg="#15171c")
        w.resizable(False, False)
        box = tk.Text(w, bg="#0e0f12", fg="#c7cad1", font=("Consolas", 9),
                      relief="flat", wrap="word", width=74, height=24,
                      padx=10, pady=8)
        box.insert("1.0", TERMS)
        box.config(state="disabled")
        box.pack(padx=16, pady=12)
        tk.Button(w, text="Close", font=("Consolas", 10), command=w.destroy,
                  bg="#22252c", fg="#d6d8de", relief="flat", padx=12, pady=4
                  ).pack(pady=(0, 12))
        w.transient(self.root)

    def open_contact(self):
        w = tk.Toplevel(self.root)
        w.title("Contact")
        w.configure(bg="#15171c")
        w.resizable(False, False)
        tk.Label(w, text="Questions, feedback, or access requests:",
                 bg="#15171c", fg="#9a9eaa",
                 font=("Consolas", 10)).pack(padx=18, pady=(16, 6))
        e = tk.Entry(w, font=("Consolas", 11), bg="#22252c", fg="#d6d8de",
                     relief="flat", justify="center")
        e.insert(0, CONTACT_EMAIL)
        e.config(state="readonly")
        e.pack(fill="x", padx=18, ipady=5)
        row = tk.Frame(w, bg="#15171c")
        row.pack(pady=12)
        tk.Button(row, text="Copy email", font=("Consolas", 10),
                  command=lambda: (self.root.clipboard_clear(),
                                   self.root.clipboard_append(CONTACT_EMAIL)),
                  bg="#22252c", fg="#ffae3b", relief="flat", padx=12, pady=4
                  ).pack(side="left", padx=4)
        tk.Button(row, text="Close", font=("Consolas", 10), command=w.destroy,
                  bg="#22252c", fg="#d6d8de", relief="flat", padx=12, pady=4
                  ).pack(side="left", padx=4)
        w.transient(self.root)

    def copy_bundle_name(self):
        name = self.cfg["spec"].get("bundle_name", "")
        if name:
            self.root.clipboard_clear()
            self.root.clipboard_append(name)
            self._log(f"copied bundle name: {name}", "ok")

    def _reload_library(self):
        names = scan_library()
        menu = self.lib_menu["menu"]
        menu.delete(0, "end")
        if not names:
            self.library_var.set("(no Library folder found)")
            self._log("Library: no 'Library' folder next to the app.", "er")
            return
        for n in names:
            menu.add_command(label=n, command=lambda v=n: self._select_library(v))
        self._log(f"Library: {len(names)} item(s) available.", "ok")

    def _select_library(self, name):
        self.library_var.set(name)
        bundle, ress = library_files(name)
        if bundle:
            self.cfg["bundle_path"] = bundle
            self.cfg["spec"]["bundle_name"] = os.path.basename(bundle)
        if ress:
            self.cfg["clean_ress_path"] = ress
            self.cfg["spec"]["ress_name"] = os.path.basename(ress)
        save_settings(self.cfg)
        self.refresh_status()
        if not bundle:
            self._log(f"Library: '{name}' has no .bundle inside it.", "er")
            return
        self._log(f"Library: loaded '{name}' — reading texture spec from bundle…")
        threading.Thread(target=self._autodetect_worker,
                         args=(name, bundle), daemon=True).start()

    def _autodetect_worker(self, name, bundle):
        log = lambda m, t=None: self.root.after(0, self._log, m, t)
        spec = detect_spec_from_bundle(bundle, log)

        # Load the reference textures (split + flipped) off the UI thread.
        eff = dict(self.cfg["spec"])
        if spec:
            eff.update(spec)
        ref0 = ref1 = None
        if HAVE_PIL:
            try:
                ref0, ref1 = reference_textures(name, eff)
            except Exception as e:
                log(f"  reference: couldn't load textures/{name} ({e})")

        def apply():
            if spec:
                self.cfg["spec"].update(spec)
                save_settings(self.cfg)
                self.refresh_status()
                s = self.cfg["spec"]
                self.single.set(s.get("slices", 2) == 1)
                self._toggle_single()
                self._log(f"auto-detect ✓  {s.get('name')} · {s['texconv_fmt']} · "
                          f"offset {s['stream_offset']} · {s['total']:,} bytes"
                          + ("  · single-slice" if self.single.get() else ""), "ok")
            else:
                self._log("auto-detect: couldn't read the spec automatically — "
                          "set format/offset in Settings if the result looks wrong.", "er")
            self._set_references(ref0, ref1)
        self.root.after(0, apply)

    def open_uabea(self):
        path = self.cfg.get("uabea_path", "")
        if not path or not os.path.exists(path):
            path = find_uabea(app_dir())          # try auto-detect again
            if path:
                self.cfg["uabea_path"] = path
                save_settings(self.cfg)
        if not path or not os.path.exists(path):   # last resort: ask
            p = filedialog.askopenfilename(
                title="Find UABEAvalonia.exe",
                filetypes=[("UABEA", "UABEAvalonia.exe"), ("All files", "*.*")])
            if p:
                self.cfg["uabea_path"] = p
                save_settings(self.cfg)
                path = p
        if not path or not os.path.exists(path):
            self._log("UABEA not found. Put it in a 'UABEA' subfolder next to "
                      "this app, or pick it in Settings.", "er")
            return
        try:
            if os.name == "nt":
                os.startfile(path)
            else:
                subprocess.Popen([path])
            self._log(f"opened UABEA: {os.path.basename(path)}", "ok")
        except Exception as e:
            self._log(f"couldn't open UABEA: {e}", "er")

    # -- reference textures (preview + download) --
    def _set_references(self, ref0, ref1):
        self._ref0, self._ref1 = ref0, ref1
        self._show_thumb(self.thumb0, self.dl0, ref0, 0)
        self._show_thumb(self.thumb1, self.dl1, ref1, 1)
        if ref0 is not None:
            self._log("reference texture loaded — preview + Download ready.", "ok")

    def _show_thumb(self, label, dlbtn, img, idx=0):
        if img is None or not HAVE_PIL:
            label.config(image="", text="", cursor="")
            label.image = None
            label.unbind("<Button-1>")
            dlbtn.config(state="disabled", fg="#5a5d66")
            return
        t = img.copy()
        t.thumbnail((72, 72))
        ph = ImageTk.PhotoImage(t)
        label.config(image=ph, cursor="hand2")
        label.image = ph                       # keep a ref so it isn't GC'd
        label.bind("<Button-1>", lambda e, i=idx: self._preview_slice(i))
        dlbtn.config(state="normal", fg="#d6d8de")

    def _preview_slice(self, idx):
        """Open a larger preview window for the reference texture slice."""
        img = self._ref0 if idx == 0 else self._ref1
        if img is None or not HAVE_PIL:
            return
        wname = self.library_var.get().strip() or "weapon"
        win = tk.Toplevel(self.root)
        win.title(f"{wname} — slice{idx} preview")
        win.configure(bg="#15171c")
        win.resizable(False, False)

        # scale to fit nicely on screen (512px or smaller if the image is small)
        preview = img.copy()
        preview.thumbnail((512, 512))
        ph = ImageTk.PhotoImage(preview)

        lbl = tk.Label(win, image=ph, bg="#15171c", bd=0)
        lbl.image = ph
        lbl.pack(padx=8, pady=8)

        tk.Label(win, text=f"slice{idx}  ·  {img.size[0]}×{img.size[1]}  ·  click to close",
                 bg="#15171c", fg="#9a9eaa", font=("Consolas", 9)).pack(pady=(0, 8))

        win.bind("<Button-1>", lambda e: win.destroy())
        win.bind("<Escape>", lambda e: win.destroy())
        win.transient(self.root)
        win.grab_set()
        win.focus_force()

    def _download_slice(self, idx):
        img = self._ref0 if idx == 0 else self._ref1
        if img is None:
            self._log("No reference texture available for that slice.", "er")
            return
        wname = self.library_var.get().strip() or "weapon"
        p = filedialog.asksaveasfilename(
            title=f"Save slice{idx} reference",
            defaultextension=".png", initialfile=f"{wname}_slice{idx}.png",
            filetypes=[("PNG", "*.png")])
        if not p:
            return
        try:
            img.save(p)
            self._log(f"saved reference slice{idx} -> {p}", "ok")
        except Exception as e:
            self._log(f"couldn't save: {e}", "er")

    # -- pickers --
    def pick0(self):
        p = filedialog.askopenfilename(filetypes=[("PNG", "*.png")])
        if p:
            self.png0 = p
            label = "① texture:  " if self.single.get() else "① slice0:  "
            self.b0.config(text=label + os.path.basename(p), fg="#7fe787")

    def pick1(self):
        p = filedialog.askopenfilename(filetypes=[("PNG", "*.png")])
        if p:
            self.png1 = p
            self.b1.config(text="② slice1:  " + os.path.basename(p), fg="#7fe787")

    def _toggle_single(self):
        """One PNG vs two: disable slice1 + slice-swap when single-slice is on."""
        if self.single.get():
            self.b1.config(state="disabled", fg="#5a5d66",
                           text="② (not needed — single-slice)")
            self.swap_cb.config(state="disabled")
            self.dl1.config(state="disabled", fg="#5a5d66")
            self.thumb1.config(image="", text="")
            self.thumb1.image = None
            if not self.png0:
                self.b0.config(text="① Choose  texture  PNG")
        else:
            self.b1.config(
                state="normal",
                fg="#7fe787" if self.png1 else "#d6d8de",
                text=("② slice1:  " + os.path.basename(self.png1))
                if self.png1 else "② Choose  slice1  PNG")
            self.swap_cb.config(state="normal")
            self._show_thumb(self.thumb1, self.dl1, self._ref1, 1)
            if not self.png0:
                self.b0.config(text="① Choose  slice0  PNG")

    def _log(self, msg, tag=None):
        self.log.insert("end", msg + "\n", tag or ())
        self.log.see("end")

    def go(self):
        single = self.single.get()
        if single and not self.png0:
            self._log("Pick the PNG first.", "er")
            return
        if not single and not (self.png0 and self.png1):
            self._log("Pick BOTH PNGs first.", "er")
            return
        if not self.name_var.get().strip():
            self._log("Enter a name for this skin first.", "er")
            return
        self.start.config(state="disabled", text="WORKING…")
        self.log.delete("1.0", "end")
        cfg, png0, png1, swap = self.cfg, self.png0, self.png1, self.swap.get()
        do_repack = self.repack.get()
        create_name = self.name_var.get()

        def worker():
            ok, msg, _ = check_license(cfg)
            self.root.after(0, self._log, "license: " + msg, ("ok" if ok else "er"))
            if not ok:
                self.root.after(0, lambda: self.start.config(state="normal", text="START"))
                return
            try:
                run_pipeline(cfg, png0, png1, swap, do_repack, single, create_name,
                             lambda m, t=None: self.root.after(0, self._log, m, t))
            except SwapError as e:
                self.root.after(0, self._log, "ERROR: " + str(e), "er")
            except Exception:
                self.root.after(0, self._log, "UNEXPECTED:\n" + traceback.format_exc(), "er")
            finally:
                self.root.after(0, lambda: self.start.config(state="normal", text="START"))

        threading.Thread(target=worker, daemon=True).start()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
