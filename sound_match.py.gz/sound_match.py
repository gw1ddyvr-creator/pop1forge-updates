# =============================================================================
#  sound_match.py  -  POP-1 Skin Forge  -  match a replacement to the original
#  Copyright (c) 2026 GW1DDY. All rights reserved.
#
#  The game plays every sound through an FMOD event + bus chain (compressor /
#  limiter / EQ / ducking) that lives in the FMOD Studio project, which is NOT
#  shipped in the bank — so we can't replay it exactly. What we CAN do is match
#  a replacement to the ORIGINAL game sample for that slot: the original is the
#  clip BigBox tuned to sit right through that chain, so matching its loudness
#  and tonal balance is the effective way to make a replacement "sound right".
#
#  analyze() -> loudness (RMS), peak, and a low/mid/high tone split + centroid.
#  match()   -> the source re-leveled to the original's loudness and (optionally)
#               tone-matched with a limited linear-phase EQ toward the original.
#
#  Pure numpy. No extra dependencies.
# =============================================================================

import numpy as np


def _to_mono_float(pcm, chans):
    a = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
    if chans > 1:
        a = a.reshape(-1, chans).mean(axis=1)
    return a


def _channels_float(pcm, chans):
    a = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
    if chans > 1:
        a = a.reshape(-1, chans)
    else:
        a = a.reshape(-1, 1)
    return a


def _db(x):
    return float(20.0 * np.log10(max(float(x), 1e-9)))


def _avg_mag(x, nfft=2048):
    """Average magnitude spectrum (rfft) over Hann windows."""
    if x.size < nfft:
        return np.abs(np.fft.rfft(x, nfft))
    hop = nfft // 2
    win = np.hanning(nfft).astype(np.float32)
    frames = 1 + (x.size - nfft) // hop
    acc = np.zeros(nfft // 2 + 1, dtype=np.float64)
    for i in range(frames):
        seg = x[i * hop:i * hop + nfft] * win
        acc += np.abs(np.fft.rfft(seg))
    return acc / max(1, frames)


def analyze(pcm, freq, chans):
    """Return loudness / peak / tone metrics for an interleaved PCM16 clip."""
    x = _to_mono_float(pcm, chans)
    n = x.size
    if n == 0:
        return {"seconds": 0, "rms_db": -120.0, "peak_db": -120.0,
                "centroid_hz": 0, "sub": 0, "low": 0, "mid": 0, "high": 0}
    rms = float(np.sqrt(np.mean(x * x) + 1e-12))
    peak = float(np.max(np.abs(x)) + 1e-12)
    mag = _avg_mag(x)
    freqs = np.fft.rfftfreq(2 * (len(mag) - 1), 1.0 / freq)
    e = mag * mag
    tot = float(e.sum()) + 1e-12
    sub = float(e[freqs < 150].sum()) / tot        # deep sub-bass (VR speakers can't)
    low = float(e[freqs < 500].sum()) / tot
    high = float(e[freqs > 4000].sum()) / tot
    mid = max(0.0, 1.0 - low - high)
    centroid = float((freqs * e).sum() / tot)
    return {"seconds": round(n / float(freq), 3),
            "rms_db": round(_db(rms), 1),
            "peak_db": round(_db(peak), 1),
            "centroid_hz": int(centroid),
            "sub": round(sub, 3),
            "low": round(low, 3), "mid": round(mid, 3), "high": round(high, 3)}


def _match_eq_fir(src_mono, ref_mono, nfft=2048, max_db=12.0):
    """Linear-phase FIR whose magnitude nudges src's average spectrum toward
    ref's, normalized to unity broadband gain and limited to +/- max_db."""
    S = _avg_mag(src_mono, nfft)
    R = _avg_mag(ref_mono, nfft)
    S = np.maximum(S, S.max() * 1e-4 + 1e-9)
    R = np.maximum(R, R.max() * 1e-4 + 1e-9)
    ratio = R / S
    ratio /= np.median(ratio)                       # loudness handled separately
    lim = 10.0 ** (max_db / 20.0)
    ratio = np.clip(ratio, 1.0 / lim, lim)
    k = 5                                            # smooth in frequency
    ratio = np.convolve(ratio, np.ones(k) / k, mode="same")
    ir = np.fft.irfft(ratio, nfft)                  # zero-phase -> symmetric
    ir = np.fft.fftshift(ir) * np.hanning(nfft)     # -> linear phase, windowed
    return ir.astype(np.float32)


def match(src_pcm, ref_pcm, freq, chans, do_eq=True, max_db=12.0):
    """Re-level src to ref's loudness and (optionally) tone-match toward ref.

    Returns (matched_pcm_bytes, info). matched keeps src's channel count.
    """
    src = _channels_float(src_pcm, chans)
    ref_mono = _to_mono_float(ref_pcm, chans)
    src_mono = src.mean(axis=1)

    info = {"eq_applied": False, "gain_db": 0.0, "peak_after_db": 0.0}

    y = src.copy()
    if do_eq and src_mono.size > 32 and ref_mono.size > 32:
        ir = _match_eq_fir(src_mono, ref_mono)
        for c in range(y.shape[1]):
            y[:, c] = np.convolve(y[:, c], ir, mode="same")
        info["eq_applied"] = True

    # loudness match to the original's RMS
    ref_rms = float(np.sqrt(np.mean(ref_mono * ref_mono) + 1e-12))
    cur_rms = float(np.sqrt(np.mean(y.mean(axis=1) ** 2) + 1e-12))
    gain = ref_rms / max(cur_rms, 1e-9)
    y *= gain
    info["gain_db"] = round(_db(gain), 1)

    # peak safety (never clip)
    peak = float(np.max(np.abs(y)) + 1e-12)
    if peak > 0.997:
        y *= 0.997 / peak
    info["peak_after_db"] = round(_db(np.max(np.abs(y)) + 1e-12), 1)

    y = np.clip(y, -1.0, 1.0)
    out = (y.reshape(-1) * 32767.0).astype("<i2").tobytes()
    return out, info


def compare(src_pcm, ref_pcm, freq, chans):
    """Analysis of source vs reference + a plain-language diff for the UI."""
    a_src = analyze(src_pcm, freq, chans)
    a_ref = analyze(ref_pcm, freq, chans)
    dl = round(a_src["rms_db"] - a_ref["rms_db"], 1)          # +=louder than orig
    tone = a_src["centroid_hz"] - a_ref["centroid_hz"]
    tone_txt = ("brighter" if tone > 400 else
                "darker" if tone < -400 else "similar tone")
    loud_txt = ("louder" if dl > 1 else "quieter" if dl < -1 else "same loudness")
    return {"source": a_src, "original": a_ref,
            "loudness_delta_db": dl, "loud_txt": loud_txt,
            "centroid_delta_hz": tone, "tone_txt": tone_txt,
            "length_ratio": round((a_src["seconds"] / a_ref["seconds"]) if a_ref["seconds"] else 0, 2)}


def slot_warnings(src_pcm, ref_pcm, freq, chans):
    """Plain-English heads-up when a replacement sits very differently from the
    slot's ORIGINAL sound (the clip BigBox tuned to survive the game's event/bus
    DSP). Returns a list of short warning strings, most important first; empty if
    the replacement is a reasonable fit. Never raises."""
    out = []
    try:
        a = analyze(src_pcm, freq, chans)
        r = analyze(ref_pcm, freq, chans)
    except Exception:
        return out
    # Deep sub-bass pile-up (the AWP case): energy stacked <150 Hz barely
    # reproduces on VR headset speakers and gets clamped by the gun's bus
    # limiter, so it reads as "bass missing" in-game even though the file keeps
    # it. Flag only when it's both high AND well above the original's share.
    if a["sub"] > 0.40 and a["sub"] > r["sub"] * 2.0 + 0.05:
        mult = a["sub"] / max(r["sub"], 0.01)
        out.append("This clip is %.0f%% deep sub-bass (under 150 Hz) vs %.0f%% on "
                   "the original — about %.1f× as much. Deep sub barely "
                   "plays on VR headset speakers and gets clamped by the gun's "
                   "built-in compressor, so it can sound thin in-game. Shift the "
                   "weight up to 150–500 Hz, or use ⚖ Match to original."
                   % (a["sub"] * 100, r["sub"] * 100, mult))
    # Loudness far from the original -> the game's limiter reacts differently.
    dl = a["rms_db"] - r["rms_db"]
    if dl > 6:
        out.append("About %.0f dB louder than the original — the game's "
                   "limiter may squash it. ⚖ Match to original evens this out."
                   % dl)
    elif dl < -8:
        out.append("About %.0f dB quieter than the original — it may be hard "
                   "to hear next to other guns." % (-dl))
    # Brightness far off (only when not already flagged for sub-bass).
    if not out or "sub-bass" not in out[0]:
        dc = a["centroid_hz"] - r["centroid_hz"]
        if dc < -1500:
            out.append("Much darker than the original (less high end) — may "
                       "sound muffled in-game.")
        elif dc > 3000:
            out.append("Much brighter/harsher than the original.")
    return out


# ---- self-test --------------------------------------------------------------
def _selftest():
    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import fmod_bank as fb
    b = fb.Bank(os.path.join(fb.GAME_SA, "Item.assets.bank"))
    s = b.fsb.samples[449]                                    # RifleAWP_Firing_01
    orig = b.fsb.sample_audio(449)
    ref_mono = _to_mono_float(orig, s.chans)

    # fabricate a "user clip": original made quieter + darkened (lowpass tilt)
    x = _channels_float(orig, s.chans)
    ir = np.zeros(101, dtype=np.float32); ir[50] = 1.0        # darken: crude LPF
    lp = np.convolve(np.ones(21) / 21, [1], mode="full")
    xd = x.copy()
    for c in range(xd.shape[1]):
        xd[:, c] = np.convolve(xd[:, c], np.ones(15) / 15, mode="same")   # muffle highs
    xd *= 0.35                                                # quieter
    user = (xd.reshape(-1) * 32767).astype("<i2").tobytes()

    cmp0 = compare(user, orig, s.freq, s.chans)
    matched, info = match(user, orig, s.freq, s.chans, do_eq=True)
    cmp1 = compare(matched, orig, s.freq, s.chans)

    print("sample:", s.name, "chans", s.chans, "freq", s.freq)
    print("BEFORE  loudness d=%+.1f dB  tone d=%+d Hz (%s / %s)"
          % (cmp0["loudness_delta_db"], cmp0["centroid_delta_hz"], cmp0["loud_txt"], cmp0["tone_txt"]))
    print("applied gain=%+.1f dB  eq=%s  peak_after=%.1f dB"
          % (info["gain_db"], info["eq_applied"], info["peak_after_db"]))
    print("AFTER   loudness d=%+.1f dB  tone d=%+d Hz (%s / %s)"
          % (cmp1["loudness_delta_db"], cmp1["centroid_delta_hz"], cmp1["loud_txt"], cmp1["tone_txt"]))
    ok = abs(cmp1["loudness_delta_db"]) < 1.0 and abs(cmp1["centroid_delta_hz"]) < abs(cmp0["centroid_delta_hz"])
    print("MATCH IMPROVED:", ok)


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print("sound_match: analyze / match / compare a replacement vs the original.")
