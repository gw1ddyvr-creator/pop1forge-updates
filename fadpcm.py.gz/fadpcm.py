# =============================================================================
#  fadpcm.py  -  POP-1 Skin Forge  -  FMOD FADPCM codec (decode + encode)
#  Copyright (c) 2026 GW1DDY. All rights reserved.
#
#  FADPCM is FMOD's own ADPCM. Every Population: ONE bank except the weapons
#  bank (which is PCM16) stores its audio as FADPCM: music, loading, the Social
#  Hub / night-club, environment ambience, characters, UI, dialogue, VO.
#
#  Format (verified byte-exact against the game's own fmod.dll):
#    - data is a stream of 0x8c (140)-byte frames, 256 samples each, per channel
#    - multi-channel is frame-interleaved:  ch0 f0 | ch1 f0 | ch0 f1 | ch1 f1 ...
#    - frame header (12 bytes):
#         0x00 u32  coefficient index per sub-block  (8 x 4-bit)
#         0x04 u32  shift value per sub-block        (8 x 4-bit)
#         0x08 s16  history sample 1 (entering the frame)
#         0x0a s16  history sample 2
#      then 8 sub-blocks x 16 bytes = 8 x (4 x u32) = 8 x 32 nibbles = 256 samples
#    - decode per sample:  raw = signext4(nib) << (6 + shift_index)
#                          out = clamp16( (raw + h1*c1 - h2*c2) >> 6 )
#                          h2 = h1 ; h1 = out
#
#  DECODE matches fmod.dll exactly (max abs diff 0 on real banks, mono + stereo).
#  ENCODE round-trips through fmod.dll at ~41 dB SNR (the same quality the game
#  ships) — i.e. the game engine loads and plays sounds this module writes.
#  See  python fadpcm.py --selftest  (needs the game install + fmod_toolkit).
# =============================================================================

import struct

FRAME = 0x8c                 # 140 bytes
SAMPLES_PER_FRAME = 256
SUBBLOCK = 32
# coefficient pairs (c1, c2); only indices 0..4 are used by the encoder
COEF = [(0, 0), (60, 0), (122, 60), (115, 52), (98, 55), (0, 0), (0, 0), (0, 0)]


def _clamp16(x):
    return -32768 if x < -32768 else (32767 if x > 32767 else x)


# ---- decode -----------------------------------------------------------------
def _decode_frame(data, base, out):
    coefs = struct.unpack_from("<I", data, base)[0]
    shifts = struct.unpack_from("<I", data, base + 4)[0]
    h1 = struct.unpack_from("<h", data, base + 8)[0]
    h2 = struct.unpack_from("<h", data, base + 10)[0]
    for sub in range(8):
        ci = (coefs >> (sub * 4)) & 0xF
        si = (shifts >> (sub * 4)) & 0xF
        c1, c2 = COEF[ci % 7] if ci < 8 else (0, 0)
        shift = 22 - si
        for w in range(4):
            word = struct.unpack_from("<I", data, base + 0x0C + sub * 16 + w * 4)[0]
            for n in range(8):
                nib = (word >> (n * 4)) & 0xF
                s = nib << 28
                if s & 0x80000000:
                    s -= 0x100000000
                s = s >> shift
                s = (s + h1 * c1 - h2 * c2) >> 6
                s = _clamp16(s)
                out.append(s)
                h2 = h1
                h1 = s


def decode(data, channels, nsamp):
    """FADPCM bytes -> interleaved PCM16 bytes (channels, nsamp per channel)."""
    nframes = (nsamp + SAMPLES_PER_FRAME - 1) // SAMPLES_PER_FRAME
    if channels == 1:
        out = []
        for f in range(nframes):
            _decode_frame(data, f * FRAME, out)
        pcm = out[:nsamp]
        return struct.pack("<%dh" % len(pcm), *pcm)
    chans = [[] for _ in range(channels)]
    for f in range(nframes):
        for c in range(channels):
            _decode_frame(data, (f * channels + c) * FRAME, chans[c])
    inter = []
    for i in range(nsamp):
        for c in range(channels):
            inter.append(chans[c][i])
    return struct.pack("<%dh" % len(inter), *inter)


# ---- encode -----------------------------------------------------------------
def _enc_subblock(blk, h1, h2):
    """Encode 32 samples. Returns (coef_index, shift_index, nibbles[32], h1, h2)."""
    # pick the coefficient set with the lowest open-loop residual energy
    best_ci = 0
    best_energy = None
    for ci in range(5):
        c1, c2 = COEF[ci]
        a1, a2 = h1, h2
        energy = 0
        for t in blk:
            r = t * 64 - (a1 * c1 - a2 * c2)
            energy += r * r
            a2 = a1
            a1 = t
        if best_energy is None or energy < best_energy:
            best_energy = energy
            best_ci = ci
    c1, c2 = COEF[best_ci]
    # shift estimate from the residual magnitude
    a1, a2 = h1, h2
    rmax = 0
    for t in blk:
        r = abs(t * 64 - (a1 * c1 - a2 * c2))
        if r > rmax:
            rmax = r
        a2 = a1
        a1 = t
    est = 0
    while est < 15 and (7 << (6 + est)) < rmax:
        est += 1
    # closed-loop quantize; try a couple of shifts and keep the best
    best = None
    for si in {max(0, est - 1), est, min(15, est + 1)}:
        step = 1 << (6 + si)
        hh1, hh2 = h1, h2
        nibs = []
        err = 0
        for t in blk:
            pred = hh1 * c1 - hh2 * c2
            q = int(round((t * 64 - pred) / step))
            if q > 7:
                q = 7
            elif q < -8:
                q = -8
            dec = _clamp16(((q * step) + pred) >> 6)
            d = dec - t
            err += d * d
            nibs.append(q & 0xF)
            hh2 = hh1
            hh1 = dec
        if best is None or err < best[0]:
            best = (err, si, nibs, hh1, hh2)
    _, si, nibs, h1, h2 = best
    return best_ci, si, nibs, h1, h2


def _enc_channel(samples):
    """int list -> list of 0x8c-byte frames."""
    frames = []
    h1 = h2 = 0
    n = len(samples)
    nfr = (n + SAMPLES_PER_FRAME - 1) // SAMPLES_PER_FRAME
    for f in range(nfr):
        frame = samples[f * 256:(f + 1) * 256]
        if len(frame) < 256:
            frame = list(frame) + [0] * (256 - len(frame))
        fh1, fh2 = h1, h2                    # history entering this frame
        cp = sp = 0
        nib = [0] * 256
        hh1, hh2 = h1, h2
        for sub in range(8):
            ci, si, nibs, hh1, hh2 = _enc_subblock(frame[sub * 32:(sub + 1) * 32], hh1, hh2)
            cp |= (ci & 0xF) << (sub * 4)
            sp |= (si & 0xF) << (sub * 4)
            nib[sub * 32:(sub + 1) * 32] = nibs
        h1, h2 = hh1, hh2
        fr = bytearray(FRAME)
        struct.pack_into("<I", fr, 0, cp)
        struct.pack_into("<I", fr, 4, sp)
        struct.pack_into("<h", fr, 8, _clamp16(fh1))
        struct.pack_into("<h", fr, 10, _clamp16(fh2))
        for sub in range(8):
            for w in range(4):
                word = 0
                for k in range(8):
                    word |= (nib[sub * 32 + w * 8 + k] & 0xF) << (k * 4)
                struct.pack_into("<I", fr, 0x0C + sub * 16 + w * 4, word)
        frames.append(bytes(fr))
    return frames


def encode(pcm16, channels):
    """Interleaved PCM16 bytes -> FADPCM bytes (frame-interleaved per channel)."""
    samples = list(struct.unpack("<%dh" % (len(pcm16) // 2), pcm16))
    if channels == 1:
        return b"".join(_enc_channel(samples))
    chans = [samples[c::channels] for c in range(channels)]
    fr = [_enc_channel(c) for c in chans]
    out = bytearray()
    for f in range(len(fr[0])):
        for c in range(channels):
            out += fr[c][f]
    return bytes(out)


def encoded_size(nsamp, channels):
    """Deterministic FADPCM byte length for nsamp frames per channel."""
    return ((nsamp + SAMPLES_PER_FRAME - 1) // SAMPLES_PER_FRAME) * FRAME * channels


# ---- self-test --------------------------------------------------------------
def _selftest():
    import os, sys, wave, io, tempfile
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import fmod_bank as fb
    import math

    def ref_pcm(bank, idx):
        w = wave.open(io.BytesIO(fb.sample_to_wav(bank, idx)), "rb")
        return w.readframes(w.getnframes()), w.getnchannels()

    def snr(a, b):
        aa = struct.unpack("<%dh" % (len(a) // 2), a)
        bb = struct.unpack("<%dh" % (len(b) // 2), b)
        m = min(len(aa), len(bb))
        sig = sum(x * x for x in aa[:m])
        noise = sum((aa[i] - bb[i]) ** 2 for i in range(m))
        if noise == 0:
            return float("inf")
        return 10 * math.log10(sig / noise) if sig else 0.0

    for bankname, want in [("Character.assets.bank", 1), ("SocialHub.assets.bank", 2)]:
        b = fb.Bank(os.path.join(fb.GAME_SA, bankname))
        idx = next((s.idx for s in b.fsb.samples if s.chans == want), None)
        if idx is None:
            continue
        s = b.fsb.samples[idx]
        raw = b.fsb.sample_bytes(idx)
        # decode == fmod?
        ref, ch = ref_pcm(b, idx)
        mine = decode(raw, s.chans, s.nsamp)
        exact = (mine == ref[:len(mine)])
        print("%s[%d] %s ch%d nsamp=%d" % (bankname, idx, s.name, s.chans, s.nsamp))
        print("   decode==fmod.dll:", exact)
        # encode -> fmod decode
        enc = encode(ref, s.chans)
        need = encoded_size(s.nsamp, s.chans)
        print("   encoded_size ok:", len(enc) == need)
        buf = bytearray(b.buf)
        start = b.fsb.data_start + s.offset
        padded = enc + b"\x00" * max(0, s.datalen - len(enc))
        if len(padded) <= s.datalen:
            buf[start:start + s.datalen] = padded[:s.datalen]
            tmp = os.path.join(tempfile.gettempdir(), "_fad_" + bankname)
            open(tmp, "wb").write(buf)
            b2 = fb.Bank(tmp)
            fm, _ = ref_pcm(b2, idx)
            print("   encode->fmod.dll SNR: %.1f dB (game engine accepts it)" % snr(ref, fm))
            os.unlink(tmp)


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print("FADPCM codec. Run with --selftest against the game install.")
