#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inject_skinproj.py  --  apply a SkinForge .skinproj to the AKM weapon bundle.

For every greeble you placed (stud / bar / rod / spike / ring / plate) it rebuilds
the exact shape the Forge 3D preview shows, drops it into the weapon mesh with the
correct paint slice baked onto each new vertex (UV0.z), and repacks the bundle --
reusing inject_mesh.py as the engine (byte-exact self-check + LZ4HC repack, and it
never overwrites your source bundle).

USAGE
    python inject_skinproj.py  <AKM-LOD0.bundle>  <project.skinproj.json>

Or just DOUBLE-CLICK it: it asks for both files, keeps the window open, and writes
everything to  inject_skinproj_output.txt  next to itself.

SCOPE (v1): additive greebles + per-vertex slice. Whole-part removal (hiddenParts /
hidden islands) is the next increment -- if the project has hidden parts this build
says so clearly and still applies the greebles.

REQUIRES:  inject_mesh.py in the same folder,  and  pip install UnityPy
"""
import os
import sys
import json
import math
import traceback

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(SCRIPT_DIR, "inject_skinproj_output.txt")

# ----------------------------------------------------------------- vector math
def vsub(a, b): return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
def vadd(a, b): return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
def vscale(a, s): return [a[0] * s, a[1] * s, a[2] * s]
def vdot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def vcross(a, b):
    return [a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]]
def vlen(a): return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
def vnorm(a):
    l = vlen(a)
    return [a[0] / l, a[1] / l, a[2] / l] if l > 1e-12 else [0.0, 0.0, 0.0]


# ------------------------------------------ THREE.js r128 primitive generators
# Each returns (positions:list[[x,y,z]], indices:list[int]) matching three.js so
# the injected geometry is identical to the preview. Normals/UVs are recomputed
# later (the preview does the same), so we only need positions + topology here.

def geo_box(width, height, depth, ws=1, hs=1, ds=1):
    pos, idx, nOff = [], [], [0]

    def plane(u, v, w, udir, vdir, W, H, D, gX, gY):
        segW, segH = W / gX, H / gY
        Wh, Hh, Dh = W / 2, H / 2, D / 2
        gX1, gY1, cnt = gX + 1, gY + 1, 0
        for iy in range(gY1):
            y = iy * segH - Hh
            for ix in range(gX1):
                x = ix * segW - Wh
                vec = [0.0, 0.0, 0.0]
                vec[u] = x * udir
                vec[v] = y * vdir
                vec[w] = Dh
                pos.append([vec[0], vec[1], vec[2]])
                cnt += 1
        for iy in range(gY):
            for ix in range(gX):
                a = nOff[0] + ix + gX1 * iy
                b = nOff[0] + ix + gX1 * (iy + 1)
                c = nOff[0] + (ix + 1) + gX1 * (iy + 1)
                d = nOff[0] + (ix + 1) + gX1 * iy
                idx.extend([a, b, d, b, c, d])
        nOff[0] += cnt

    plane(2, 1, 0, -1, -1, depth, height, width, ds, hs)   # px
    plane(2, 1, 0, 1, -1, depth, height, -width, ds, hs)   # nx
    plane(0, 2, 1, 1, 1, width, depth, height, ws, ds)     # py
    plane(0, 2, 1, 1, -1, width, depth, -height, ws, ds)   # ny
    plane(0, 1, 2, 1, -1, width, height, depth, ws, hs)    # pz
    plane(0, 1, 2, -1, -1, width, height, -depth, ws, hs)  # nz
    return pos, idx


def geo_sphere(radius, wSeg=18, hSeg=14):
    wSeg = max(3, int(wSeg)); hSeg = max(2, int(hSeg))
    pos, grid, index = [], [], 0
    for iy in range(hSeg + 1):
        row = []; v = iy / hSeg
        for ix in range(wSeg + 1):
            u = ix / wSeg
            x = -radius * math.cos(u * 2 * math.pi) * math.sin(v * math.pi)
            y = radius * math.cos(v * math.pi)
            z = radius * math.sin(u * 2 * math.pi) * math.sin(v * math.pi)
            pos.append([x, y, z]); row.append(index); index += 1
        grid.append(row)
    idx = []
    for iy in range(hSeg):
        for ix in range(wSeg):
            a = grid[iy][ix + 1]; b = grid[iy][ix]
            c = grid[iy + 1][ix]; d = grid[iy + 1][ix + 1]
            if iy != 0:
                idx.extend([a, b, d])
            if iy != hSeg - 1:
                idx.extend([b, c, d])
    return pos, idx


def geo_cylinder(radiusTop, radiusBottom, height, radialSeg=20, heightSeg=1, openEnded=False):
    theta0, thetaLen = 0.0, 2 * math.pi
    pos, idx, index, halfH = [], [], [0], height / 2
    rows = []
    for y in range(heightSeg + 1):
        row = []; v = y / heightSeg
        radius = v * (radiusBottom - radiusTop) + radiusTop
        for x in range(radialSeg + 1):
            u = x / radialSeg; theta = u * thetaLen + theta0
            pos.append([radius * math.sin(theta), -v * height + halfH, radius * math.cos(theta)])
            row.append(index[0]); index[0] += 1
        rows.append(row)
    for x in range(radialSeg):
        for y in range(heightSeg):
            a = rows[y][x]; b = rows[y + 1][x]; c = rows[y + 1][x + 1]; d = rows[y][x + 1]
            idx.extend([a, b, d, b, c, d])

    def cap(top):
        r = radiusTop if top else radiusBottom
        if r == 0:
            return
        sign = 1 if top else -1
        cstart = index[0]
        for _ in range(radialSeg):
            pos.append([0.0, halfH * sign, 0.0]); index[0] += 1
        cend = index[0]
        for x in range(radialSeg + 1):
            u = x / radialSeg; theta = u * thetaLen + theta0
            pos.append([r * math.sin(theta), halfH * sign, r * math.cos(theta)]); index[0] += 1
        for x in range(radialSeg):
            c = cstart + x; i = cend + x
            if top:
                idx.extend([i, i + 1, c])
            else:
                idx.extend([i + 1, i, c])

    if not openEnded:
        if radiusTop > 0:
            cap(True)
        if radiusBottom > 0:
            cap(False)
    return pos, idx


def geo_torus(radius, tube, radialSeg=12, tubularSeg=26, arc=2 * math.pi):
    pos, idx = [], []
    for j in range(radialSeg + 1):
        for i in range(tubularSeg + 1):
            u = i / tubularSeg * arc; v = j / radialSeg * 2 * math.pi
            pos.append([(radius + tube * math.cos(v)) * math.cos(u),
                        (radius + tube * math.cos(v)) * math.sin(u),
                        tube * math.sin(v)])
    ts1 = tubularSeg + 1
    for j in range(1, radialSeg + 1):
        for i in range(1, tubularSeg + 1):
            a = ts1 * j + i - 1; b = ts1 * (j - 1) + i - 1
            c = ts1 * (j - 1) + i; d = ts1 * j + i
            idx.extend([a, b, d, b, c, d])
    return pos, idx


def rotZ(pos, ang):
    c, s = math.cos(ang), math.sin(ang)
    return [[p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2]] for p in pos]


def rotX(pos, ang):
    c, s = math.cos(ang), math.sin(ang)
    return [[p[0], p[1] * c - p[2] * s, p[1] * s + p[2] * c] for p in pos]


def base_geo(shape, size):
    if shape == 'stud':
        return geo_sphere(size * 0.5, 18, 14)
    if shape == 'bar':
        return geo_box(size * 2.0, size * 0.55, size * 0.7)
    if shape == 'rod':
        p, i = geo_cylinder(size * 0.32, size * 0.32, size * 2.0, 20)
        return rotZ(p, math.pi / 2), i
    if shape == 'spike':                                    # THREE.ConeGeometry
        return geo_cylinder(0.0, size * 0.5, size * 1.7, 18)
    if shape == 'ring':
        p, i = geo_torus(size * 0.8, size * 0.24, 12, 26)
        return rotX(p, math.pi / 2), i
    return geo_box(size * 2.0, size * 0.28, size * 1.4)     # plate / default


# --------------------------------------------------------------- shared math
def compute_vertex_normals(pos, idx):
    nrm = [[0.0, 0.0, 0.0] for _ in pos]
    for t in range(0, len(idx), 3):
        a, b, c = idx[t], idx[t + 1], idx[t + 2]
        f = vcross(vsub(pos[c], pos[b]), vsub(pos[a], pos[b]))
        for k in (a, b, c):
            nrm[k][0] += f[0]; nrm[k][1] += f[1]; nrm[k][2] += f[2]
    return [vnorm(n) for n in nrm]


def q_from_unit_vectors(vf, vt):
    r = vdot(vf, vt) + 1
    if r < 1e-6:
        r = 0
        if abs(vf[0]) > abs(vf[2]):
            x, y, z, w = -vf[1], vf[0], 0.0, r
        else:
            x, y, z, w = 0.0, -vf[2], vf[1], r
    else:
        c = vcross(vf, vt); x, y, z, w = c[0], c[1], c[2], r
    l = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    return [x / l, y / l, z / l, w / l]


def q_from_axis_angle(axis, ang):
    h = ang / 2; s = math.sin(h)
    return [axis[0] * s, axis[1] * s, axis[2] * s, math.cos(h)]


def q_mul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return [ax * bw + aw * bx + ay * bz - az * by,
            ay * bw + aw * by + az * bx - ax * bz,
            az * bw + aw * bz + ax * by - ay * bx,
            aw * bw - ax * bx - ay * by - az * bz]


def q_apply(q, v):
    x, y, z = v; qx, qy, qz, qw = q
    ix = qw * x + qy * z - qz * y
    iy = qw * y + qz * x - qx * z
    iz = qw * z + qx * y - qy * x
    iw = -qx * x - qy * y - qz * z
    return [ix * qw + iw * (-qx) + iy * (-qz) - iz * (-qy),
            iy * qw + iw * (-qy) + iz * (-qx) - ix * (-qz),
            iz * qw + iw * (-qz) + ix * (-qy) - iy * (-qx)]


def mm_tangents(n):
    up = [1.0, 0.0, 0.0] if abs(n[1]) > 0.92 else [0.0, 1.0, 0.0]
    T = vnorm(vcross(up, n)); B = vnorm(vcross(n, T))
    return T, B


def gun_radius(positions):
    xs = [p[0] for p in positions]; ys = [p[1] for p in positions]; zs = [p[2] for p in positions]
    cx = (min(xs) + max(xs)) / 2; cy = (min(ys) + max(ys)) / 2; cz = (min(zs) + max(zs)) / 2
    r2 = 0.0
    for p in positions:
        d = (p[0] - cx) ** 2 + (p[1] - cy) ** 2 + (p[2] - cz) ** 2
        if d > r2:
            r2 = d
    return math.sqrt(r2)


def uv_world_scale(positions, uv0, indices):
    """world units per UV unit -- the same median the Forge's mmComputeUvScale uses."""
    nt = len(indices) // 3
    if nt == 0:
        return 1.0
    step = max(1, nt // 400)
    samples = []
    for t in range(0, nt, step):
        a = indices[t * 3]; b = indices[t * 3 + 1]
        w = math.hypot(positions[a][0] - positions[b][0],
                       positions[a][1] - positions[b][1],
                       positions[a][2] - positions[b][2])
        u = math.hypot(uv0[a][0] - uv0[b][0], uv0[a][1] - uv0[b][1])
        if u > 1e-5 and w > 1e-6:
            samples.append(w / u)
    if not samples:
        return 1.0
    samples.sort()
    return samples[len(samples) // 2] or 1.0


def loop_subdivide(pos, idx):
    """One level of Loop subdivision on a triangle mesh (rounds/smooths it).
    pos: list of [x,y,z]; idx: flat triangle indices. Returns (new_pos, new_idx).
    Must stay identical to mmLoopSubdivide() in the Forge so preview == export."""
    from collections import defaultdict
    n = len(pos)
    tris = [(idx[i], idx[i + 1], idx[i + 2]) for i in range(0, len(idx), 3)]
    edge_opp = defaultdict(list)
    neighbors = [set() for _ in range(n)]
    for (a, b, c) in tris:
        for (u, v, w) in ((a, b, c), (b, c, a), (c, a, b)):
            edge_opp[(u, v) if u < v else (v, u)].append(w)
        neighbors[a].update((b, c)); neighbors[b].update((a, c)); neighbors[c].update((a, b))

    new_pos = [list(p) for p in pos]
    edge_index = {}
    boundary = [set() for _ in range(n)]
    for e, opp in edge_opp.items():
        a, b = e
        pa, pb = pos[a], pos[b]
        if len(opp) == 2:
            pc, pd = pos[opp[0]], pos[opp[1]]
            ep = [(3.0 * (pa[k] + pb[k]) + (pc[k] + pd[k])) / 8.0 for k in range(3)]
        else:
            ep = [(pa[k] + pb[k]) / 2.0 for k in range(3)]
            boundary[a].add(b); boundary[b].add(a)
        edge_index[e] = len(new_pos)
        new_pos.append(ep)

    for vi in range(n):
        if boundary[vi]:
            bn = list(boundary[vi])
            if len(bn) == 2:
                s = [0.0, 0.0, 0.0]
                for w in bn:
                    for k in range(3):
                        s[k] += pos[w][k]
                new_pos[vi] = [0.75 * pos[vi][k] + 0.125 * s[k] for k in range(3)]
        else:
            nb = list(neighbors[vi]); deg = len(nb)
            if not deg:
                continue
            beta = 3.0 / 16.0 if deg == 3 else 3.0 / (8.0 * deg)
            s = [0.0, 0.0, 0.0]
            for w in nb:
                for k in range(3):
                    s[k] += pos[w][k]
            new_pos[vi] = [(1.0 - deg * beta) * pos[vi][k] + beta * s[k] for k in range(3)]

    def ei(u, v):
        return edge_index[(u, v) if u < v else (v, u)]
    new_idx = []
    for (a, b, c) in tris:
        ab, bc, ca = ei(a, b), ei(b, c), ei(c, a)
        new_idx += [a, ab, ca, b, bc, ab, c, ca, bc, ab, bc, ca]
    return new_pos, new_idx


def _triangulate_loop(verts, loop, cap_normal):
    """Ear-clip a boundary loop into triangles using ONLY its own vertices (no
    centroid fan) -> fills concave / complex cross-sections cleanly. Returns a list
    of (a, b, c) global vertex-index triples wound to face cap_normal."""
    m = len(loop)
    if m < 3:
        return []
    # projection plane from the loop's own geometry (Newell) -> never degenerate for a real loop
    nx = ny = nz = 0.0
    for i in range(m):
        cur = verts[loop[i]]["Position"]
        nxt = verts[loop[(i + 1) % m]]["Position"]
        nx += (cur[1] - nxt[1]) * (cur[2] + nxt[2])
        ny += (cur[2] - nxt[2]) * (cur[0] + nxt[0])
        nz += (cur[0] - nxt[0]) * (cur[1] + nxt[1])
    if (nx * nx + ny * ny + nz * nz) < 1e-20:
        return []
    n = vnorm([nx, ny, nz])
    orient = cap_normal if (cap_normal and (cap_normal[0]**2 + cap_normal[1]**2 + cap_normal[2]**2) > 1e-12) else n
    ax = [1.0, 0.0, 0.0] if abs(n[0]) < 0.9 else [0.0, 1.0, 0.0]
    u = vnorm(vcross(n, ax))
    w = vcross(n, u)
    pts = []
    for gi in loop:
        p = verts[gi]["Position"]
        pts.append((p[0] * u[0] + p[1] * u[1] + p[2] * u[2],
                    p[0] * w[0] + p[1] * w[1] + p[2] * w[2]))
    order = list(range(m))
    area = 0.0
    for i in range(m):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % m]
        area += x1 * y2 - x2 * y1
    if area < 0:
        order.reverse()

    def in_tri(px, py, axx, ayy, bxx, byy, cxx, cyy):
        d1 = (px - bxx) * (ayy - byy) - (axx - bxx) * (py - byy)
        d2 = (px - cxx) * (byy - cyy) - (bxx - cxx) * (py - cyy)
        d3 = (px - axx) * (cyy - ayy) - (cxx - axx) * (py - ayy)
        has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
        has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
        return not (has_neg and has_pos)

    tris2d = []
    idx = order[:]
    guard = 0
    while len(idx) > 3 and guard < 100000:
        guard += 1
        cnt = len(idx)
        found = False
        for k in range(cnt):
            i0, i1, i2 = idx[(k - 1) % cnt], idx[k], idx[(k + 1) % cnt]
            axx, ayy = pts[i0]; bxx, byy = pts[i1]; cxx, cyy = pts[i2]
            cross = (bxx - axx) * (cyy - ayy) - (byy - ayy) * (cxx - axx)
            if cross <= 1e-12:                 # reflex / degenerate corner
                continue
            good = True
            for j in idx:
                if j in (i0, i1, i2):
                    continue
                px, py = pts[j]
                if in_tri(px, py, axx, ayy, bxx, byy, cxx, cyy):
                    good = False
                    break
            if good:
                tris2d.append((i0, i1, i2))
                del idx[k]
                found = True
                break
        if not found:
            break
    if len(idx) == 3:
        tris2d.append((idx[0], idx[1], idx[2]))

    out = []
    for (i, j, k) in tris2d:
        A, B, C = loop[i], loop[j], loop[k]
        fn = vcross(vsub(verts[B]["Position"], verts[A]["Position"]),
                    vsub(verts[C]["Position"], verts[A]["Position"]))
        out.append((A, B, C) if vdot(fn, orient) >= 0 else (A, C, B))
    return out


def plane_cut(verts, indices, pt, nrm, keep_pos=True, eps=1e-7, bounds=None, cap=True):
    """Slice the mesh by a flat plane (pt, nrm), splitting straddling triangles
    exactly on the plane so the cut edge is perfectly straight, dropping the far
    side, and capping the cross-section flat so no hollow interior shows.
    verts: list of attribute dicts; indices: flat triangle list.
    bounds: optional list of {point, normal} end-planes; a triangle is only
    subject to the cut when its centroid is in-bounds (dot(c-point,normal) >= 0)
    for EVERY bound. Triangles outside the bounds are kept whole -- this limits a
    drag cut to the span of the drag instead of the infinite plane.
    Returns (new_verts, new_indices)."""
    from collections import defaultdict, Counter
    nrm = vnorm(nrm)
    sgn = 1.0 if keep_pos else -1.0
    bnds = []
    for bd in (bounds or []):
        bp = bd.get("point") if isinstance(bd, dict) else bd[0]
        bn = bd.get("normal") if isinstance(bd, dict) else bd[1]
        if bp and bn:
            bnds.append((bp, vnorm(bn)))

    def in_bounds(a, b, c):
        if not bnds:
            return True
        cx = (verts[a]["Position"][0] + verts[b]["Position"][0] + verts[c]["Position"][0]) / 3.0
        cy = (verts[a]["Position"][1] + verts[b]["Position"][1] + verts[c]["Position"][1]) / 3.0
        cz = (verts[a]["Position"][2] + verts[b]["Position"][2] + verts[c]["Position"][2]) / 3.0
        for bp, bn in bnds:
            if (cx - bp[0]) * bn[0] + (cy - bp[1]) * bn[1] + (cz - bp[2]) * bn[2] < -eps:
                return False
        return True

    def sd(p):
        return sgn * ((p[0] - pt[0]) * nrm[0] + (p[1] - pt[1]) * nrm[1] + (p[2] - pt[2]) * nrm[2])

    d = [sd(v["Position"]) for v in verts]
    new_verts = [dict(v) for v in verts]
    edge_split = {}

    def split_index(a, b):
        key = (a, b) if a < b else (b, a)
        if key in edge_split:
            return edge_split[key]
        ka, kb = key
        t = d[ka] / (d[ka] - d[kb])
        va, vb = verts[ka], verts[kb]
        nv = {}
        for k in va:
            A, B = va[k], vb[k]
            nv[k] = [A[i] + t * (B[i] - A[i]) for i in range(len(A))] if isinstance(A, list) else A + t * (B - A)
        idx = len(new_verts)
        new_verts.append(nv)
        edge_split[key] = idx
        return idx

    new_idx = []
    segments = []
    for i in range(0, len(indices), 3):
        a, b, c = indices[i], indices[i + 1], indices[i + 2]
        if not in_bounds(a, b, c):
            new_idx += [a, b, c]          # outside the drag span -> leave untouched
            continue
        da, db, dc = d[a], d[b], d[c]
        keep = [da >= -eps, db >= -eps, dc >= -eps]
        nk = sum(keep)
        if nk == 3:
            new_idx += [a, b, c]
            continue
        if nk == 0:
            continue
        vv, dd = [a, b, c], [da, db, dc]
        if nk == 1:
            j = keep.index(True)
            k0, k1, k2 = vv[j], vv[(j + 1) % 3], vv[(j + 2) % 3]
            s1, s2 = split_index(k0, k1), split_index(k0, k2)
            new_idx += [k0, s1, s2]
            segments.append((s1, s2))
        else:  # nk == 2 -> quad on keep side, split into 2 tris
            j = keep.index(False)
            k0, k1, k2 = vv[j], vv[(j + 1) % 3], vv[(j + 2) % 3]   # k0 removed
            s1, s2 = split_index(k0, k1), split_index(k0, k2)
            new_idx += [k1, k2, s2, k1, s2, s1]
            segments.append((s2, s1))

    # cap the cross-section: on-plane segments -> loop(s) -> flat fan
    if cap and segments:
        adj = defaultdict(list)
        for (u, v) in segments:
            adj[u].append(v); adj[v].append(u)
        seen = set()

        def ekey(u, v):
            return (u, v) if u < v else (v, u)
        loops = []
        for (su, sv) in segments:
            if ekey(su, sv) in seen:
                continue
            loop = [su]; seen.add(ekey(su, sv)); prev, cur = su, sv
            while cur != su:
                loop.append(cur)
                nxt = [w for w in adj[cur] if w != prev and ekey(cur, w) not in seen]
                if not nxt:
                    if su in adj[cur] and ekey(cur, su) not in seen:
                        seen.add(ekey(cur, su))
                    break
                w = nxt[0]; seen.add(ekey(cur, w)); prev, cur = cur, w
            if len(loop) >= 3:
                loops.append(loop)
        capN = [-nrm[0] * sgn, -nrm[1] * sgn, -nrm[2] * sgn]
        for loop in loops:
            for (A, B, C) in _triangulate_loop(new_verts, loop, capN):
                new_idx += [A, B, C]

    return new_verts, new_idx


def cap_holes(verts, orig_indices, carve_set):
    """After a cut removes triangles from the (often unwelded) shell, fill the
    open boundary the cut created with flat caps so it reads as solid. Welds
    vertices by position first to find the true physical boundary across seams.
    Caps reuse nearby verts' UVs/slice so the skin still applies.
    Returns (new_verts, new_tris)."""
    from collections import defaultdict, Counter

    # weld by position -> one canonical vertex index per physical location
    loc = {}
    canon = [0] * len(verts)
    for i, v in enumerate(verts):
        p = v["Position"]
        key = (round(p[0], 5), round(p[1], 5), round(p[2], 5))
        if key not in loc:
            loc[key] = i
        canon[i] = loc[key]

    ntri = len(orig_indices) // 3
    edge_kr = defaultdict(lambda: [0, 0])       # welded edge -> [kept, removed]
    for t in range(ntri):
        a, b, c = (canon[orig_indices[3 * t + k]] for k in range(3))
        r = 1 if t in carve_set else 0
        for u, v in ((a, b), (b, c), (c, a)):
            if u == v:
                continue
            edge_kr[(u, v) if u < v else (v, u)][r] += 1

    # boundary = a welded edge that WAS shared (2 tris) but lost one side to the cut
    boundary = [e for e, (k, r) in edge_kr.items() if k == 1 and r >= 1]
    if not boundary:
        return [], []
    adj = defaultdict(list)
    for (u, v) in boundary:
        adj[u].append(v); adj[v].append(u)

    used = set()

    def ekey(u, v):
        return (u, v) if u < v else (v, u)
    loops = []
    for (su, sv) in boundary:
        if ekey(su, sv) in used:
            continue
        loop = [su]; used.add(ekey(su, sv)); prev, cur = su, sv
        while cur != su:
            loop.append(cur)
            nxt = [w for w in adj[cur] if w != prev and ekey(cur, w) not in used]
            if not nxt:
                if su in adj[cur] and ekey(cur, su) not in used:
                    used.add(ekey(cur, su))
                break
            w = nxt[0]; used.add(ekey(cur, w)); prev, cur = cur, w
        if len(loop) >= 3:
            loops.append(loop)

    new_verts, new_tris = [], []
    for loop in loops:
        outward = vnorm([sum(verts[i]["Normal"][k] for i in loop) / len(loop) for k in range(3)])
        for (A, B, C) in _triangulate_loop(verts, loop, outward):
            new_tris.extend((A, B, C))
    return new_verts, new_tris


def _pos_edge_key(verts, i, j):
    a = verts[i]["Position"]; b = verts[j]["Position"]
    ka = (round(a[0], 4), round(a[1], 4), round(a[2], 4))
    kb = (round(b[0], 4), round(b[1], 4), round(b[2], 4))
    return (ka, kb) if ka < kb else (kb, ka)


def boundary_pos_keys(verts, indices):
    """Position-keyed set of the mesh's natural open boundary edges (used once
    after welding). Lets us tell cut-created holes from the gun's natural openings."""
    from collections import defaultdict
    loc, canon = {}, [0] * len(verts)
    for i, v in enumerate(verts):
        p = v["Position"]
        canon[i] = loc.setdefault((round(p[0], 5), round(p[1], 5), round(p[2], 5)), i)
    ec = defaultdict(int)
    for t in range(len(indices) // 3):
        a, b, c = (canon[indices[3 * t + k]] for k in range(3))
        for u, v in ((a, b), (b, c), (c, a)):
            if u != v:
                ec[(u, v) if u < v else (v, u)] += 1
    keys = set()
    for (u, v), n in ec.items():
        if n == 1:
            keys.add(_pos_edge_key(verts, u, v))
    return keys


def find_open_loops(verts, indices):
    """Find every open boundary loop of the CURRENT mesh (edges used by exactly one
    triangle after welding coincident vertices). Returns lists of vertex indices."""
    from collections import defaultdict
    loc, canon = {}, [0] * len(verts)
    for i, v in enumerate(verts):
        p = v["Position"]
        canon[i] = loc.setdefault((round(p[0], 5), round(p[1], 5), round(p[2], 5)), i)
    ec = defaultdict(int)
    for t in range(len(indices) // 3):
        a, b, c = (canon[indices[3 * t + k]] for k in range(3))
        for u, v in ((a, b), (b, c), (c, a)):
            if u != v:
                ec[(u, v) if u < v else (v, u)] += 1
    boundary = [e for e, n in ec.items() if n == 1]
    if not boundary:
        return []
    adj = defaultdict(list)
    for (u, v) in boundary:
        adj[u].append(v); adj[v].append(u)
    used = set()

    def ek(u, v):
        return (u, v) if u < v else (v, u)
    loops = []
    for (su, sv) in boundary:
        if ek(su, sv) in used:
            continue
        loop = [su]; used.add(ek(su, sv)); prev, cur = su, sv
        while cur != su:
            loop.append(cur)
            nxt = [w for w in adj[cur] if w != prev and ek(cur, w) not in used]
            if not nxt:
                if su in adj[cur] and ek(cur, su) not in used:
                    used.add(ek(cur, su))
                break
            w = nxt[0]; used.add(ek(cur, w)); prev, cur = cur, w
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def build_greeble(g, gunR, uvScale, anchor_uv1, anchor_uv3, anchor_tan, models=None):
    """Return (list of vertex dicts, list of local indices) for one greeble,
    reproducing mmBuildMesh + mmMakeUVs exactly and baking slice into UV0.z.
    Handles both built-in shapes and imported custom models."""
    size = gunR * 0.045 * ((g.get('size', 100) or 100) / 100.0)
    shape = g.get('shape', 'stud')
    if shape == 'custom' or str(shape).startswith('custom:'):
        mid = g.get('model') or (str(shape).split(':', 1)[1] if ':' in str(shape) else None)
        m = (models or {}).get(mid)
        if not m or len(m.get('pos') or []) < 9:
            raise ValueError("custom model %r not embedded in project" % mid)
        sc = size * 2.0                      # mmBaseGeo: geo.scale(size*2,...)
        flat = m['pos']                      # already unit-normalized at import
        pos = [[flat[i] * sc, flat[i + 1] * sc, flat[i + 2] * sc]
               for i in range(0, len(flat) - 2, 3)]
        idx = list(m.get('idx') or []) or list(range(len(pos)))
    else:
        pos, idx = base_geo(shape, size)
    lvl = max(0, min(2, int(g.get('smooth', 0) or 0)))
    for _ in range(lvl):
        pos, idx = loop_subdivide(pos, idx)
    nrm = compute_vertex_normals(pos, idx)

    ys = [p[1] for p in pos]
    halfY = (max(ys) - min(ys)) / 2 if pos else 0.0

    n = vnorm(g['normal'])
    qAlign = q_from_unit_vectors([0.0, 1.0, 0.0], n)
    qSpin = q_from_axis_angle(n, (g.get('rot', 0) or 0) * math.pi / 180.0)
    quat = q_mul(qSpin, qAlign)
    hfrac = (100 if g.get('height') is None else g['height']) / 100.0
    center = vadd(g['point'], vscale(n, halfY * hfrac))

    T, B = mm_tangents(n)
    hu, hv = g['uv'][0], g['uv'][1]
    scl = uvScale or 1.0
    sl = 1.0 if int(round(g.get('slice', 0) or 0)) == 1 else 0.0

    out = []
    for i in range(len(pos)):
        wp = vadd(q_apply(quat, pos[i]), center)
        wn = vnorm(q_apply(quat, nrm[i]))
        d = vsub(wp, g['point'])
        out.append({
            'Position': wp,
            'Normal': [wn[0], wn[1], wn[2], 0.0],
            'Tangent': list(anchor_tan),
            'UV0': [hu + vdot(d, T) / scl, hv + vdot(d, B) / scl, sl, 0.0],
            'UV1': list(anchor_uv1),
            'UV2': [1.0, 0.0, 0.0, 0.0],
            'UV3': list(anchor_uv3),
        })
    return out, idx


def nearest_vertex_index(verts, point):
    best, bd = 0, None
    for i, v in enumerate(verts):
        p = v['Position']
        d = (p[0] - point[0]) ** 2 + (p[1] - point[1]) ** 2 + (p[2] - point[2]) ** 2
        if bd is None or d < bd:
            bd, best = d, i
    return best


def replace_mesh(base_verts, new_pos_flat, new_idx, log=print):
    """Swap the entire mesh for an imported one (whole-mesh replacement).

    The imported mesh (bundle-space positions, from the Forge) is fitted uniformly
    into the ORIGINAL mesh's AABB, then every new vertex copies UV0 (incl. the
    slice in .z), UV1, UV2, UV3 and Tangent from the NEAREST original vertex -- so
    the gun's existing painted texture wraps straight onto the new geometry and the
    two-slice Texture2DArray addressing stays valid. Normals are recomputed; the
    inherited tangent is re-orthogonalised against the new normal.

    Returns (new_verts, new_idx). Vertex dicts keep the original schema exactly, so
    the existing write path handles them unchanged.
    """
    if len(new_pos_flat) < 9 or len(new_idx) < 3:
        raise ValueError("imported mesh has no geometry")
    from collections import defaultdict

    P = [v["Position"] for v in base_verts]
    bmn = [min(p[k] for p in P) for k in range(3)]
    bmx = [max(p[k] for p in P) for k in range(3)]
    bctr = [(bmn[k] + bmx[k]) / 2.0 for k in range(3)]
    bsz = [max(bmx[k] - bmn[k], 1e-9) for k in range(3)]

    npts = [[new_pos_flat[i], new_pos_flat[i + 1], new_pos_flat[i + 2]]
            for i in range(0, len(new_pos_flat) - 2, 3)]
    nmn = [min(p[k] for p in npts) for k in range(3)]
    nmx = [max(p[k] for p in npts) for k in range(3)]
    nctr = [(nmn[k] + nmx[k]) / 2.0 for k in range(3)]
    nsz = [max(nmx[k] - nmn[k], 1e-9) for k in range(3)]
    s = min(bsz[k] / nsz[k] for k in range(3))       # uniform fit inside the gun's AABB
    fit = [[(p[k] - nctr[k]) * s + bctr[k] for k in range(3)] for p in npts]

    cell = max(bsz) / 64.0 or 1e-4
    grid = defaultdict(list)

    def gkey(p):
        return (int((p[0] - bmn[0]) // cell), int((p[1] - bmn[1]) // cell), int((p[2] - bmn[2]) // cell))

    for i, v in enumerate(base_verts):
        grid[gkey(v["Position"])].append(i)

    def nearest(p):
        kx, ky, kz = gkey(p)
        best, bd, r = -1, None, 0
        while True:
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    for dz in range(-r, r + 1):
                        if max(abs(dx), abs(dy), abs(dz)) != r:
                            continue
                        for i in grid.get((kx + dx, ky + dy, kz + dz), ()):
                            q = base_verts[i]["Position"]
                            d = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2 + (q[2] - p[2]) ** 2
                            if bd is None or d < bd:
                                bd, best = d, i
            if best >= 0 and ((r - 1) * cell) ** 2 > bd:
                break
            r += 1
            if r > 300:
                break
        return best if best >= 0 else 0

    new_verts = []
    for p in fit:
        nv = dict(base_verts[nearest(p)])            # inherit full schema + transferred channels
        nv["Position"] = [p[0], p[1], p[2]]
        new_verts.append(nv)

    nrm = compute_vertex_normals(fit, list(new_idx))
    for i, nv in enumerate(new_verts):
        n = nrm[i]
        nw = nv["Normal"][3] if isinstance(nv.get("Normal"), list) and len(nv["Normal"]) > 3 else 0.0
        nv["Normal"] = [n[0], n[1], n[2], nw]
        t = nv.get("Tangent")
        if isinstance(t, list) and len(t) >= 3:
            dot = t[0] * n[0] + t[1] * n[1] + t[2] * n[2]
            tx, ty, tz = t[0] - n[0] * dot, t[1] - n[1] * dot, t[2] - n[2] * dot
            L = (tx * tx + ty * ty + tz * tz) ** 0.5 or 1.0
            w = t[3] if len(t) > 3 else 1.0
            nv["Tangent"] = [tx / L, ty / L, tz / L, w]
    return new_verts, list(new_idx)


# ------------------------------------------------------------------- pipeline
def apply_project(bundle_path, proj, log=print, out_path=None):
    """Inject a project's greebles into a weapon bundle.

    bundle_path : path to the clean source .bundle
    proj        : a parsed project dict OR a path to a .skinproj(.json)
    log         : callable(str) for progress (defaults to print)
    out_path    : where to write the modded bundle; defaults to
                  '<bundle_stem>__MODDED.bundle' next to the source.

    Returns a dict: {ok, out, added_verts, added_tris, reason}.
    Never overwrites the source bundle.
    """
    import inject_mesh as im

    if isinstance(proj, str):
        with open(proj, "r", encoding="utf-8") as fh:
            proj = json.load(fh)
    if not isinstance(proj, dict):
        log("ABORT: project is not a JSON object.")
        return {"ok": False, "out": None, "added_verts": 0, "added_tris": 0,
                "reason": "bad project data"}

    if proj.get("v") != 1:
        log("warning: project v=%r (expected 1) -- proceeding anyway" % proj.get("v"))
    greebles = proj.get("greebles") or []
    carve = set(proj.get("carveTris") or proj.get("hiddenTris") or [])
    planes = proj.get("planeCuts") or []
    models = {cm["id"]: cm for cm in (proj.get("customModels") or []) if cm.get("id")}
    log("project: weapon=%r  greebles=%d  carveTris=%d  planeCuts=%d  customModels=%d"
        % (proj.get("weapon"), len(greebles), len(carve), len(planes), len(models)))
    if not greebles and not carve and not planes and not proj.get("replaceMesh") and not proj.get("fillPoints"):
        log("nothing to do -- no greebles, cuts, plane cuts, or mesh replacement.")
        return {"ok": False, "out": None, "added_verts": 0, "added_tris": 0,
                "reason": "no greebles, carves, or plane cuts"}

    m = im.read_mesh(bundle_path)
    log("mesh: %d verts, %d indices" % (m["vcount"], len(m["indices"])))

    # single-submesh guard: append + carve assume one submesh (like the AKM).
    subs = (m.get("tree") or {}).get("m_SubMeshes") or []
    if len(subs) != 1:
        log("ABORT: '%s' has %d submeshes; mesh export currently supports single-submesh "
            "weapons. Send me its geo dump and I'll extend it." % (proj.get("weapon"), len(subs)))
        return {"ok": False, "out": None, "added_verts": 0, "added_tris": 0,
                "reason": "multi-submesh weapon"}

    if not im.self_check(m):
        log("ABORT: mesh did not round-trip byte-exactly -- not writing anything.")
        return {"ok": False, "out": None, "added_verts": 0, "added_tris": 0,
                "reason": "self-check failed"}
    log("self-check PASSED -- read/repack is byte-exact on the real data.")

    # --- whole-mesh replacement (before anything else edits the mesh) ---
    replaced = False
    rm = proj.get("replaceMesh")
    if rm:
        if rm.get("pos"):
            rpos, ridx = rm["pos"], (rm.get("idx") or list(range(len(rm["pos"]) // 3)))
        elif rm.get("model") and models.get(rm.get("model")):
            cm = models[rm["model"]]
            rpos, ridx = cm["pos"], (cm.get("idx") or list(range(len(cm["pos"]) // 3)))
        else:
            rpos = ridx = None
        if rpos:
            m["verts"], m["indices"] = replace_mesh(m["verts"], rpos, ridx, log=log)
            m["vcount"] = len(m["verts"])
            replaced = True
            log("replaced whole mesh -> %d verts, %d tris" % (len(m["verts"]), len(m["indices"]) // 3))

    positions = [v["Position"] for v in m["verts"]]
    uv0 = [v["UV0"] for v in m["verts"]]
    gunR = gun_radius(positions)
    uvScale = uv_world_scale(positions, uv0, m["indices"])
    log("gunRadius=%.5f  uvWorldScale=%.6f" % (gunR, uvScale))

    # --- carve FIRST, on the original triangle numbering, then add greebles ---
    orig_boundary = boundary_pos_keys(m["verts"], m["indices"])   # natural openings, before edits
    removed_t = capped_t = 0
    cap_cuts = proj.get("capCuts", True)
    if carve:
        orig_indices = list(m["indices"])          # before carve, for boundary detection
        kept = []
        for t in range(len(orig_indices) // 3):
            if t in carve:
                continue
            kept.extend(orig_indices[t * 3:t * 3 + 3])
        removed_t = len(orig_indices) // 3 - len(kept) // 3
        m["indices"] = kept
        log("carved away %d hidden triangle(s)" % removed_t)
        if cap_cuts:
            try:
                cap_v, cap_t = cap_holes(m["verts"], orig_indices, carve)
                if cap_t:
                    m["verts"].extend(cap_v)
                    m["indices"].extend(cap_t)
                    capped_t = len(cap_t) // 3
                    log("capped the cut with %d triangle(s) across %d opening(s)"
                        % (capped_t, len(cap_v)))
            except Exception as e:
                log("  cap skipped (%s) -- exported with the cut left open" % e)

    # --- clean straight plane cuts (split triangles on the plane, cap flat) ---
    sliced_n = 0
    for pc in planes:
        try:
            m["verts"], m["indices"] = plane_cut(
                m["verts"], m["indices"], pc["point"], pc["normal"], bool(pc.get("keepPos", True)),
                bounds=pc.get("bounds"), cap=(cap_cuts and not pc.get("bounds")))
            sliced_n += 1
            log("plane cut %d applied -> %d tris" % (sliced_n, len(m["indices"]) // 3))
        except Exception as e:
            log("  plane cut skipped: %s" % e)

    added_v = added_t = 0
    have_uv1 = bool(m["verts"]) and ("UV1" in m["verts"][0])
    have_uv3 = bool(m["verts"]) and ("UV3" in m["verts"][0])
    for k, g in enumerate(greebles):
        try:
            ai = nearest_vertex_index(m["verts"], g["point"])
            av = m["verts"][ai]
            gv, gi = build_greeble(g, gunR, uvScale,
                                   av.get("UV1", [0.0, 0.0, 0.0, 0.0]),
                                   av.get("UV3", [0.0, 0.0, 0.0, 0.0]),
                                   av.get("Tangent", [1.0, 0.0, 0.0, 1.0]), models)
        except Exception as e:
            log("  greeble %d (%r) SKIPPED: %s" % (k, g.get("shape"), e))
            continue
        # keep greeble verts schema-identical to the mesh (some weapons have no UV1/UV3)
        if not have_uv1:
            for vtx in gv:
                vtx.pop("UV1", None)
        if not have_uv3:
            for vtx in gv:
                vtx.pop("UV3", None)
        base = len(m["verts"])
        m["verts"].extend(gv)
        m["indices"].extend(base + j for j in gi)
        added_v += len(gv); added_t += len(gi) // 3
        log("  greeble %d: %-6s slice=%d  +%d verts +%d tris"
            % (k, g.get("shape", "?"), int(g.get("slice", 0) or 0), len(gv), len(gi) // 3))

    # --- close cut-created holes: auto-cap new open loops (cap on) + manual fills ---
    filled_n = 0
    fill_points = proj.get("fillPoints") or []
    if cap_cuts or fill_points:
        loops = find_open_loops(m["verts"], m["indices"])
        if loops:
            xs = [v["Position"][0] for v in m["verts"]]
            ys = [v["Position"][1] for v in m["verts"]]
            zs = [v["Position"][2] for v in m["verts"]]
            gun = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1e-6)
            r2 = (gun * 0.16) ** 2
            cents = [[sum(m["verts"][i]["Position"][k] for i in lp) / len(lp) for k in range(3)] for lp in loops]
            for li, lp in enumerate(loops):
                do_cap = False
                if cap_cuts:
                    L = len(lp)
                    orig = sum(1 for k in range(L)
                               if _pos_edge_key(m["verts"], lp[k], lp[(k + 1) % L]) in orig_boundary)
                    if orig / L < 0.5:                    # mostly-new edges -> a cut/erase hole
                        do_cap = True
                if not do_cap and fill_points:
                    c = cents[li]
                    for fp in fill_points:
                        if (c[0] - fp[0]) ** 2 + (c[1] - fp[1]) ** 2 + (c[2] - fp[2]) ** 2 <= r2:
                            do_cap = True
                            break
                if do_cap:
                    onrm = vnorm([sum(m["verts"][i]["Normal"][k] for i in lp) / len(lp) for k in range(3)])
                    for (A, B, C) in _triangulate_loop(m["verts"], lp, onrm):
                        m["indices"] += [A, B, C]
                    filled_n += 1
            if filled_n:
                log("closed %d cut hole(s)" % filled_n)

    total = len(m["verts"])
    log("added %d greeble verts / %d tris, carved %d, capped %d, plane-cuts %d -> now %d verts, %d tris"
        % (added_v, added_t, removed_t, capped_t, sliced_n, total, len(m["indices"]) // 3))
    if total >= 65536:
        log("ABORT: %d verts exceeds the 16-bit index limit (65535). Needs 32-bit "
            "index promotion -- tell me and I'll add it." % total)
        return {"ok": False, "out": None, "added_verts": added_v, "added_tris": added_t,
                "reason": "over 65535 verts"}
    if added_t == 0 and removed_t == 0 and sliced_n == 0 and not replaced and filled_n == 0:
        log("ABORT: nothing changed (no geometry added, carved, or sliced); not writing.")
        return {"ok": False, "out": None, "added_verts": 0, "added_tris": 0,
                "reason": "no change produced"}

    if not out_path:
        out_path = os.path.splitext(bundle_path)[0] + "__MODDED.bundle"
    im.write_bundle(m, out_path)
    log("DONE -> %s" % os.path.basename(out_path))
    return {"ok": True, "out": out_path, "added_verts": added_v, "added_tris": added_t,
            "carved_tris": removed_t, "capped_tris": capped_t, "plane_cuts": sliced_n,
            "replaced": replaced, "reason": ""}


# --------------------------------------------------------------- window / CLI
class Tee:
    def __init__(self, fh, console):
        self.fh = fh; self.console = console
    def write(self, s):
        self.console.write(s); self.fh.write(s)
    def flush(self):
        try:
            self.console.flush()
        except Exception:
            pass
        self.fh.flush()


def ask(prompt):
    for _ in range(3):
        try:
            raw = input(prompt + ":\n> ").strip().strip('"').strip("'").strip()
        except EOFError:
            return None
        if raw and os.path.isfile(raw):
            return raw
        print("  can't find a file there -- try again.")
    return None


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    bundle = args[0] if len(args) > 0 else None
    proj = args[1] if len(args) > 1 else None
    if not bundle or not os.path.isfile(bundle):
        bundle = ask("Drag the AKM LOD0 .bundle here, then Enter")
    if not proj or not os.path.isfile(proj):
        proj = ask("Drag your .skinproj.json here, then Enter")
    if not bundle or not proj:
        print("Need both a bundle and a .skinproj file. Nothing done.")
        return 1
    try:
        import UnityPy  # noqa: F401
    except ImportError:
        print("UnityPy is not installed. In this same Python run:  pip install UnityPy")
        return 2
    res = apply_project(bundle, proj)
    if res.get("ok"):
        print("Copy %s into the game as the original's replacement." % os.path.basename(res["out"]))
        return 0
    return 3


if __name__ == "__main__":
    code = 1
    with open(LOG_PATH, "w", encoding="utf-8") as _fh:
        _real = sys.stdout
        sys.stdout = Tee(_fh, _real)
        print("(a copy of this output is saved to: %s)\n" % LOG_PATH)
        try:
            code = main(sys.argv)
        except Exception:
            print("\n!! Unexpected error:\n" + traceback.format_exc())
            code = 4
        finally:
            sys.stdout = _real
    try:
        input("\nPress Enter to close this window...")
    except Exception:
        pass
    sys.exit(code)
