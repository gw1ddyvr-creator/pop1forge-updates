"""POP-1 Skin Forge - the Api (everything the page calls) + billboard/ctex engine.

Loaded and driven by app.py, the thin immutable launcher. This module ships as a SILENT
UPDATE (it is listed in app.py's _UPD_MODULES and in publish_update.py FILES), so fixes to
billboards, ctex, injects, sounds, reticles, shine, etc. reach users WITHOUT a reinstall.
Only app.py (the update/verify root + window bootstrap) and native libs still need a new exe.

app.py hands us the trusted helpers below at startup via attribute injection (see the
"for _n in (...): setattr(forge_api, _n, ...)" block in app.py). They are declared here as
placeholders so this module still imports on its own; the real objects are wired in before
any Api() is constructed.
"""
import os, sys, json, time, base64, logging, tempfile, shutil
import threading, traceback, gzip, hashlib, io, re, wave
import urllib.request, urllib.parse
from io import BytesIO

# ---- injected by app.py at startup (the launcher's trusted, immutable helpers) ----
_log = None
_base_dir = None
_asset = None
_img_to_data_url = None
_forge_html_path = None
_upd_applied = None
_download_updates = None
_staged_ok = None
BUNDLED_WEB_BUILD = 0
eng = None
matpre = None
fmod_bank = None
sound_match = None
webview = None
HAVE_PIL = False

# ---- Billboards (Signs_CCC_tarray) engine constants ------------------------
BB_TEX_NAME   = "Signs_CCC_tarray"
BB_TEX_PATHID = 2334
BB_W, BB_H, BB_DEPTH, BB_FORMAT = 1024, 1024, 5, 100
BB_DEFAULT_ASSET = (
    r"C:\Program Files\Meta Horizon\Software\Software"
    r"\big-box-vr-inc-battleroyale\PopulationONE_Data\sharedassets4.assets"
)
BB_DEFAULT_ASSET_ALT = (
    r"C:\Program Files\Meta Horizon\Software\Software"
    r"\big-box-vr-inc-battleroyale\PopulationONE_Data\sharedassets2.assets"
)
BB_SLICE_HINTS = {
    0: "Red ONE propaganda posters (logo, skyline, fist, robot, tank, banner)",
    1: "Grey 'T' diamond logo (animated in-game, 2 frames)",
    2: "TRUTH / SEEK TRUTH conspiracy posters",
    3: "Neon signs (ONE, POP ONE, SHIELD, Metropolis, POP Chicken, ONE POP...)",
    4: "Departure board / SHOP UI / crossing signs / GUN SHOP / GENESIS",
    5: "Extra sign (only in the 7-slice copy)",
    6: "Extra sign (only in the 7-slice copy)",
}
# Downloaded ad-board textures (.ctex = ZIP of ContainerType/Header/RawData)
# These are what the game ACTUALLY draws on gb_megaboard_ad / miniboard / posters.
BB_CTEX_DIR = os.path.join(
    os.path.expanduser("~"), "AppData", "LocalLow", "BigBoxVR",
    "Population_ ONE", "cached")
BB_CTEX_ORIG = "originals"      # pristine .ctex copies (Billboards/originals)
BB_CTEX = {
    "BB-Megaboards-Standalone": "Big billboards (gb_megaboard_ad) - the giant boards",
    "BB-Miniboards-Standalone": "Mini ad boards (gb_miniboard_ad)",
    "BB-Posters-Standalone":    "Wall posters (gb_poster_*)",
}

# Which Signs slice each ctex board mirrors, so the boards reuse the same fixed
# region maps (only slices with a BB_REGIONS_FIXED entry actually override; the
# rest auto-detect). BB-Posters is the yellow SEEK TRUTH board = slice2.
BB_BOARD_SLICE = {
    "BB-Posters-Standalone":    2,
    "BB-Miniboards-Standalone": 0,
    "BB-Megaboards-Standalone": 1,
}


# Hand-measured panel rectangles for the fixed Signs_CCC_tarray texture.
# (x, y, w, h) in 1024x1024 slice space. Clicking a panel in the editor selects it.
BB_PANELS = {
    0: [(12,6,218,504),(260,6,246,504),(522,6,236,504),(780,6,236,504),
        (8,520,430,240),(818,556,200,206),(12,812,1000,172)],
    1: [(36,4,952,506),(36,514,952,506)],
    2: [(12,6,236,502),(260,6,238,502),(512,6,238,502),(762,6,252,502),
        (8,522,1008,236),(0,850,86,112),(108,850,346,100),(474,852,440,96),(950,850,74,112)],
    3: [(8,5,240,246),(258,5,242,246),(512,5,248,246),(772,5,246,505),
        (8,258,240,252),(258,258,502,252),(8,534,1008,208),
        (8,800,240,220),(258,800,242,220),(512,800,236,220),(760,800,258,220)],
    4: [(14,4,232,764),(250,4,486,764),(740,4,282,510),(740,520,282,246),
        (4,772,1016,120),(4,896,506,126),(512,896,510,126)],
}

# Verified region tilings for the busy slices whose art can't be auto-detected
# cleanly (unsealed images with no background gap between them / text banners /
# irregular collages). Each list already tiles the slice: neighbours meet at the
# gap midline and outer images run to the slice border. Slices NOT listed here
# (0,1,5 = sealed layouts, 6 = seam-detected) auto-detect correctly and are left
# to the live detector. Confirmed against the real slice pixels with GW1DDY.
# The busy slices sit on a 4x4 grid of 256px cells (cols A-D left->right,
# rows 1-4 bottom->top). Multi-cell images span several cells; GW1DDY defined
# the groupings. Regions already tile the slice (outer edges hit the border,
# neighbours butt together).
BB_REGIONS_FIXED = {
    # slice2 - same 4-top + middle band + bottom banner layout as slice0
    2: [(0,0,256,517),(256,0,261,517),(517,0,246,517),(763,0,261,517),
        (0,517,1024,252),(0,769,1024,255)],
    # slice3 - A4 B4 C4 | shaker=D4+D3 | A3 single, BC3=one image | METROPOLIS=row2 | A1 B1 C1 D1
    3: [(0,0,256,256),(256,0,256,256),(512,0,256,256),(768,0,256,512),
        (0,256,256,256),(256,256,512,256),(0,512,1024,256),
        (0,768,256,256),(256,768,256,256),(512,768,256,256),(768,768,256,256)],
    # slice4 - can=A3+4 | banana=B left half, sword=B right half (vertical split) | char=C3+4
    #          | cat=D4 hammer=D3 | board=A2 signs=B2 shop=C2 D2 | GUN SHOP=top row1 | GENESIS=bottom row1
    4: [(0,0,256,512),(256,0,128,512),(384,0,128,512),(512,0,256,512),
        (768,0,256,256),(768,256,256,256),
        (0,512,256,256),(256,512,256,256),(512,512,256,256),(768,512,256,256),
        (0,768,1024,128),(0,896,1024,128)],
    # slice6 - POPnMEDIA. ABC3+4=big top-left | D4 globe | D3 sign | ABCD2=POP.MEDIA bar | AB1 | CD1
    6: [(0,0,768,512),(768,0,256,256),(768,256,256,256),
        (0,512,1024,256),(0,768,512,256),(512,768,512,256)],
}


def _normal_from_height(height, strength=2.0, flip_y=False):
    """(H,W) float height in [0,1] -> (H,W,3) uint8 tangent normal; flat=(128,128,255).
    Measured on the AWP: the game's NNN is a STANDARD tangent normal (R=X, G=Y,
    B=Z, flat blue), so relief = tilt R/G along a heightmap's slopes."""
    import numpy as np
    h = height.astype("float32")
    gy, gx = np.gradient(h)
    nx = -gx * strength
    ny = -gy * strength * (-1.0 if flip_y else 1.0)
    nz = np.ones_like(h)
    inv = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
    r = np.clip((nx * inv) * 0.5 + 0.5, 0, 1) * 255.0
    g = np.clip((ny * inv) * 0.5 + 0.5, 0, 1) * 255.0
    b = np.clip((nz * inv) * 0.5 + 0.5, 0, 1) * 255.0
    return np.stack([r, g, b], -1).astype("uint8")


def _blend_normal_maps(base_rgb, detail_rgb):
    """UDN blend: add a detail normal's slope onto a base normal so the gun's
    existing surface detail is kept and the engraving is added on top."""
    import numpy as np
    b = base_rgb.astype("float32") / 127.5 - 1.0
    d = detail_rgb.astype("float32") / 127.5 - 1.0
    nx = b[..., 0] + d[..., 0]
    ny = b[..., 1] + d[..., 1]
    nz = np.maximum(b[..., 2], 1e-3)
    inv = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
    out = np.stack([nx * inv, ny * inv, nz * inv], -1)
    return ((out * 0.5 + 0.5) * 255.0).clip(0, 255).astype("uint8")


def _curvature_from_normal(nrm, blur=1.5):
    """Derive a signed curvature map from a tangent normal map (H,W,3 uint8):
    the divergence of the surface normal's tangent (XY) — POSITIVE on convex
    edges/ridges (where paint wears to bare metal), NEGATIVE in concave cavities
    (where grime settles). Returns (H,W) float in [-1,1]. This is how Substance's
    curvature/edge masks are made; here it's baked from the gun's OWN normal map
    (no 3D ray-casting needed)."""
    import numpy as np
    n = nrm.astype("float32") / 127.5 - 1.0
    nx, ny = n[..., 0], n[..., 1]
    dnx = np.gradient(nx)            # [d/row, d/col]
    dny = np.gradient(ny)
    curv = dnx[1] + dny[0]          # dNx/dx + dNy/dy  (divergence)
    if blur and blur > 0:
        from PIL import Image, ImageFilter
        c = Image.fromarray(((np.clip(curv, -1, 1) * 0.5 + 0.5) * 255).astype("uint8"))
        c = c.filter(ImageFilter.GaussianBlur(float(blur)))
        curv = np.asarray(c).astype("float32") / 127.5 - 1.0
    m = float(np.percentile(np.abs(curv), 99)) or 1.0
    return np.clip(curv / m, -1.0, 1.0)


def _apply_wear(color_rgb, curv, edge_amt, cav_amt, edge_color=(175, 178, 182)):
    """Age a colour texture with curvature masks: convex edges scuff toward bare
    metal (edge_color), concave cavities darken with grime. (H,W,3)->(H,W,3)."""
    import numpy as np
    c = color_rgb.astype("float32")
    edge = (np.clip(curv, 0, 1) * float(edge_amt))[..., None]
    cav = (np.clip(-curv, 0, 1) * float(cav_amt))[..., None]
    ec = np.array(edge_color, "float32")
    c = c * (1.0 - edge) + ec * edge          # edges -> bare metal
    c = c * (1.0 - cav * 0.65)                 # cavities -> darkened grime
    return np.clip(c, 0, 255).astype("uint8")


def _boost_mge_edges(mge_rgb, curv, edge_amt):
    """Make the worn edges read as real metal in-game: raise metallic (R) + gloss
    (G,A) on convex edges, blended onto the stock MGE. (H,W,3)->(H,W,4)."""
    import numpy as np
    m = mge_rgb.astype("float32")
    edge = np.clip(curv, 0, 1) * float(edge_amt)
    R = m[..., 0] * (1 - edge) + 220 * edge
    G = m[..., 1] * (1 - edge) + 210 * edge
    B = m[..., 2]
    return np.clip(np.stack([R, G, B, G], -1), 0, 255).astype("uint8")


# --------------------------------------------------------------------------- #
#  Procedural surface engine — noise/streaks/weave, and the material + grunge
#  generators built on them. Pure numpy+PIL (headless). This is the "material
#  library" + "grunge" that Substance sells, made native. Each material returns
#  (colour RGB, MGE RGBA, height) so apply blends its micro-relief onto the gun's
#  stock normal (keeps panel lines) while replacing colour + finish.
# --------------------------------------------------------------------------- #
def _p_noise(w, h, scale, seed, octaves=4):
    """Fractal value noise in [0,1], (h,w)."""
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(int(seed) & 0x7fffffff)
    out = np.zeros((h, w), "float32"); amp = 1.0; tot = 0.0
    for o in range(octaves):
        s = max(2, int(scale) >> o)
        low = (rng.random((max(2, h // s + 2), max(2, w // s + 2))) * 255).astype("uint8")
        up = np.asarray(Image.fromarray(low).resize((w, h), Image.BILINEAR), dtype="float32") / 255.0
        out += up * amp; tot += amp; amp *= 0.5
    return out / (tot or 1.0)


def _p_streaks(w, h, seed):
    """Brushed-metal horizontal grain in [0,1]."""
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(int(seed) & 0x7fffffff)
    line = (rng.random((1, w)) * 255).astype("uint8")
    row = np.asarray(Image.fromarray(line).resize((w, 1), Image.BILINEAR), dtype="float32") / 255.0
    return 0.72 * np.tile(row, (h, 1)) + 0.28 * _p_noise(w, h, 160, seed + 1, 3)


def _p_weave(w, h, cell=22):
    """Carbon-fibre twill weave in [0,1]."""
    import numpy as np
    yy, xx = np.mgrid[0:h, 0:w]
    a = np.sin((xx / cell) * np.pi) * np.sin((yy / cell) * np.pi)
    b = np.sin(((xx + cell / 2) / cell) * np.pi) * np.sin(((yy + cell / 2) / cell) * np.pi)
    wv = np.where(((xx // cell + yy // cell) % 2) == 0, a, b)
    return (wv * 0.5 + 0.5).astype("float32")


# name -> (base colour rgb, metallic 0-255, gloss 0-255, texture kind)
_MATERIALS = ["gunmetal", "brushed_steel", "carbon", "blued_steel", "worn_steel", "parkerized",
              "nickel", "titanium", "bronze", "damascus", "cerakote_od", "cerakote_fde",
              "anodized_red", "tungsten"]


def _material_maps(name, w, h, seed=7):
    """Return (colour uint8 HxWx3, MGE uint8 HxWx4, height float HxW) for a material."""
    import numpy as np
    n = _p_noise(w, h, 96, seed, 4)
    def solid(rgb):
        return np.tile(np.array(rgb, "float32"), (h, w, 1))
    def mge(met, gl, var=None):
        R = np.full((h, w), met, "float32"); G = np.full((h, w), gl, "float32")
        if var is not None:
            G = np.clip(G + (var - 0.5) * 55, 0, 255)
        return np.clip(np.stack([R, G, np.zeros((h, w), "float32"), G], -1), 0, 255).astype("uint8")
    k = name.lower()
    if k == "brushed_steel":
        s = _p_streaks(w, h, seed); col = solid((150, 152, 156)) + (s[..., None] - 0.5) * 42; mg = mge(230, 185, s); ht = s
    elif k == "carbon":
        wv = _p_weave(w, h, 22); col = solid((18, 19, 22)) * (1 - wv[..., None]) + solid((42, 44, 50)) * wv[..., None]; mg = mge(120, 205, wv); ht = wv
    elif k == "blued_steel":
        col = solid((26, 29, 42)) + (n[..., None] - 0.5) * 16; mg = mge(215, 162, n); ht = n * 0.4
    elif k == "worn_steel":
        sc = _p_noise(w, h, 30, seed + 2, 5); col = solid((120, 121, 126)) + (n[..., None] - 0.5) * 30 - (sc[..., None] > 0.76) * 42; mg = mge(200, 150, n); ht = n * 0.5 + sc * 0.5
    elif k == "parkerized":
        col = solid((40, 40, 43)) + (n[..., None] - 0.5) * 20; mg = mge(95, 68, n); ht = n
    elif k == "nickel":
        col = solid((210, 213, 218)) + (n[..., None] - 0.5) * 12; mg = mge(246, 236, n); ht = n * 0.18
    elif k == "titanium":
        s = _p_streaks(w, h, seed + 4); col = solid((150, 156, 166)) + (s[..., None] - 0.5) * 26; mg = mge(234, 150, s); ht = s * 0.4
    elif k == "bronze":
        pat = _p_noise(w, h, 44, seed + 3, 5); col = solid((150, 96, 44)) + (pat[..., None] - 0.5) * 40 - (pat[..., None] > 0.72) * 26; mg = mge(208, 118, pat); ht = pat * 0.55
    elif k == "damascus":
        warp = _p_noise(w, h, 120, seed + 5, 4)
        yy = np.linspace(0, 1, h, dtype="float32")[:, None] + (warp - 0.5) * 0.28
        band = np.clip(0.5 + 0.5 * np.sin(yy * np.pi * 46.0), 0, 1).astype("float32")
        dark = np.array((58, 60, 68), "float32"); light = np.array((158, 162, 170), "float32")
        col = dark * (1 - band[..., None]) + light * band[..., None]; mg = mge(232, 150, band); ht = band
    elif k == "cerakote_od":
        col = solid((74, 80, 58)) + (n[..., None] - 0.5) * 14; mg = mge(30, 58, n); ht = n * 0.3
    elif k == "cerakote_fde":
        col = solid((150, 128, 96)) + (n[..., None] - 0.5) * 14; mg = mge(26, 52, n); ht = n * 0.3
    elif k == "anodized_red":
        s = _p_streaks(w, h, seed + 6); col = solid((150, 26, 30)) + (s[..., None] - 0.5) * 30; mg = mge(224, 168, s); ht = s * 0.35
    elif k == "tungsten":
        col = solid((72, 74, 80)) + (n[..., None] - 0.5) * 16; mg = mge(238, 128, n); ht = n * 0.45
    else:  # gunmetal
        col = solid((60, 64, 72)) + (n[..., None] - 0.5) * 22; mg = mge(205, 150, n); ht = n * 0.6
    return np.clip(col, 0, 255).astype("uint8"), mg, ht.astype("float32")


_GRUNGE = ["scratches", "grime", "dust", "smudge", "soot", "dirt", "speckle", "fingerprints"]


def _grunge_map(kind, w, h, seed=11):
    """Grayscale grunge in [0,1] (1 = heaviest grunge)."""
    import numpy as np
    k = kind.lower()
    if k == "scratches":
        from PIL import Image, ImageDraw
        rng = np.random.default_rng(seed)
        im = Image.new("L", (w, h), 0); d = ImageDraw.Draw(im)
        for _ in range(max(6, int(w * h / 22000))):
            x0, y0 = rng.integers(0, w), rng.integers(0, h)
            ang = rng.random() * 6.283; ln = rng.integers(40, 320)
            x1 = int(x0 + np.cos(ang) * ln); y1 = int(y0 + np.sin(ang) * ln)
            d.line([x0, y0, x1, y1], fill=int(rng.integers(140, 255)), width=1)
        return np.asarray(im, "float32") / 255.0
    if k == "grime":
        g = _p_noise(w, h, 64, seed, 5)
        return np.clip((g - 0.45) * 2.2, 0, 1)
    if k == "dust":
        return _p_noise(w, h, 8, seed, 3) * 0.6 + _p_noise(w, h, 40, seed + 1, 4) * 0.4
    if k == "soot":
        g = _p_noise(w, h, 110, seed, 5)
        return np.clip((g - 0.42) * 2.6, 0, 1)                 # heavy clumpy carbon build-up
    if k == "dirt":
        patch = _p_noise(w, h, 70, seed, 4)
        spat = (_p_noise(w, h, 10, seed + 3, 2) > 0.7).astype("float32")
        return np.clip(patch * 0.7 + spat * 0.5, 0, 1)         # patches + splatter
    if k == "speckle":
        from PIL import Image, ImageFilter
        rng = np.random.default_rng(seed)
        seeds = (rng.random((h, w)) > 0.992).astype("uint8") * 255       # sparse hits
        chips = Image.fromarray(seeds, "L").filter(ImageFilter.MaxFilter(3))
        return np.asarray(chips, "float32") / 255.0                       # small paint chips
    if k == "fingerprints":
        from PIL import Image, ImageDraw, ImageFilter
        rng = np.random.default_rng(seed)
        im = Image.new("L", (w, h), 0); d = ImageDraw.Draw(im)
        for _ in range(max(3, int(w * h / 320000))):           # a few smudged prints
            cx, cy = rng.integers(0, w), rng.integers(0, h)
            for r in range(6, 42, 5):
                d.ellipse([cx - r, cy - int(r * 1.3), cx + r, cy + int(r * 1.3)],
                          outline=int(rng.integers(60, 130)), width=2)
        return np.asarray(im.filter(ImageFilter.GaussianBlur(2)), "float32") / 255.0
    # smudge
    return np.clip(_p_noise(w, h, 200, seed, 3) * 1.4 - 0.2, 0, 1)


def _blend_by_mask(new_arr, orig_arr, mask01):
    """new where mask=1, orig where mask=0. mask01 is (H,W) float; arrays (H,W,C)."""
    import numpy as np
    m = mask01[..., None].astype("float32")
    return np.clip(new_arr.astype("float32") * m + orig_arr.astype("float32") * (1 - m), 0, 255).astype("uint8")


def _build_engraving_normal(mask, base=None, depth=1.0, recessed=True,
                            bevel=3.0, flip_y=False, size=(2048, 2048)):
    """Black/white MASK (white = the engraving) -> tangent normal map, optionally
    blended onto a `base` normal (the stock NNN slice). recessed=True carves IN;
    bevel slopes the walls so they read as real engraving, not vertical cliffs.
    (Lives here, not material_presets, because forge_api is self-updatable.)"""
    import numpy as np
    from PIL import Image, ImageFilter
    m = mask.convert("L").resize(size, Image.LANCZOS)
    if bevel and bevel > 0:
        m = m.filter(ImageFilter.GaussianBlur(float(bevel)))
    hm = np.asarray(m).astype("float32") / 255.0        # 1 = engraving
    if recessed:
        hm = 1.0 - hm                                    # carve IN: engraving = low
    det = _normal_from_height(hm, strength=2.0 * float(depth), flip_y=flip_y)
    if base is not None:
        b = np.asarray(base.convert("RGB").resize(size, Image.LANCZOS), dtype="uint8")
        return Image.fromarray(_blend_normal_maps(b, det), "RGB")
    return Image.fromarray(det, "RGB")


class Api:
    """Everything under here is reachable from the page as
    window.pywebview.api.<method>(...) and returns a JS Promise."""

    def __init__(self):
        self.cfg = eng.load_settings()
        try:
            self._archive_working()      # fresh launch = start from the originals
        except Exception:
            _log("archive_working failed:\n" + traceback.format_exc())
        self.png0 = None
        self.png1 = None
        self._tmp0 = None           # temp files for slices handed over from the Forge
        self._tmp1 = None
        self.window = None          # set in main() after the window exists
        self._presence_url = ""     # heartbeat/admin backend, read from the gist
        self._admin = False         # True when the active key is marked admin
        self._hb_started = False
        self._snd_banks = {}        # path -> (mtime, fmod_bank.Bank) cache
        self._snd_pending = {}      # bank_file -> {index: pcm16 bytes} staged swaps

    # ---- read-only summaries --------------------------------------------
    def _spec_summary(self):
        s = self.cfg.get("spec", {}) or {}
        return {
            "name": s.get("name"),
            "fmt": s.get("texconv_fmt"),
            "width": s.get("width"),
            "height": s.get("height"),
            "slices": s.get("slices"),
            "stream_offset": s.get("stream_offset"),
            "total": s.get("total"),
            "ress_name": s.get("ress_name"),
            "bundle_name": s.get("bundle_name"),
        }

    def status(self):
        tex = self.cfg.get("texconv_path") or ""
        bundle = self.cfg.get("bundle_path") or ""
        return {
            "version": getattr(eng, "VERSION", "?"),
            "texconv_ok": bool(tex and os.path.exists(tex)),
            "bundle_ok": bool(bundle and os.path.exists(bundle)),
            "weapons": eng.scan_library(),
            "spec": self._spec_summary(),
            "png0": os.path.basename(self.png0) if self.png0 else None,
            "png1": os.path.basename(self.png1) if self.png1 else None,
            "single_slice": (self.cfg.get("spec", {}).get("slices", 2) == 1),
            "machine_id": eng.machine_id(),
        }

    # ---- weapon selection + auto-detect ---------------------------------
    def select_weapon(self, name):
        logs = []

        def log(m, t=None):
            logs.append(str(m))

        bundle, ress = eng.library_files(name)
        if bundle:
            self.cfg["bundle_path"] = bundle
            self.cfg["spec"]["bundle_name"] = os.path.basename(bundle)
        if ress:
            self.cfg["clean_ress_path"] = ress
            self.cfg["spec"]["ress_name"] = os.path.basename(ress)

        spec = None
        if bundle:
            try:
                spec = eng.detect_spec_from_bundle(bundle, log)
            except Exception as e:
                log("auto-detect error: %s" % e)
            if spec:
                self.cfg["spec"].update(spec)

        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass

        ref0 = ref1 = None
        # --- diagnostics: show exactly what we can (or can't) find ---
        tdir = os.path.join(eng.app_dir(), "textures")
        sub = os.path.join(tdir, name)
        log("textures folder: %s" % tdir)
        log("  weapon subfolder: %s (exists=%s)" % (name, os.path.isdir(sub)))
        if os.path.isdir(sub):
            try:
                pngs = [f for f in os.listdir(sub) if f.lower().endswith(".png")]
                log("  PNGs inside: %d  %s" % (len(pngs), ", ".join(pngs[:4]) or "(none)"))
            except Exception as e:
                log("  couldn't list subfolder (%s)" % e)
        log("  image support (PIL): %s" % getattr(eng, "HAVE_PIL", False))

        if getattr(eng, "HAVE_PIL", False):
            try:
                ref0, ref1 = eng.reference_textures(name, dict(self.cfg["spec"]))
                log("  reference loaded: slice0=%s slice1=%s"
                    % (bool(ref0), bool(ref1)))
            except Exception as e:
                log("reference: couldn't load textures/%s (%s)" % (name, e))

        return {
            "ok": bool(bundle),
            "detected": bool(spec),
            "spec": self._spec_summary(),
            "single_slice": (self.cfg["spec"].get("slices", 2) == 1),
            "ref0": _img_to_data_url(ref0),
            "ref1": _img_to_data_url(ref1),
            "log": logs,
        }

    # ---- native file pickers --------------------------------------------
    def pick_png(self, which):
        result = self.window.create_file_dialog(
            webview.OPEN_DIALOG,
            allow_multiple=False,
            file_types=("PNG image (*.png)",),
        )
        if not result:
            return None
        path = result[0] if isinstance(result, (list, tuple)) else result
        if int(which) == 1:
            self.png1 = path
        else:
            self.png0 = path
        return {"path": path, "name": os.path.basename(path)}

    def set_slice_data(self, which, data_url):
        """Accept a base64 PNG data URL for a slice painted in the Forge tab,
        save it to a temp file, and use it as png0/png1 for the next build."""
        if not data_url or "," not in data_url:
            return {"ok": False, "error": "no image data"}
        try:
            raw = base64.b64decode(data_url.split(",", 1)[1])
        except Exception as e:
            return {"ok": False, "error": "bad image data: %s" % e}
        which = int(which)
        try:
            fd, path = tempfile.mkstemp(prefix="forge_slice%d_" % which, suffix=".png")
            with os.fdopen(fd, "wb") as f:
                f.write(raw)
        except Exception as e:
            return {"ok": False, "error": "couldn't save slice: %s" % e}
        old = self._tmp1 if which == 1 else self._tmp0
        if old and os.path.exists(old) and old != path:
            try:
                os.remove(old)
            except Exception:
                pass
        if which == 1:
            self.png1 = path
            self._tmp1 = path
        else:
            self.png0 = path
            self._tmp0 = path
        return {"ok": True, "name": "Forge slice %d" % which}

    # ---- Forge-tab texture auto-load (reads a textures/ folder) ---------
    def list_textures(self):
        """Return every PNG under textures/ as a forward-slash relative path,
        at ANY depth (textures/awp/x.png, textures/awp/sub/y.png, x.png ...).
        Also writes textures_scan.txt next to the app so the exact folder
        contents can be inspected."""
        base = eng.app_dir()
        d = os.path.join(base, "textures")
        out = []
        report = ["POP-1 Skin Forge — texture scan (recursive) v2",
                  "app folder : %s" % base,
                  "looking in : %s" % d,
                  "exists     : %s" % os.path.isdir(d), ""]
        try:
            for root, dirs, files in os.walk(d):
                dirs.sort()
                rel_root = os.path.relpath(root, d)
                for f in sorted(files):
                    rel = f if rel_root == "." else (rel_root + os.sep + f)
                    rel = rel.replace("\\", "/")
                    report.append(rel)
                    if f.lower().endswith(".png"):
                        out.append(rel)
        except Exception as e:
            report.append("scan error: %s" % e)
        report.append("")
        report.append("PNG files found: %d" % len(out))
        try:
            with open(os.path.join(base, "textures_scan.txt"), "w", encoding="utf-8") as fh:
                fh.write("\n".join(report))
        except Exception:
            pass
        return out

    def get_texture(self, name):
        d = os.path.join(eng.app_dir(), "textures")
        rel = (name or "").replace("\\", "/")
        parts = [p for p in rel.split("/") if p and p not in (".", "..")]
        if not parts:
            return None
        p = os.path.join(d, *parts)
        try:                                     # never escape the textures/ folder
            if os.path.commonpath([os.path.abspath(p), os.path.abspath(d)]) != os.path.abspath(d):
                return None
        except Exception:
            return None
        if not os.path.isfile(p):
            return None
        try:
            with open(p, "rb") as f:
                data = f.read()
            return "data:image/png;base64," + base64.b64encode(data).decode("ascii")
        except Exception:
            return None

    # ---- access / licensing (uses eng.LICENSE_URL, e.g. a GitHub Gist) --
    #  The network verification runs on a background thread and the result is
    #  pushed to the page via window.__lic(...), so a slow/failing gist fetch
    #  can NEVER freeze the UI.
    def _license_static(self):
        return {
            "enabled": bool(getattr(eng, "LICENSE_URL", "")),
            "machine_id": eng.machine_id(),
            "key": self.cfg.get("license_key") or "",
        }

    def _remember_verified(self):
        """Persist that this user has been granted access, so the gate never pops up
        again — works offline, survives gist/network hiccups. GW1DDY: once a person
        is verified the window never reappears. This grandfathers the user: they stay
        in even if verification is later switched back on (the toggle then only gates
        people who never got in)."""
        try:
            if not self.cfg.get("forge_verified"):
                self.cfg["forge_verified"] = True
                eng.save_settings(self.cfg)
        except Exception:
            pass

    def _check_access(self):
        """Verify against the gist and read the daily limit in ONE fetch.
        The Forge gates on 'forge_enabled' (falls back to 'enabled' if that
        field is absent) so the author can disable the OLD Swapper app via
        'enabled': false while keeping the Forge alive with
        'forge_enabled': true. Returns {ok,msg,code,limit,machine_id}."""
        url = getattr(eng, "LICENSE_URL", "")
        mine = eng.machine_id()
        out = {"ok": True, "msg": "license check OFF", "code": "no_url",
               "limit": 0, "machine_id": mine}
        # DEV / OWNER EXEMPTION: an 'owner.key' marker file sits next to the app
        # in the dev build and is NEVER shipped in the installer. When present,
        # THIS build skips the gist entirely — always verified, admin, unlimited —
        # so the dev copy keeps working no matter what the key list says (revoked,
        # offline, disabled). The installed/handout copy has no owner.key, so it
        # falls through to the normal licence check below and behaves exactly like
        # any handout user — which is what lets the installer be a real test copy.
        try:
            if os.path.isfile(os.path.join(eng.app_dir(), "owner.key")):
                self._admin = True
                out.update(ok=True, admin=True, code="owner", limit=0,
                           msg="Owner/dev build — licensing bypassed (owner.key present).")
                return out
        except Exception:
            pass
        # Once granted access, remember it FOREVER — the gate never reappears (works
        # offline, survives gist/network hiccups). GW1DDY: once a person is verified,
        # the window never pops up again.
        try:
            if self.cfg.get("forge_verified"):
                out.update(ok=True, code="remembered", msg="Verified — welcome back.")
                return out
        except Exception:
            pass
        if not url:
            return out
        key = (self.cfg.get("license_key") or "").strip()
        # On a cold launch the network/DNS often isn't ready the instant the app opens,
        # so a single fetch fails and the user has to reopen. Retry a few times.
        data = None
        last_err = None
        for _attempt in range(4):
            try:
                bust = ("&" if "?" in url else "?") + "nocache=" + str(int(time.time())) + str(_attempt)
                req = urllib.request.Request(url + bust, headers={
                    "Cache-Control": "no-cache", "User-Agent": "Pop1Forge"})
                with urllib.request.urlopen(req, timeout=12) as r:
                    data = json.loads(r.read().decode("utf-8", "replace"))
                break
            except Exception as e:
                last_err = e
                time.sleep(1.5)
        if data is None:
            out.update(ok=False, msg="Couldn't verify access (no internet?): %s" % last_err, code="net")
            return out
        self._presence_url = (data.get("presence_url") or "").strip()
        # Optional hard kill: "killed": true blocks everyone (rarely needed).
        if data.get("killed") is True:
            out.update(ok=False, msg="Access has been turned off by the author.", code="disabled")
            return out
        # VERIFY TOGGLE — the author flips this in the gist:
        #   "enabled": true   -> OPEN to everyone, no access key needed (verify OFF)
        #   "enabled": false  -> a valid access key is required (verify ON)
        # ("forge_enabled" overrides "enabled" when present; absent = key required.)
        gate = data.get("forge_enabled")
        if gate is None:
            gate = data.get("enabled")
        if gate is True:
            self._remember_verified()          # got in once -> don't ask again
            out.update(ok=True, msg="Verified.", code="open", presence_url=self._presence_url)
            return out
        # verification required -> a valid access key must be present
        if not key:
            out.update(ok=False, msg="No access key entered.", code="no_key")
            return out
        matched = None
        for e in data.get("keys", []):
            if isinstance(e, str) and e == key:
                matched = {"key": e}; break
            if isinstance(e, dict) and e.get("key") == key:
                matched = e; break
        if matched is None:
            out.update(ok=False, msg="This access key is not recognized or has been revoked.", code="unknown_key")
            return out
        if data.get("require_device"):
            bound = (matched.get("device") or "").strip().upper()
            author = getattr(eng, "AUTHOR", "the author")
            if not bound:
                out.update(ok=False, code="unactivated",
                           msg="Not activated on this PC yet.\nYour Machine ID:  %s\nSend this ID to %s to activate your key." % (mine, author))
                return out
            if bound != mine:
                out.update(ok=False, code="wrong_device",
                           msg="This key is locked to a different PC.\nYour Machine ID:  %s" % mine)
                return out
        lim = matched.get("limit", data.get("daily_limit", 0)) or 0
        try:
            lim = int(lim)
        except Exception:
            lim = 0
        self._admin = bool(matched.get("admin"))
        if self._admin:
            # Owner/admin unlock is bound to a specific PC when the admin key has a
            # 'device' set: a leaked admin key won't unlock the owner features on
            # another machine (it still works as a normal key). No device set = any PC.
            adev = (matched.get("device") or "").strip().upper()
            if adev and adev != (mine or "").strip().upper():
                self._admin = False
        self._remember_verified()              # verified once -> never prompt again
        out.update(ok=True, msg="License verified.", code="ok", limit=lim,
                   admin=self._admin, presence_url=self._presence_url)
        return out

    # ---- daily skin-creation limit (tracked locally, per calendar day) ---
    def _today(self):
        return time.strftime("%Y-%m-%d")

    def _build_count(self):
        bc = self.cfg.get("build_count") or {}
        return int(bc.get("count") or 0) if bc.get("date") == self._today() else 0

    def _bump_build_count(self):
        self.cfg["build_count"] = {"date": self._today(), "count": self._build_count() + 1}
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass

    # ---- presence (heartbeat to the author's private backend) -----------
    def _send_heartbeat(self):
        url = getattr(self, "_presence_url", "")
        key = (self.cfg.get("license_key") or "").strip()
        if not url or not key:
            return
        try:
            payload = json.dumps({
                "action": "beat", "key": key, "machine": eng.machine_id(),
                "version": getattr(eng, "VERSION", "?"), "build": APP_BUILD,
            }).encode("utf-8")
            req = urllib.request.Request(url, data=payload,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=8).read()
        except Exception:
            pass

    def _start_heartbeat(self):
        if getattr(self, "_hb_started", False):
            return
        self._hb_started = True

        def loop():
            while True:
                self._send_heartbeat()
                time.sleep(180)     # ping every 3 minutes so "online" stays fresh

        threading.Thread(target=loop, daemon=True).start()

    def admin_presence(self):
        """Admin-only: fetch the who's-online list. Gated both here (admin key)
        and server-side (the backend only answers the admin key)."""
        if not getattr(self, "_admin", False):
            return {"ok": False, "admin": False, "error": "This key is not an admin key."}
        url = getattr(self, "_presence_url", "")
        if not url:
            return {"ok": False, "admin": True, "error": "Presence backend not configured (no presence_url in the gist)."}
        key = (self.cfg.get("license_key") or "").strip()
        try:
            q = url + (("&" if "?" in url else "?") + "action=list&key=" + urllib.parse.quote(key))
            req = urllib.request.Request(q, headers={"Cache-Control": "no-cache"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
            users = data.get("users", data if isinstance(data, list) else [])
            return {"ok": True, "admin": True, "users": users, "now": int(time.time())}
        except Exception as e:
            return {"ok": False, "admin": True, "error": str(e)}

    def _push_license(self):
        win = self.window
        base = self._license_static()

        def worker():
            info = dict(base)
            try:
                acc = self._check_access()
                ok, msg, code = acc["ok"], acc["msg"], acc["code"]
            except Exception as e:
                ok, msg, code = False, "license check error: %s" % e, "err"
                acc = {}
            info.update({"ok": bool(ok), "msg": msg, "code": code, "pending": False,
                         "admin": bool(acc.get("admin"))})
            _log("license   : ok=%s code=%s admin=%s msg=%s"
                 % (ok, code, acc.get("admin"), str(msg).replace("\n", " ")))
            if ok:
                self._start_heartbeat()
                self._send_heartbeat()
            try:
                if win:
                    win.evaluate_js("window.__lic && window.__lic(%s)" % json.dumps(info))
            except Exception:
                _log("license   : evaluate_js push failed:\n" + traceback.format_exc())

        threading.Thread(target=worker, daemon=True).start()

    def license_info(self):
        self._push_license()
        d = self._license_static()
        d["pending"] = True
        # Remembered (or owner) -> unlock instantly so the gate never even flashes.
        try:
            if self.cfg.get("forge_verified") or os.path.isfile(os.path.join(eng.app_dir(), "owner.key")):
                d["ok"] = True
                d["pending"] = False
        except Exception:
            pass
        return d

    def set_license_key(self, key):
        self.cfg["license_key"] = (key or "").strip()
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass
        self._push_license()
        d = self._license_static()
        d["pending"] = True
        return d

    def check_updates(self):
        """Force an update check right now: download + stage the latest. We do NOT reload
        in place — WebView2 caches the page by path and its cache is locked while running,
        so an in-place reload would just show the stale copy. The new page applies cleanly
        on the next restart (see _bust_webview_cache_if_stale), so we say 'restart to apply'."""
        try:
            before = int(_upd_applied().get("build", 0))
            try:
                _download_updates()
            except Exception:
                _log("check_updates: download error\n" + traceback.format_exc())
            after = int(_upd_applied().get("build", 0))
            cur = max(after, BUNDLED_WEB_BUILD)
            got_new = (after > before) and _staged_ok()
            # No in-place reload: WebView2's cache is locked while running, so it would
            # just show the stale page. The restart path clears that cache and loads new.
            return {"ok": True, "updated": bool(got_new),
                    "build": (after if got_new else cur), "reloaded": False}
        except Exception as e:
            _log("check_updates error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def open_output_folder(self):
        folder = self._output_root()
        try:
            os.makedirs(folder, exist_ok=True)
            if os.name == "nt":
                os.startfile(folder)  # noqa
            return {"ok": True, "path": folder}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _output_root(self):
        base = (self.cfg.get("out_dir") or "").strip()
        if not base or not os.path.isdir(base):
            base = eng.app_dir()
        return os.path.join(base, "Bundle Output")

    def list_outputs(self):
        """List the folders inside Bundle Output (newest first) with their files."""
        root = self._output_root()
        folders = []
        try:
            ents = []
            for n in os.listdir(root):
                p = os.path.join(root, n)
                if os.path.isdir(p):
                    ents.append((os.path.getmtime(p), n, p))
            ents.sort(reverse=True)
            for mt, n, p in ents[:40]:
                files = []
                try:
                    for f in sorted(os.listdir(p)):
                        fp = os.path.join(p, f)
                        if os.path.isfile(fp):
                            files.append({"name": f, "size": os.path.getsize(fp)})
                except Exception:
                    pass
                folders.append({"name": n, "path": p, "files": files})
        except Exception:
            pass
        return {"root": root, "folders": folders}

    def open_path(self, path):
        """Open a folder inside Bundle Output in Explorer (path-guarded)."""
        root = os.path.abspath(self._output_root())
        p = os.path.abspath(path or "")
        try:
            if os.path.commonpath([p, root]) != root:
                return {"ok": False, "error": "outside output folder"}
        except Exception:
            return {"ok": False}
        try:
            if os.path.isdir(p):
                if os.name == "nt":
                    os.startfile(p)  # noqa
                return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": False, "error": "not found"}

    def open_latest_output(self):
        root = self._output_root()
        try:
            ents = [(os.path.getmtime(os.path.join(root, n)), os.path.join(root, n))
                    for n in os.listdir(root) if os.path.isdir(os.path.join(root, n))]
            if not ents:
                return {"ok": False}
            ents.sort(reverse=True)
            p = ents[0][1]
            if os.name == "nt":
                os.startfile(p)  # noqa
            return {"ok": True, "path": p}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def save_previews(self, name, shots):
        """Save multi-angle 3D preview PNGs (data URLs) to Previews/<name>/."""
        if not shots:
            return {"ok": False, "error": "no images"}
        safe = "".join(ch if (ch.isalnum() or ch in "-_") else "_" for ch in (name or "skin")).strip("_") or "skin"
        base = (self.cfg.get("out_dir") or "").strip()
        if not base or not os.path.isdir(base):
            base = eng.app_dir()
        folder = os.path.join(base, "Previews", safe)
        try:
            os.makedirs(folder, exist_ok=True)
            for i, durl in enumerate(shots):
                if not durl or "," not in durl:
                    continue
                raw = base64.b64decode(durl.split(",", 1)[1])
                with open(os.path.join(folder, "%s_angle%d.png" % (safe, i + 1)), "wb") as f:
                    f.write(raw)
            if os.name == "nt":
                os.startfile(folder)  # noqa
            return {"ok": True, "path": folder, "count": len(shots)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- Armory: a local skin-showcase catalog you can publish -----------
    def _armory_dir(self):
        base = (self.cfg.get("out_dir") or "").strip()
        if not base or not os.path.isdir(base):
            base = eng.app_dir()
        d = os.path.join(base, "Armory")
        os.makedirs(d, exist_ok=True)
        return d

    def _armory_catalog(self):
        p = os.path.join(self._armory_dir(), "catalog.json")
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            if "items" not in d:
                d["items"] = []
            return d
        except Exception:
            return {"title": "Skin Armory", "contact": "set your contact",
                    "venmo": "GW1DDYVR", "pingId": "1029486783039283271",
                    "webhook": "", "creators": [{"name": "GW1DDY", "folder": ""},
                                                {"name": "Dontay", "folder": ""}],
                    "items": []}

    def _armory_write(self, cat):
        p = os.path.join(self._armory_dir(), "catalog.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(cat, f)

    def armory_list(self):
        cat = self._armory_catalog()
        items = []
        for it in cat.get("items", []):
            imgs = it.get("images", []) or []
            items.append({"id": it.get("id"), "title": it.get("title", ""),
                          "tag": it.get("tag", ""), "tier": it.get("tier", ""),
                          "creator": it.get("creator", ""), "avail": it.get("avail", ""),
                          "count": len(imgs), "cover": imgs[0] if imgs else None})
        return {"title": cat.get("title", "Skin Armory"),
                "contact": cat.get("contact", ""), "venmo": cat.get("venmo", ""),
                "webhook": cat.get("webhook", ""), "pingId": cat.get("pingId", ""),
                "statsUrl": cat.get("statsUrl", ""), "statsKey": cat.get("statsKey", ""),
                "creators": cat.get("creators", [{"name": "GW1DDY", "folder": ""},
                                                  {"name": "Dontay", "folder": ""}]),
                "items": items}

    def armory_add(self, title, tag, avail, desc, images, tier=None, creator=None):
        if not images and not (title or "").strip():
            return {"ok": False, "error": "Add a name or at least one image."}
        cat = self._armory_catalog()
        item = {
            "id": "s" + str(int(time.time() * 1000)),
            "title": (title or "").strip(), "tag": (tag or "").strip(),
            "tier": (tier or "").strip(), "creator": (creator or "").strip(),
            "avail": (avail or "").strip(), "desc": (desc or "").strip(),
            "images": [im for im in (images or []) if im and "," in im],
        }
        cat.setdefault("items", []).insert(0, item)
        try:
            self._armory_write(cat)
            return {"ok": True, "count": len(cat["items"])}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def armory_set_creators(self, creators):
        cat = self._armory_catalog()
        clean = []
        for c in (creators or []):
            nm = (c.get("name") or "").strip()
            if nm:
                clean.append({"name": nm, "folder": (c.get("folder") or "").strip()})
        cat["creators"] = clean or [{"name": "GW1DDY", "folder": ""}]
        try:
            self._armory_write(cat)
            return {"ok": True, "creators": cat["creators"]}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def armory_delete(self, item_id):
        cat = self._armory_catalog()
        cat["items"] = [it for it in cat.get("items", []) if it.get("id") != item_id]
        try:
            self._armory_write(cat)
            return {"ok": True, "count": len(cat["items"])}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def armory_set_meta(self, title, contact, venmo=None, webhook=None, ping_id=None, stats_url=None, stats_key=None):
        cat = self._armory_catalog()
        if title is not None:
            cat["title"] = (title or "").strip() or "Skin Armory"
        if contact is not None:
            cat["contact"] = (contact or "").strip()
        if venmo is not None:
            cat["venmo"] = (venmo or "").strip().lstrip("@")
        if webhook is not None:
            cat["webhook"] = (webhook or "").strip()
        if ping_id is not None:
            cat["pingId"] = "".join(c for c in (ping_id or "") if c.isdigit())
        if stats_url is not None:
            cat["statsUrl"] = (stats_url or "").strip()
        if stats_key is not None:
            cat["statsKey"] = (stats_key or "").strip()
        try:
            self._armory_write(cat)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def armory_publish(self):
        """Bake the catalog into a ready-to-host index.html (view-only)."""
        cat = self._armory_catalog()
        tpl_path = _asset("armory.html")
        if not os.path.exists(tpl_path):
            return {"ok": False, "error": "armory.html template is missing from the app."}
        try:
            with open(tpl_path, "r", encoding="utf-8") as f:
                tpl = f.read()
            inject = "<script>window.__PRELOAD=%s;window.__VIEWONLY=true;</script>\n</head>" \
                     % json.dumps(cat)
            if "</head>" in tpl:
                tpl = tpl.replace("</head>", inject, 1)
            out = os.path.join(self._armory_dir(), "index.html")
            with open(out, "w", encoding="utf-8") as f:
                f.write(tpl)
            if os.name == "nt":
                os.startfile(self._armory_dir())  # noqa
            return {"ok": True, "path": out}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def open_armory(self):
        try:
            d = self._armory_dir()
            if os.name == "nt":
                os.startfile(d)  # noqa
            return {"ok": True, "path": d}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    @staticmethod
    def _safe_name(s):
        s = "".join(ch if (ch.isalnum() or ch in "-_ ") else "_" for ch in (s or "")).strip()
        return s.rstrip(". ") or "misc"

    def _creator_folder(self, name):
        cat = self._armory_catalog()
        for c in cat.get("creators", []):
            if (c.get("name") or "").strip().lower() == (name or "").strip().lower():
                return (c.get("folder") or "").strip()
        return ""

    def armory_file_bundle(self, creator, weapon, skinname=None):
        """Copy the most-recently-built bundle into the creator's Drive folder,
        organised as <creator folder>/<weapon>/<skin name>/."""
        folder = self._creator_folder(creator)
        if not folder:
            return {"ok": False, "error": "No Drive folder set for '%s' — set one in Creators & Drive folders." % creator}
        if not os.path.isdir(folder):
            return {"ok": False, "error": "That Drive folder doesn't exist yet: %s" % folder}
        root = self._output_root()
        try:
            ents = [(os.path.getmtime(os.path.join(root, n)), n)
                    for n in os.listdir(root) if os.path.isdir(os.path.join(root, n))]
        except Exception:
            ents = []
        if not ents:
            return {"ok": False, "error": "No built bundle found — build one first."}
        ents.sort(reverse=True)
        src_name = ents[0][1]
        src = os.path.join(root, src_name)
        skin = self._safe_name(skinname or src_name)
        dest = os.path.join(folder, self._safe_name(weapon), skin)
        try:
            os.makedirs(dest, exist_ok=True)
            copied = 0
            for f in os.listdir(src):
                fp = os.path.join(src, f)
                if os.path.isfile(fp):
                    shutil.copy2(fp, os.path.join(dest, f))
                    copied += 1
            if copied == 0:
                return {"ok": False, "error": "Nothing to copy from the last build."}
            return {"ok": True, "dest": dest, "copied": copied, "creator": creator}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _orders_dir(self):
        base = (self.cfg.get("out_dir") or "").strip()
        if not base or not os.path.isdir(base):
            base = eng.app_dir()
        d = os.path.join(base, "Orders")
        os.makedirs(d, exist_ok=True)
        return d

    def list_deliverables(self):
        """Scan every creator's Drive folder for built skins (weapon/skin/bundle)."""
        cat = self._armory_catalog()
        out = []
        for c in cat.get("creators", []):
            folder = (c.get("folder") or "").strip()
            name = c.get("name") or ""
            if not folder or not os.path.isdir(folder):
                continue
            try:
                for weapon in sorted(os.listdir(folder)):
                    wp = os.path.join(folder, weapon)
                    if not os.path.isdir(wp):
                        continue
                    for skin in sorted(os.listdir(wp)):
                        sp = os.path.join(wp, skin)
                        if not os.path.isdir(sp):
                            continue
                        files = [f for f in os.listdir(sp) if os.path.isfile(os.path.join(sp, f))]
                        if files:
                            out.append({"creator": name, "weapon": weapon, "skin": skin,
                                        "path": sp, "files": len(files)})
            except Exception:
                pass
        return {"deliverables": out}

    def fulfill_order(self, buyer, paths):
        """Copy the chosen skins into Orders/<buyer>_<id>/ and zip it up to send."""
        if not paths:
            return {"ok": False, "error": "Pick at least one skin for the order."}
        safe = self._safe_name(buyer) or "buyer"
        stamp = str(int(time.time()))[-6:]
        dest_root = os.path.join(self._orders_dir(), safe + "_" + stamp)
        try:
            copied = 0
            for p in paths:
                if not p or not os.path.isdir(p):
                    continue
                skinname = self._safe_name(os.path.basename(p.rstrip("/\\")))
                dst = os.path.join(dest_root, skinname)
                os.makedirs(dst, exist_ok=True)
                for f in os.listdir(p):
                    fp = os.path.join(p, f)
                    if os.path.isfile(fp):
                        shutil.copy2(fp, os.path.join(dst, f))
                        copied += 1
            if copied == 0:
                return {"ok": False, "error": "None of those skins had files to copy."}
            zip_path = shutil.make_archive(dest_root, "zip", dest_root)
            if os.name == "nt":
                os.startfile(self._orders_dir())  # noqa
            return {"ok": True, "zip": os.path.basename(zip_path), "copied": copied}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- the build/inject pipeline (runs in a worker thread) ------------
    def _projects_dir(self):
        base = (self.cfg.get("out_dir") or "").strip()
        if not base or not os.path.isdir(base):
            base = eng.app_dir()
        d = os.path.join(base, "Projects")
        os.makedirs(d, exist_ok=True)   # created on first save
        return d

    def save_project(self, name, data):
        try:
            safe = self._safe_name(name) or "project"
            p = os.path.join(self._projects_dir(), safe + ".skinproj.json")
            with open(p, "w", encoding="utf-8") as f:
                f.write(data or "")
            return {"ok": True, "path": p, "name": safe}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def list_projects(self):
        d = self._projects_dir()
        out = []
        try:
            for n in os.listdir(d):
                if not n.lower().endswith(".skinproj.json"):
                    continue
                p = os.path.join(d, n)
                meta = {"name": n[:-len(".skinproj.json")],
                        "date": int(os.path.getmtime(p) * 1000),
                        "weapon": "", "layers": 0, "thumb": ""}
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        o = json.load(f)
                    meta["weapon"] = o.get("weapon", "")
                    meta["layers"] = len(o.get("layers", []))
                    meta["thumb"] = o.get("_thumb", "")
                except Exception:
                    pass
                out.append(meta)
        except Exception:
            pass
        out.sort(key=lambda m: m["date"], reverse=True)
        return {"dir": d, "projects": out}

    def load_project(self, name):
        try:
            p = os.path.join(self._projects_dir(), self._safe_name(name) + ".skinproj.json")
            with open(p, "r", encoding="utf-8") as f:
                return {"ok": True, "json": f.read()}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def delete_project(self, name):
        try:
            p = os.path.join(self._projects_dir(), self._safe_name(name) + ".skinproj.json")
            if os.path.isfile(p):
                os.remove(p)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- build history + batch rebuild ----------------------------------
    def _hist_dir(self):
        d = os.path.join(eng.app_dir(), "BuildHistory")
        os.makedirs(d, exist_ok=True)
        return d

    def _hist_path(self):
        return os.path.join(self._hist_dir(), "history.json")

    def _load_history(self):
        try:
            with open(self._hist_path(), "r", encoding="utf-8") as f:
                d = json.load(f)
            b = d.get("builds", []) if isinstance(d, dict) else []
            return b if isinstance(b, list) else []
        except Exception:
            return []

    def _save_history(self, builds):
        try:
            with open(self._hist_path(), "w", encoding="utf-8") as f:
                json.dump({"builds": builds[-200:]}, f)
        except Exception:
            pass

    def _latest_output(self):
        """Return (folder_path, [file dicts]) for the most-recently-built bundle."""
        root = self._output_root()
        try:
            ents = [(os.path.getmtime(os.path.join(root, n)), os.path.join(root, n))
                    for n in os.listdir(root) if os.path.isdir(os.path.join(root, n))]
        except Exception:
            ents = []
        if not ents:
            return None, []
        ents.sort(reverse=True)
        p = ents[0][1]
        files = []
        try:
            for f in sorted(os.listdir(p)):
                fp = os.path.join(p, f)
                if os.path.isfile(fp):
                    files.append({"name": f, "size": os.path.getsize(fp)})
        except Exception:
            pass
        return p, files

    def _record_build(self, name, weapon, creator, single):
        """Log a successful build and snapshot its source slices so it can be rebuilt."""
        bid = "b%d_%s" % (int(time.time() * 1000),
                          os.urandom(2).hex())
        snap = os.path.join(self._hist_dir(), bid)
        srcs = []
        try:
            os.makedirs(snap, exist_ok=True)
            if self.png0 and os.path.isfile(self.png0):
                dst = os.path.join(snap, "slice0.png")
                shutil.copy2(self.png0, dst)
                srcs.append(dst)
            if not single and self.png1 and os.path.isfile(self.png1):
                dst = os.path.join(snap, "slice1.png")
                shutil.copy2(self.png1, dst)
                srcs.append(dst)
        except Exception:
            pass
        folder, files = self._latest_output()
        entry = {
            "id": bid,
            "name": (name or "skin"),
            "weapon": (weapon or ""),
            "creator": (creator or ""),
            "single": bool(single),
            "ts": int(time.time()),
            "folder": folder or "",
            "files": len(files),
            "srcs": srcs,
        }
        builds = self._load_history()
        builds.append(entry)
        self._save_history(builds)
        return entry

    def list_builds(self):
        """Return the build history, newest first, for the File Export panel."""
        out = []
        for b in reversed(self._load_history()):
            folder = b.get("folder") or ""
            out.append({
                "id": b.get("id"),
                "name": b.get("name") or "skin",
                "weapon": b.get("weapon") or "",
                "creator": b.get("creator") or "",
                "single": bool(b.get("single")),
                "ts": int(b.get("ts") or 0),
                "files": int(b.get("files") or 0),
                "folder": folder,
                "hasFolder": bool(folder and os.path.isdir(folder)),
                "rebuildable": bool(b.get("srcs")) and all(os.path.isfile(s) for s in (b.get("srcs") or [])),
            })
        return {"ok": True, "builds": out}

    def open_build(self, build_id):
        for b in self._load_history():
            if b.get("id") == build_id:
                p = b.get("folder") or ""
                if p and os.path.isdir(p):
                    try:
                        if os.name == "nt":
                            os.startfile(p)  # noqa
                        return {"ok": True}
                    except Exception as e:
                        return {"ok": False, "error": str(e)}
                return {"ok": False, "error": "that build's output folder is gone"}
        return {"ok": False, "error": "build not found"}

    def delete_build(self, build_id):
        builds = self._load_history()
        kept = [b for b in builds if b.get("id") != build_id]
        if len(kept) == len(builds):
            return {"ok": False, "error": "build not found"}
        try:
            snap = os.path.join(self._hist_dir(), build_id)
            if os.path.isdir(snap):
                shutil.rmtree(snap, ignore_errors=True)
        except Exception:
            pass
        self._save_history(kept)
        return {"ok": True}

    def _run_one(self, name, single, swap, repack, push, extra_layers=None,
                 color_png0=None, color_png1=None):
        """Shared build core: access check, daily limit, pipeline. Returns True on success.
        color_png0/1 override the colour slices (e.g. a preset-tinted copy)."""
        acc = self._check_access()
        push("access: " + acc["msg"], "ok" if acc["ok"] else "er")
        if not acc["ok"]:
            return False
        limit = int(acc.get("limit") or 0)
        used = self._build_count()
        if limit and used >= limit:
            push("Daily limit reached: %d of %d skins today. Try again tomorrow."
                 % (used, limit), "er")
            return False
        if limit:
            push("skin %d of %d allowed today" % (used + 1, limit))
        try:
            eng.run_pipeline(self.cfg, color_png0 or self.png0, color_png1 or self.png1,
                             bool(swap), bool(repack),
                             bool(single), name, push, extra_layers=extra_layers)
            self._bump_build_count()
            return True
        except eng.SwapError as e:
            push("ERROR: " + str(e), "er")
            return False
        except Exception:
            push("UNEXPECTED:\n" + traceback.format_exc(), "er")
            return False

    def _prep_rebuild(self, entry):
        """Restore an old build's source slices + weapon spec so it can be rebuilt."""
        srcs = entry.get("srcs") or []
        s0 = next((s for s in srcs if s.endswith("slice0.png")), None)
        s1 = next((s for s in srcs if s.endswith("slice1.png")), None)
        if not s0 or not os.path.isfile(s0):
            return False, "source slice 0 is missing"
        self.png0 = s0
        self.png1 = s1 if (s1 and os.path.isfile(s1)) else None
        if entry.get("weapon"):
            try:
                self.select_weapon(entry["weapon"])
            except Exception:
                pass
        return True, ""

    def batch_rebuild(self, ids):
        """Rebuild a set of past builds one after another, refiling each to its creator."""
        ids = list(ids or [])
        if not ids:
            return {"ok": False, "error": "nothing selected"}
        by_id = {b.get("id"): b for b in self._load_history()}
        win = self.window

        def push(line, tag=None):
            try:
                win.evaluate_js("window.__forgeLog && window.__forgeLog(%s)"
                                % json.dumps({"line": str(line), "tag": tag or ""}))
            except Exception:
                pass

        def finish(ok):
            try:
                win.evaluate_js("window.__forgeDone && window.__forgeDone(%s)"
                                % ("true" if ok else "false"))
            except Exception:
                pass

        def worker():
            total, done = len(ids), 0
            for i, bid in enumerate(ids):
                entry = by_id.get(bid)
                label = (entry.get("name") if entry else bid) or "skin"
                push("\u2500\u2500 [%d/%d] %s \u00b7 %s \u2500\u2500"
                     % (i + 1, total, label, (entry and entry.get("weapon")) or "?"))
                if not entry:
                    push("  build not found \u2014 skipped", "er")
                    continue
                okp, err = self._prep_rebuild(entry)
                if not okp:
                    push("  can't rebuild: " + err, "er")
                    continue
                if self._run_one(label, entry.get("single"), False, True, push):
                    done += 1
                    cr = entry.get("creator")
                    if cr:
                        try:
                            r = self.armory_file_bundle(cr, entry.get("weapon") or "", label)
                            if r and r.get("ok"):
                                push("  filed to %s\u2019s Drive (%d file%s)"
                                     % (cr, r["copied"], "s" if r["copied"] > 1 else ""), "ok")
                            elif r and r.get("error"):
                                push("  Drive filing skipped: " + r["error"], "er")
                        except Exception:
                            pass
            push("\u2500\u2500 batch done: %d of %d rebuilt \u2500\u2500"
                 % (done, total), "ok" if done == total else "er")
            finish(done == total and done > 0)

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True, "started": True, "count": len(ids)}

    # ---- shiny / reflective finish (MGE metallic-gloss array) -----------
    def material_presets(self):
        """Finish presets for the Forge 'Finish' dropdown: [{key,label}, ...]."""
        if matpre is None:
            return {"ok": False, "presets": []}
        return {"ok": True,
                "presets": [{"key": k, "label": lbl,
                             "metallic": matpre.PRESETS[k].get("metallic", 0),
                             "gloss": matpre.PRESETS[k].get("gloss", 0)}
                            for k, lbl in matpre.preset_list()]}

    def autoskin_starters(self):
        """Bundled starter patterns for the Auto-skin generator: [{name,dataURL}].
        Also picks up any PNGs the user drops into the 'Auto Textures' folder."""
        import glob
        roots = []
        mp = getattr(sys, "_MEIPASS", None)
        if mp:
            roots.append(os.path.join(mp, "Auto Textures"))
        try:
            roots.append(os.path.join(eng.app_dir(), "Auto Textures"))
        except Exception:
            pass
        seen = {}
        for r in roots:
            if not r or not os.path.isdir(r):
                continue
            for p in sorted(glob.glob(os.path.join(r, "*.png"))):
                nm = os.path.splitext(os.path.basename(p))[0]
                if nm in seen:
                    continue
                try:
                    with open(p, "rb") as f:
                        seen[nm] = ("data:image/png;base64,"
                                    + base64.b64encode(f.read()).decode("ascii"))
                except Exception:
                    pass
        return {"ok": True,
                "textures": [{"name": k, "dataURL": v} for k, v in seen.items()]}

    def _mge_shine_layer(self, metallic, gloss, preset=None):
        """Auto-detect this weapon's MGE (metallic-gloss) array and return a
        run_pipeline extra-layer for the finish. With a `preset` it builds a
        spatially-varying finish map from the colour art (reads like a real
        skin); without one it paints a uniform metallic/gloss over the whole gun.
        Returns (layer, None) or (None, reason)."""
        bundle = (self.cfg.get("bundle_path") or "")
        if not bundle or not os.path.isfile(bundle):
            return None, "no clean bundle for this weapon"
        try:
            import UnityPy
            from PIL import Image
        except Exception:
            return None, "imaging libraries unavailable in this build"
        mge = None
        try:
            env = UnityPy.load(bundle)
            for obj in getattr(env, "objects", []):
                if getattr(obj.type, "name", "") != "Texture2DArray":
                    continue
                try:
                    t = obj.read_typetree()
                except Exception:
                    continue
                if "MGE" in (t.get("m_Name") or "").upper():
                    mge = t
                    break
        except Exception as e:
            return None, "couldn't read bundle: %s" % e
        if not mge:
            return None, "this weapon has no MGE (shine) array"
        sd = mge.get("m_StreamData") or {}
        if not int(sd.get("size") or 0) or not sd.get("path"):
            return None, "MGE array isn't streamed as expected"
        depth = int(mge.get("m_Depth") or 2)
        size = int(sd.get("size"))
        spec = {
            "name": mge.get("m_Name") or "MGE_1p_tarray",
            "width": int(mge.get("m_Width") or 2048),
            "height": int(mge.get("m_Height") or 2048),
            "slices": depth,
            "per_slice": size // depth if depth else size,
            "total": size,
            "stream_offset": int(sd.get("offset") or 0),
            "texconv_fmt": eng._FMT_MAP.get(mge.get("m_Format"), "BC3_UNORM"),
            "ress_name": os.path.basename(sd.get("path") or ""),
        }
        # A preset builds a spatially-varying finish map from the colour art
        # (different finish on different parts of the gun) so the result reads
        # like a designed skin. No preset -> the original uniform finish.
        if preset and preset != "custom" and matpre is not None and self.png0:
            try:
                sz = (spec["width"], spec["height"])
                p0 = os.path.join(tempfile.gettempdir(), "p1forge_mge_%s_s0.png" % preset)
                matpre.build_mge(self.png0, preset, size=sz).save(p0)
                p1 = p0
                if depth > 1 and self.png1:
                    p1 = os.path.join(tempfile.gettempdir(), "p1forge_mge_%s_s1.png" % preset)
                    matpre.build_mge(self.png1, preset, size=sz).save(p1)
                return {"spec": spec, "png0": p0, "png1": p1, "single": depth <= 1}, None
            except Exception as e:
                return None, "couldn't build %s finish map: %s" % (preset, e)

        # Uniform map: R=metallic, G=gloss, B=emission(0), A=gloss -- A carries gloss
        # too so it works whether the shader reads smoothness from G or from A.
        m = max(0, min(255, int(round(float(metallic) * 2.55))))
        g = max(0, min(255, int(round(float(gloss) * 2.55))))
        png = os.path.join(tempfile.gettempdir(), "p1forge_mge_%d_%d.png" % (m, g))
        try:
            Image.new("RGBA", (spec["width"], spec["height"]), (m, g, 0, g)).save(png)
        except Exception as e:
            return None, "couldn't build shine map: %s" % e
        return {"spec": spec, "png0": png, "png1": png, "single": depth <= 1}, None

    def _decode_bundle_array(self, bundle, spec):
        """Decode a Texture2DArray's top-mip slices from `bundle` to PIL RGB images
        (used to blend an engraving onto the STOCK normal so existing detail is
        kept). Returns [] on any failure -- callers fall back to a flat base."""
        try:
            import UnityPy, texture2ddecoder, numpy as np
            from PIL import Image
        except Exception:
            return []
        try:
            env = UnityPy.load(bundle)
            bf = list(env.files.values())[0]
            resS = None
            for k, f in getattr(bf, "files", {}).items():
                if k.lower().endswith(".ress"):
                    resS = f
                    break
            if resS is None:
                return []
            data = resS.bytes if hasattr(resS, "bytes") else bytes(resS.view)
            w, h = int(spec["width"]), int(spec["height"])
            per = int(spec["per_slice"]); off0 = int(spec["stream_offset"])
            nsl = int(spec["slices"]); mip0 = w * h            # BC3 = 1 byte/pixel
            out = []
            for i in range(nsl):
                base = off0 + i * per
                raw = texture2ddecoder.decode_bc3(bytes(data[base:base + mip0]), w, h)  # BGRA
                a = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 4)
                rgb = np.ascontiguousarray(a[..., [2, 1, 0]])   # BGR -> RGB
                out.append(Image.fromarray(rgb, "RGB"))
            return out
        except Exception:
            _log("decode_bundle_array error:\n" + traceback.format_exc())
            return []

    def _nnn_layer(self, mask_path, depth=1.0, recessed=True, blend=True):
        """Build a run_pipeline extra-layer that carves an engraving into this
        weapon's NNN (normal / surface-relief) array so it catches light in-game
        like real engraving. `mask_path` = a black/white image (white = the mark).
        Blending keeps the gun's existing detail. Returns (layer, None) or
        (None, reason)."""
        bundle = (self.cfg.get("bundle_path") or "")
        if not bundle or not os.path.isfile(bundle):
            return None, "no clean bundle for this weapon"
        if not mask_path or not os.path.isfile(mask_path):
            return None, "pick an engraving image first"
        try:
            import UnityPy, numpy  # noqa: F401  (numpy needed by the normal builder)
            from PIL import Image
        except Exception:
            return None, "imaging libraries unavailable in this build"
        nnn = None
        try:
            env = UnityPy.load(bundle)
            for obj in getattr(env, "objects", []):
                if getattr(obj.type, "name", "") != "Texture2DArray":
                    continue
                try:
                    t = obj.read_typetree()
                except Exception:
                    continue
                if "NNN" in (t.get("m_Name") or "").upper():
                    nnn = t
                    break
        except Exception as e:
            return None, "couldn't read bundle: %s" % e
        if not nnn:
            return None, "this weapon has no NNN (normal) array"
        sd = nnn.get("m_StreamData") or {}
        if not int(sd.get("size") or 0) or not sd.get("path"):
            return None, "NNN array isn't streamed as expected"
        nsl = int(nnn.get("m_Depth") or 2)
        size = int(sd.get("size"))
        w = int(nnn.get("m_Width") or 2048); h = int(nnn.get("m_Height") or 2048)
        spec = {
            "name": nnn.get("m_Name") or "NNN_1p_tarray",
            "width": w, "height": h, "slices": nsl,
            "per_slice": size // nsl if nsl else size,
            "total": size,
            "stream_offset": int(sd.get("offset") or 0),
            "texconv_fmt": eng._FMT_MAP.get(nnn.get("m_Format"), "BC3_UNORM"),
            "ress_name": os.path.basename(sd.get("path") or ""),
        }
        try:
            mask = Image.open(mask_path)
        except Exception as e:
            return None, "couldn't open engraving image: %s" % e
        bases = [None, None]
        if blend:
            slc = self._decode_bundle_array(bundle, spec)      # stock normal slices
            if slc:
                bases = (slc + slc)[:2]
        sz = (w, h)
        try:
            p0 = os.path.join(tempfile.gettempdir(), "p1forge_nnn_s0.png")
            _build_engraving_normal(mask, base=bases[0], depth=depth,
                                    recessed=recessed, size=sz).save(p0)
            p1 = p0
            if nsl > 1:
                p1 = os.path.join(tempfile.gettempdir(), "p1forge_nnn_s1.png")
                _build_engraving_normal(mask, base=bases[1], depth=depth,
                                        recessed=recessed, size=sz).save(p1)
        except Exception as e:
            return None, "couldn't build normal map: %s" % e
        return {"spec": spec, "png0": p0, "png1": p1, "single": nsl <= 1}, None

    def nnn_apply(self, mask_b64="", depth=1.0, recessed=True, blend=True,
                  single_slice=None, swap_order=False, inject_game=True):
        """Carve an engraving into the CURRENT weapon's normal (NNN) map so it
        catches light in-game like real engraving. `mask_b64` = a black/white
        image, white = the mark. Rebuilds the weapon's bundle with the engraving
        added on top of the stock surface; installs it when inject_game."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not (self.cfg.get("bundle_path") and self.png0):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        try:
            data = base64.b64decode((mask_b64 or "").split(",")[-1]) if mask_b64 else b""
        except Exception as e:
            return {"ok": False, "error": "bad image: %s" % e}
        if not data:
            return {"ok": False, "error": "drop or pick an engraving image first"}
        mp = os.path.join(tempfile.gettempdir(), "p1forge_engrave_src.png")
        try:
            with open(mp, "wb") as f:
                f.write(data)
        except Exception as e:
            return {"ok": False, "error": "couldn't save image: %s" % e}
        layer, err = self._nnn_layer(mp, depth=float(depth or 1.0),
                                     recessed=bool(recessed), blend=bool(blend))
        if err:
            return {"ok": False, "error": err}
        logs = []
        def push(m, t=None):
            logs.append(str(m))
        spec = self.cfg.get("spec", {}) or {}
        name = (spec.get("name") or "weapon").replace("_1p_tarray", "") + "_engraved"
        single = (spec.get("slices", 2) == 1) if single_slice is None else bool(single_slice)
        ok = self._run_one(name, single, bool(swap_order), True, push,
                           extra_layers=[layer], color_png0=self.png0, color_png1=self.png1)
        if ok and inject_game:
            push("─ inject into game ─")
            try:
                self._inject_weapon_live(name, push)
            except Exception:
                push("install failed:\n" + traceback.format_exc())
        tail = [l for l in logs if l][-60:]
        return {"ok": bool(ok), "log": "\n".join(tail),
                "error": ("" if ok else "build failed — see log")}

    def _array_layer(self, name_substr, png0, png1):
        """Generalized run_pipeline extra-layer for ANY of the weapon's texture
        arrays (MGE, NNN, …) from pre-built slice PNGs. (Generalizes
        _mge_shine_layer / _nnn_layer for the PBR importer.)"""
        bundle = (self.cfg.get("bundle_path") or "")
        if not bundle or not os.path.isfile(bundle):
            return None, "no clean bundle for this weapon"
        try:
            import UnityPy  # noqa: F401
        except Exception:
            return None, "imaging libraries unavailable in this build"
        arr = None
        try:
            env = UnityPy.load(bundle)
            for obj in getattr(env, "objects", []):
                if getattr(obj.type, "name", "") != "Texture2DArray":
                    continue
                try:
                    t = obj.read_typetree()
                except Exception:
                    continue
                if name_substr.upper() in (t.get("m_Name") or "").upper():
                    arr = t
                    break
        except Exception as e:
            return None, "couldn't read bundle: %s" % e
        if not arr:
            return None, "this weapon has no %s array" % name_substr
        sd = arr.get("m_StreamData") or {}
        if not int(sd.get("size") or 0) or not sd.get("path"):
            return None, "%s array isn't streamed as expected" % name_substr
        nsl = int(arr.get("m_Depth") or 2)
        size = int(sd.get("size"))
        spec = {
            "name": arr.get("m_Name"),
            "width": int(arr.get("m_Width") or 2048),
            "height": int(arr.get("m_Height") or 2048),
            "slices": nsl, "per_slice": size // nsl if nsl else size, "total": size,
            "stream_offset": int(sd.get("offset") or 0),
            "texconv_fmt": eng._FMT_MAP.get(arr.get("m_Format"), "BC3_UNORM"),
            "ress_name": os.path.basename(sd.get("path") or ""),
        }
        # the encode needs each PNG at the array's exact dims, or the raw blob won't
        # match per_slice -> resize any off-size import in place (safety net).
        try:
            from PIL import Image
            for pp in {png0, png1 or png0}:
                if pp and os.path.isfile(pp):
                    im = Image.open(pp)
                    if im.size != (spec["width"], spec["height"]):
                        im.convert("RGBA").resize((spec["width"], spec["height"]),
                                                  Image.LANCZOS).save(pp)
        except Exception:
            pass
        return {"spec": spec, "png0": png0, "png1": png1 or png0, "single": nsl <= 1}, None

    def _save_b64_png(self, b64, tag):
        """Write a data-URL/base64 PNG to a temp file; '' if empty/unreadable."""
        if not b64:
            return ""
        try:
            data = base64.b64decode((b64 or "").split(",")[-1])
            if not data:
                return ""
            p = os.path.join(tempfile.gettempdir(), "p1forge_pbr_%s.png" % tag)
            with open(p, "wb") as f:
                f.write(data)
            return p
        except Exception:
            return ""

    def pbr_import(self, ccc0="", ccc1="", mge0="", mge1="", nnn0="", nnn1="",
                   single_slice=None, swap_order=False, inject_game=True):
        """Inject a full PBR texture set into the weapon's arrays: colour -> CCC,
        packed metallic/gloss -> MGE, normal -> NNN. Each is a per-slice PNG (b64);
        the frontend packs MGE and splits maps into slices. An empty channel keeps
        the weapon's current/stock value for it. Owner-only."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not self.cfg.get("bundle_path"):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        c0 = self._save_b64_png(ccc0, "ccc0"); c1 = self._save_b64_png(ccc1, "ccc1")
        m0 = self._save_b64_png(mge0, "mge0"); m1 = self._save_b64_png(mge1, "mge1")
        n0 = self._save_b64_png(nnn0, "nnn0"); n1 = self._save_b64_png(nnn1, "nnn1")
        color0 = c0 or self.png0
        color1 = c1 or self.png1
        if not color0:
            return {"ok": False, "error": "no colour to build — import a base-colour map or load a weapon skin first."}
        layers = []
        for nm, a, b in (("MGE", m0, m1), ("NNN", n0, n1)):
            if a:
                ly, err = self._array_layer(nm, a, b)
                if err:
                    return {"ok": False, "error": "%s: %s" % (nm, err)}
                layers.append(ly)
        logs = []
        def push(m, t=None):
            logs.append(str(m))
        spec = self.cfg.get("spec", {}) or {}
        name = (spec.get("name") or "weapon").replace("_1p_tarray", "") + "_pbr"
        single = (spec.get("slices", 2) == 1) if single_slice is None else bool(single_slice)
        ok = self._run_one(name, single, bool(swap_order), True, push,
                           extra_layers=(layers or None),
                           color_png0=color0, color_png1=color1)
        if ok and inject_game:
            push("─ inject into game ─")
            try:
                self._inject_weapon_live(name, push)
            except Exception:
                push("install failed:\n" + traceback.format_exc())
        tail = [l for l in logs if l][-60:]
        return {"ok": bool(ok), "channels": {"ccc": bool(c0), "mge": bool(m0), "nnn": bool(n0)},
                "log": "\n".join(tail), "error": ("" if ok else "build failed — see log")}

    def _array_spec(self, name_substr):
        """Detect the weapon's <name_substr> Texture2DArray -> its spec, or None."""
        bundle = (self.cfg.get("bundle_path") or "")
        if not bundle or not os.path.isfile(bundle):
            return None
        try:
            import UnityPy
            env = UnityPy.load(bundle)
            for obj in getattr(env, "objects", []):
                if getattr(obj.type, "name", "") != "Texture2DArray":
                    continue
                try:
                    t = obj.read_typetree()
                except Exception:
                    continue
                if name_substr.upper() in (t.get("m_Name") or "").upper():
                    sd = t.get("m_StreamData") or {}
                    if not int(sd.get("size") or 0):
                        return None
                    nsl = int(t.get("m_Depth") or 2); size = int(sd.get("size"))
                    return {"name": t.get("m_Name"), "width": int(t.get("m_Width") or 2048),
                            "height": int(t.get("m_Height") or 2048), "slices": nsl,
                            "per_slice": size // nsl if nsl else size, "total": size,
                            "stream_offset": int(sd.get("offset") or 0),
                            "texconv_fmt": eng._FMT_MAP.get(t.get("m_Format"), "BC3_UNORM"),
                            "ress_name": os.path.basename(sd.get("path") or "")}
        except Exception:
            _log("array_spec error:\n" + traceback.format_exc())
        return None

    def smart_wear(self, edge=0.6, cavity=0.5, metal_edges=True, pm0="", pm1="", inject_game=True):
        """One-click aging: read the weapon's own normal map for curvature, then
        scuff the convex EDGES of your current skin toward bare metal and settle
        grime into the concave CAVITIES -- the Substance smart-wear look, native.
        Wears the colours you've built (self.png0/1); metal_edges also makes the
        worn edges metallic/glossy in-game. Owner-only."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not self.cfg.get("bundle_path"):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        if not self.png0:
            return {"ok": False, "error": "Build or load a weapon skin first — wear ages your current colours."}
        try:
            import numpy as np
            from PIL import Image
        except Exception:
            return {"ok": False, "error": "imaging libraries unavailable in this build"}
        bundle = self.cfg["bundle_path"]
        nspec = self._array_spec("NNN")
        if not nspec:
            return {"ok": False, "error": "this weapon has no normal map to read wear from."}
        nnn = self._decode_bundle_array(bundle, nspec)
        if not nnn:
            return {"ok": False, "error": "couldn't read the weapon's normal map."}
        mspec = self._array_spec("MGE") if metal_edges else None
        mge = self._decode_bundle_array(bundle, mspec) if mspec else []
        e = max(0.0, min(1.5, float(edge or 0)))
        cav = max(0.0, min(1.5, float(cavity or 0)))
        colors = [self.png0, self.png1 or self.png0]
        out_col, out_mge = [], []
        try:
            for i in range(2):
                ns = nnn[i % len(nnn)]
                w, h = ns.size
                curv = _curvature_from_normal(np.asarray(ns.convert("RGB")))
                cp = colors[i]
                if cp and os.path.isfile(cp):
                    col = np.asarray(Image.open(cp).convert("RGB").resize((w, h)))
                else:
                    col = np.full((h, w, 3), 128, "uint8")
                worn = _apply_wear(col, curv, e, cav)
                mask = self._load_mask([pm0, pm1][i], w, h)
                if mask is not None:
                    worn = _blend_by_mask(worn, col, mask)
                op = os.path.join(tempfile.gettempdir(), "p1forge_wear_col%d.png" % i)
                Image.fromarray(worn, "RGB").save(op)
                out_col.append(op)
                if metal_edges and mge:
                    ms = np.asarray(mge[i % len(mge)].convert("RGB").resize((w, h)))
                    bm = _boost_mge_edges(ms, curv, e)
                    if mask is not None:
                        bm = _blend_by_mask(bm, np.dstack([ms, ms[..., 1]]), mask)
                    mp = os.path.join(tempfile.gettempdir(), "p1forge_wear_mge%d.png" % i)
                    Image.fromarray(bm, "RGBA").save(mp)
                    out_mge.append(mp)
        except Exception as ex:
            _log("smart_wear build error:\n" + traceback.format_exc())
            return {"ok": False, "error": "couldn't build wear: %s" % ex}
        layers = []
        if metal_edges and len(out_mge) == 2:
            ly, err = self._array_layer("MGE", out_mge[0], out_mge[1])
            if not err:
                layers.append(ly)
        return self._finish_surface(out_col, layers, "wear", inject_game)

    def _load_mask(self, b64, w, h):
        """A per-part white-on-black mask (b64) -> (H,W) float [0,1], or None."""
        if not b64:
            return None
        try:
            import numpy as np
            from PIL import Image
            data = base64.b64decode((b64 or "").split(",")[-1])
            if not data:
                return None
            m = Image.open(io.BytesIO(data)).convert("L").resize((w, h))
            return np.asarray(m, "float32") / 255.0
        except Exception:
            return None

    def _cur_color(self, i, w, h):
        """The current colour slice i as (H,W,3) uint8, or None."""
        try:
            import numpy as np
            from PIL import Image
            p = [self.png0, self.png1 or self.png0][i]
            if p and os.path.isfile(p):
                return np.asarray(Image.open(p).convert("RGB").resize((w, h)))
        except Exception:
            pass
        return None

    def material_apply(self, name="gunmetal", pm0="", pm1="", inject_game=True):
        """Reskin the weapon (or just the selected parts) with a procedural
        material — real metal/gunmetal/carbon/etc. Writes colour + finish (MGE)
        and blends the material's micro-relief onto the stock normal (keeps the
        gun's panel lines). pm0/pm1 = optional per-part masks. Owner-only."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not self.cfg.get("bundle_path"):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        try:
            import numpy as np
            from PIL import Image
        except Exception:
            return {"ok": False, "error": "imaging libraries unavailable in this build"}
        bundle = self.cfg["bundle_path"]
        nspec = self._array_spec("NNN"); mspec = self._array_spec("MGE")
        cspec = self._array_spec("CCC")
        dims = cspec or nspec or {"width": 2048, "height": 2048}
        w, h = int(dims["width"]), int(dims["height"])
        col, mge, ht = _material_maps(name, w, h)
        matn = _normal_from_height(ht, 0.8)
        nnn = self._decode_bundle_array(bundle, nspec) if nspec else []
        mst = self._decode_bundle_array(bundle, mspec) if mspec else []
        masks = [self._load_mask(pm0, w, h), self._load_mask(pm1, w, h)]
        out_col, out_mge, out_nnn = [], [], []
        try:
            for i in range(2):
                stock_n = np.asarray(nnn[i % len(nnn)].convert("RGB").resize((w, h))) if nnn else None
                ni = _blend_normal_maps(stock_n, matn) if stock_n is not None else matn
                ci = col; mi = mge
                m = masks[i]
                if m is not None:
                    cur = self._cur_color(i, w, h)
                    if cur is None:
                        cur = np.full((h, w, 3), 128, "uint8")
                    ci = _blend_by_mask(col, cur, m)
                    if stock_n is not None:
                        ni = _blend_by_mask(ni, stock_n, m)
                    if mst:
                        sm = np.asarray(mst[i % len(mst)].convert("RGB").resize((w, h)))
                        sm4 = np.dstack([sm, sm[..., 1]])
                        mi = _blend_by_mask(mge, sm4, m)
                cp = os.path.join(tempfile.gettempdir(), "p1forge_mat_col%d.png" % i)
                Image.fromarray(ci, "RGB").save(cp); out_col.append(cp)
                mp = os.path.join(tempfile.gettempdir(), "p1forge_mat_mge%d.png" % i)
                Image.fromarray(mi, "RGBA").save(mp); out_mge.append(mp)
                npp = os.path.join(tempfile.gettempdir(), "p1forge_mat_nnn%d.png" % i)
                Image.fromarray(ni, "RGB").save(npp); out_nnn.append(npp)
        except Exception as ex:
            _log("material_apply build error:\n" + traceback.format_exc())
            return {"ok": False, "error": "couldn't build material: %s" % ex}
        layers = []
        for arr, pngs in (("MGE", out_mge), ("NNN", out_nnn)):
            ly, err = self._array_layer(arr, pngs[0], pngs[1])
            if not err:
                layers.append(ly)
        return self._finish_surface(out_col, layers, "material", inject_game)

    def grunge_apply(self, kind="grime", amount=0.6, pm0="", pm1="", inject_game=True):
        """Overlay procedural grunge (scratches/grime/dust/smudge) on the current
        skin (or selected parts): darkens colour + roughens the finish where the
        grunge falls. Owner-only."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not self.cfg.get("bundle_path"):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        if not self.png0:
            return {"ok": False, "error": "Build or load a weapon skin first — grunge ages your current colours."}
        try:
            import numpy as np
            from PIL import Image
        except Exception:
            return {"ok": False, "error": "imaging libraries unavailable in this build"}
        bundle = self.cfg["bundle_path"]
        cspec = self._array_spec("CCC"); mspec = self._array_spec("MGE")
        dims = cspec or {"width": 2048, "height": 2048}
        w, h = int(dims["width"]), int(dims["height"])
        amt = max(0.0, min(1.5, float(amount or 0)))
        mst = self._decode_bundle_array(bundle, mspec) if mspec else []
        masks = [self._load_mask(pm0, w, h), self._load_mask(pm1, w, h)]
        out_col, out_mge = [], []
        try:
            for i in range(2):
                g = _grunge_map(kind, w, h, seed=11 + i)
                cur = self._cur_color(i, w, h)
                if cur is None:
                    cur = np.full((h, w, 3), 128, "uint8")
                worn = (cur.astype("float32") * (1 - (g[..., None] * amt * 0.6))).clip(0, 255).astype("uint8")
                m = masks[i]
                if m is not None:
                    worn = _blend_by_mask(worn, cur, m)
                cp = os.path.join(tempfile.gettempdir(), "p1forge_grunge_col%d.png" % i)
                Image.fromarray(worn, "RGB").save(cp); out_col.append(cp)
                if mst:
                    sm = np.asarray(mst[i % len(mst)].convert("RGB").resize((w, h))).astype("float32")
                    G = sm[..., 1] * (1 - g * amt * 0.5)
                    mm = np.dstack([sm[..., 0], G, sm[..., 2], G]).clip(0, 255).astype("uint8")
                    if m is not None:
                        sm4 = np.dstack([sm[..., 0], sm[..., 1], sm[..., 2], sm[..., 1]]).astype("uint8")
                        mm = _blend_by_mask(mm, sm4, m)
                    mp = os.path.join(tempfile.gettempdir(), "p1forge_grunge_mge%d.png" % i)
                    Image.fromarray(mm, "RGBA").save(mp); out_mge.append(mp)
        except Exception as ex:
            _log("grunge_apply build error:\n" + traceback.format_exc())
            return {"ok": False, "error": "couldn't build grunge: %s" % ex}
        layers = []
        if len(out_mge) == 2:
            ly, err = self._array_layer("MGE", out_mge[0], out_mge[1])
            if not err:
                layers.append(ly)
        return self._finish_surface(out_col, layers, "grunge", inject_game)

    def _preview_slices(self, color_pngs, px=1024):
        """Per-slice JPEG data-URLs of the result colour (downscaled) so the app
        can paint them onto the 3D gun model as a live, non-destructive preview
        BEFORE anything is injected."""
        out = []
        try:
            from PIL import Image
            for p in color_pngs[:2]:
                if p and os.path.isfile(p):
                    im = Image.open(p).convert("RGB").resize((px, px))
                    buf = io.BytesIO(); im.save(buf, "JPEG", quality=85)
                    out.append("data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii"))
                else:
                    out.append("")
        except Exception:
            pass
        return out

    def _finish_surface(self, color_pngs, layers, tag, inject_game):
        """Shared build+(optional)install for the surface tools (material/grunge).
        Always builds the bundle to Bundle Output; installs into the live game only
        when inject_game. Returns a colour preview either way so you can look first."""
        logs = []
        def push(m, t=None):
            logs.append(str(m))
        spec = self.cfg.get("spec", {}) or {}
        name = (spec.get("name") or "weapon").replace("_1p_tarray", "") + "_" + tag
        single = (spec.get("slices", 2) == 1)
        ok = self._run_one(name, single, False, True, push,
                           extra_layers=(layers or None),
                           color_png0=color_pngs[0], color_png1=color_pngs[1])
        if ok and inject_game:
            push("─ inject into game ─")
            try:
                self._inject_weapon_live(name, push)
            except Exception:
                push("install failed:\n" + traceback.format_exc())
        tail = [l for l in logs if l][-60:]
        return {"ok": bool(ok), "injected": bool(ok and inject_game),
                "slices": self._preview_slices(color_pngs),
                "log": "\n".join(tail), "error": ("" if ok else "build failed — see log")}

    def paint_channels(self, ccc0="", ccc1="", h0="", h1="", m0="", m1="",
                       strength=1.2, inject_game=True):
        """Bake painted RELIEF + METAL into the game maps: the height channels
        (h0/h1, grey=flat) -> a normal blended onto the stock NNN so brushed bumps/
        dents catch light; the metal channels (m0/m1, white=bare shiny metal) ->
        MGE metallic+gloss over the stock finish. ccc0/1 = the painted colour.
        Each is a per-slice PNG (b64). Owner-only."""
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        if not self.cfg.get("bundle_path"):
            return {"ok": False, "error": "Pick a weapon in the Forge tab first."}
        try:
            import numpy as np
            from PIL import Image
        except Exception:
            return {"ok": False, "error": "imaging libraries unavailable in this build"}
        bundle = self.cfg["bundle_path"]
        nspec = self._array_spec("NNN"); mspec = self._array_spec("MGE"); cspec = self._array_spec("CCC")
        dims = cspec or nspec or {"width": 2048, "height": 2048}
        w, h = int(dims["width"]), int(dims["height"])
        nnn = self._decode_bundle_array(bundle, nspec) if nspec else []
        mst = self._decode_bundle_array(bundle, mspec) if mspec else []
        c0 = self._save_b64_png(ccc0, "pc_c0"); c1 = self._save_b64_png(ccc1, "pc_c1")
        color0 = c0 or self.png0; color1 = c1 or self.png1 or color0
        if not color0:
            return {"ok": False, "error": "no colour to build — paint or load a skin first."}
        hs = [self._save_b64_png(h0, "pc_h0"), self._save_b64_png(h1, "pc_h1")]
        ms = [self._save_b64_png(m0, "pc_m0"), self._save_b64_png(m1, "pc_m1")]

        def gray(p, default):
            if p and os.path.isfile(p):
                return np.asarray(Image.open(p).convert("L").resize((w, h))).astype("float32")
            return np.full((h, w), default, "float32")

        out_nnn, out_mge = [], []
        try:
            for i in range(2):
                stock_n = np.asarray(nnn[i % len(nnn)].convert("RGB").resize((w, h))) if nnn else None
                if hs[i]:
                    hm = gray(hs[i], 128) / 255.0
                    nrm = _normal_from_height(hm, float(strength))
                    ni = _blend_normal_maps(stock_n, nrm) if stock_n is not None else nrm
                    ip = os.path.join(tempfile.gettempdir(), "p1forge_pc_nnn%d.png" % i)
                    Image.fromarray(ni, "RGB").save(ip); out_nnn.append(ip)
                if ms[i]:
                    if mst:
                        base = np.asarray(mst[i % len(mst)].convert("RGB").resize((w, h))).astype("float32")
                    else:
                        base = np.zeros((h, w, 3), "float32"); base[..., 1] = 140.0
                    metal = gray(ms[i], 0) / 255.0
                    R = base[..., 0] * (1 - metal) + 220 * metal
                    G = base[..., 1] * (1 - metal) + 210 * metal
                    mge = np.clip(np.stack([R, G, base[..., 2], G], -1), 0, 255).astype("uint8")
                    mp = os.path.join(tempfile.gettempdir(), "p1forge_pc_mge%d.png" % i)
                    Image.fromarray(mge, "RGBA").save(mp); out_mge.append(mp)
        except Exception as ex:
            _log("paint_channels error:\n" + traceback.format_exc())
            return {"ok": False, "error": "couldn't bake relief/metal: %s" % ex}
        layers = []
        for arr, pngs in (("MGE", out_mge), ("NNN", out_nnn)):
            if len(pngs) == 2:
                ly, err = self._array_layer(arr, pngs[0], pngs[1])
                if not err:
                    layers.append(ly)
        return self._finish_surface([color0, color1], layers, "relief", inject_game)

    # ---- install a freshly built weapon bundle over the live game file --
    def _game_weapon_dir(self):
        """The live game folder that holds weapon bundles (…/aa/StandaloneWindows64)."""
        roots = []
        try:
            sa = fmod_bank.find_streaming_assets(self.cfg.get("sa_dir")) if fmod_bank else None
            if sa:
                roots.append(os.path.join(sa, "aa", "StandaloneWindows64"))
        except Exception:
            pass
        for getter in (self._bb_asset, self._ret_assets):
            try:
                a = getter()
                if a and os.path.isfile(a):
                    pdata = os.path.dirname(a)          # …/PopulationONE_Data
                    roots.append(os.path.join(pdata, "StreamingAssets", "aa", "StandaloneWindows64"))
            except Exception:
                pass
        for r in roots:
            if r and os.path.isdir(r):
                return r
        return None

    def _weapon_backup_dir(self):
        base = os.environ.get("LOCALAPPDATA") or eng.app_dir()
        return os.path.join(base, "Pop1Forge", "Weapon Backup")

    def _inject_weapon_live(self, create_name, push):
        """Swap the freshly built weapon bundle over the LIVE game file
        (backed up once, atomic). Bundle Output copy is left untouched."""
        bundle_name = (self.cfg.get("spec") or {}).get("bundle_name") or ""
        if not bundle_name:
            push("inject into game: no bundle name for this weapon.", "er")
            return False
        out_base = (self.cfg.get("out_dir") or "").strip()
        if not out_base or not os.path.isdir(out_base):
            out_base = eng.app_dir()
        built = os.path.join(out_base, "Bundle Output",
                             eng.safe_folder_name(create_name), bundle_name)
        if not os.path.isfile(built):
            push("inject into game: built bundle not found (%s)." % built, "er")
            return False
        gdir = self._game_weapon_dir()
        if not gdir:
            push("inject into game: couldn't find the game's weapon folder "
                 "(the bundle is still saved in Bundle Output).", "er")
            return False
        live = os.path.join(gdir, bundle_name)
        if not os.path.isfile(live):
            push("inject into game: live file not found (%s)." % live, "er")
            return False
        try:
            bak_dir = self._weapon_backup_dir()
            os.makedirs(bak_dir, exist_ok=True)
            bkp = os.path.join(bak_dir, bundle_name)
            if not os.path.isfile(bkp):
                shutil.copy2(live, bkp)
                push("  backed up the original weapon file")
            tmp = live + ".p1forge.tmp"
            shutil.copy2(built, tmp)
            os.replace(tmp, live)                        # atomic swap
            push("  installed into game ✓", "ok")
            return True
        except PermissionError:
            push("inject into game: file is locked. Close Population: One and the "
                 "Meta app, then build again.", "er")
            return False
        except Exception as e:
            push("inject into game error: %s" % e, "er")
            return False

    def build(self, create_name, single_slice, swap_order, do_repack, weapon=None, creator=None,
              shine=None, inject_game=False):
        single_slice = bool(single_slice)
        if single_slice and not self.png0:
            return {"ok": False, "error": "Pick the texture PNG first."}
        if not single_slice and not (self.png0 and self.png1):
            return {"ok": False, "error": "Pick both slice PNGs first."}
        if not (create_name or "").strip():
            return {"ok": False, "error": "Enter a name for this skin first."}

        cfg = self.cfg
        png0, png1 = self.png0, self.png1
        win = self.window

        def push(line, tag=None):
            payload = json.dumps({"line": str(line), "tag": tag or ""})
            try:
                win.evaluate_js("window.__forgeLog && window.__forgeLog(%s)" % payload)
            except Exception:
                pass

        def finish(ok):
            try:
                win.evaluate_js("window.__forgeDone && window.__forgeDone(%s)"
                                % ("true" if ok else "false"))
            except Exception:
                pass

        def worker():
            layers = []
            color0 = color1 = None
            if shine and shine.get("on"):
                preset = shine.get("preset") or None
                layer, err = self._mge_shine_layer(shine.get("metallic", 78),
                                                   shine.get("gloss", 92),
                                                   preset=preset)
                if layer:
                    layers.append(layer)
                    if preset:
                        push("finish: %s preset" % preset)
                        # materials with an inherent colour (gold, gunmetal) tint
                        # the colour art too; plain finishes leave it untouched.
                        if matpre is not None and matpre.has_tint(preset) and self.png0:
                            try:
                                c0 = os.path.join(tempfile.gettempdir(),
                                                  "p1forge_col_%s_s0.png" % preset)
                                matpre.process_albedo(self.png0, preset).save(c0)
                                color0 = c0
                                if self.png1:
                                    c1 = os.path.join(tempfile.gettempdir(),
                                                      "p1forge_col_%s_s1.png" % preset)
                                    matpre.process_albedo(self.png1, preset).save(c1)
                                    color1 = c1
                                push("  colour tinted for %s" % preset)
                            except Exception as e:
                                push("  colour tint skipped: %s" % e, "er")
                    else:
                        push("shine: metallic %s%%, gloss %s%%"
                             % (shine.get("metallic", 78), shine.get("gloss", 92)))
                else:
                    push("shine skipped: %s" % err, "er")
            ok = self._run_one(create_name, single_slice, swap_order, do_repack, push,
                               extra_layers=(layers or None),
                               color_png0=color0, color_png1=color1)
            if ok:
                try:
                    self._record_build(create_name, weapon, creator, single_slice)
                except Exception:
                    pass
                if inject_game:
                    push("─ inject into game ─")
                    self._inject_weapon_live(create_name, push)
            finish(ok)

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True, "started": True}

    # ---- BigBox mesh variants -------------------------------------------
    #  Everything here reads from 'BigBox Assets/' NEXT TO THE APP at runtime.
    #  Nothing is added to SkinForge.spec and no geometry is embedded in
    #  forge.html -- the exe must not grow.

    #  app weapon name -> BigBox Assets folder name
    _BBV_ALIAS = {"1911": "c1911", "mag357": "sw357", "spr": "mk12"}
    _bbv_cache = None

    def _bbv_root(self):
        return os.path.join(eng.app_dir(), "BigBox Assets")

    def _bbv_manifest(self):
        if self._bbv_cache is None:
            p = os.path.join(self._bbv_root(), "manifest.json")
            try:
                with open(p, "r", encoding="utf-8") as f:
                    Api._bbv_cache = json.load(f)
                _log("bbv: manifest loaded, %d weapons" % len(Api._bbv_cache))
            except Exception:
                _log("bbv: no manifest at %s" % p)
                Api._bbv_cache = {}
        return self._bbv_cache

    def _bbv_safe(self, *parts):
        """Join under 'BigBox Assets/' and refuse to escape it."""
        root = os.path.abspath(self._bbv_root())
        clean = []
        for part in parts:
            for seg in str(part or "").replace("\\", "/").split("/"):
                if seg and seg not in (".", ".."):
                    clean.append(seg)
        if not clean:
            return None
        p = os.path.abspath(os.path.join(root, *clean))
        try:
            if os.path.commonpath([p, root]) != root:
                return None
        except Exception:
            return None
        return p

    def _bbv_data_url(self, p):
        if not p or not os.path.isfile(p):
            return None
        try:
            with open(p, "rb") as f:
                return "data:image/png;base64," + base64.b64encode(f.read()).decode("ascii")
        except Exception:
            return None

    def _bbv_find(self, skin):
        for w in self._bbv_manifest().values():
            for v in (w.get("variants") or []):
                if v.get("skin") == skin:
                    return v
        return None

    def list_bigbox_variants(self, weapon):
        """Every BigBox mesh-mod variant for a weapon. Always returns the same
        shape, with variants=[] when 'BigBox Assets/' is missing, so the page can
        just hide the dropdown instead of erroring."""
        if not self._owner_ok():
            return {"weapon": (weapon or "").lower(), "stock": None, "variants": []}
        key = (weapon or "").lower()
        key = self._BBV_ALIAS.get(key, key)
        w = self._bbv_manifest().get(key) or {}
        out = []
        for v in (w.get("variants") or []):
            out.append({
                "skin":       v.get("skin"),
                "playfab":    v.get("playfab"),
                "protrusion": v.get("protrusion_cm"),
                "verts":      v.get("verts"),
                "tris":       v.get("tris"),
                "uv_max":     v.get("uv_max"),
                "hands":      sorted((v.get("mesh") or {}).keys()),
                "slices":     len(((v.get("tex") or {}).get("CCC") or [])),
                "thumb":      self._bbv_data_url(
                    self._bbv_safe(v.get("tex_dir"), v.get("thumb") or "thumb.png")),
            })
        out.sort(key=lambda v: (v["skin"] or ""))
        return {"weapon": key, "stock": w.get("stock"), "variants": out}

    def load_bigbox_mesh(self, skin, hand="r"):
        """geo_<hand>.json for one variant -> {pos, uv, nrm, idx, nv, nt, uv_max}.
        Some variants only shipped one hand, so fall back rather than fail.
        NOTE: uv_max can exceed 1.0 (tec9_002 runs 0.009 -> 2.986). The painter
        must read uv_max and not assume a 0-1 layout."""
        if not self._owner_ok():
            return None
        v = self._bbv_find(skin)
        if not v:
            return None
        meshes = v.get("mesh") or {}
        h = (hand or "r").lower()
        if h not in meshes:
            h = "r" if "r" in meshes else ("l" if "l" in meshes else None)
        if not h:
            return None
        p = self._bbv_safe(v.get("mesh_dir"), meshes[h])
        if not p or not os.path.isfile(p):
            return None
        try:
            with open(p, "r", encoding="utf-8") as f:
                geo = json.load(f)
        except Exception:
            _log("bbv mesh read failed: %s\n%s" % (p, traceback.format_exc()))
            return None
        geo["skin"] = skin
        geo["hand"] = h
        if not geo.get("uv_max"):
            geo["uv_max"] = v.get("uv_max")
        return geo

    def load_bigbox_texture(self, skin, slice_index=0):
        """CCC albedo PNG (2048^2) for one variant slice, as a data URL. That is
        ~5 MB of base64 over the bridge -- the page must cache it per skin and
        never re-fetch it on a repaint."""
        if not self._owner_ok():
            return None
        v = self._bbv_find(skin)
        if not v:
            return None
        names = ((v.get("tex") or {}).get("CCC") or [])
        try:
            i = int(slice_index)
        except Exception:
            i = 0
        if not names or i < 0 or i >= len(names):
            return None
        return self._bbv_data_url(self._bbv_safe(v.get("tex_dir"), names[i]))

    # ---- BigBox texture library (first-person albedos, texture-only) -----
    #  Reads 'Texture Library/' NEXT TO THE APP at runtime. Built once by
    #  build_texture_library.py. Nothing here is baked into the exe. These are
    #  BigBox's own shipped skin albedos, decoded to PNG so the user can open
    #  one as a paint base, edit/recolor it, and bake their OWN texture.
    _texlib_cache = None

    def _texlib_root(self):
        return os.path.join(eng.app_dir(), "Texture Library")

    def _texlib_manifest(self):
        if self._texlib_cache is None:
            p = os.path.join(self._texlib_root(), "library.json")
            try:
                with open(p, "r", encoding="utf-8") as f:
                    Api._texlib_cache = json.load(f)
                _log("texlib: library loaded, %d weapons" % len(Api._texlib_cache))
            except Exception:
                _log("texlib: no library at %s" % p)
                Api._texlib_cache = {}
        return self._texlib_cache

    def _texlib_safe(self, *parts):
        """Join under 'Texture Library/' and refuse to escape it."""
        root = os.path.abspath(self._texlib_root())
        clean = []
        for part in parts:
            for seg in str(part or "").replace("\\", "/").split("/"):
                if seg and seg not in (".", ".."):
                    clean.append(seg)
        if not clean:
            return None
        p = os.path.abspath(os.path.join(root, *clean))
        try:
            if os.path.commonpath([p, root]) != root:
                return None
        except Exception:
            return None
        return p

    def _texlib_data_url(self, p):
        if not p or not os.path.isfile(p):
            return None
        try:
            with open(p, "rb") as f:
                return "data:image/png;base64," + base64.b64encode(f.read()).decode("ascii")
        except Exception:
            return None

    def _texlib_find(self, skin):
        for w in self._texlib_manifest().values():
            for v in (w.get("skins") or []):
                if v.get("skin") == skin:
                    return v
        return None

    def list_texture_library(self, weapon=None):
        """Every first-person skin albedo in the library, grouped by weapon.
        'thumb' is a small data URL for the browser; the big 2048^2 slices are
        fetched lazily by load_library_texture only when a skin is chosen.
        Returns {weapons:[{family, skins:[{skin, family, slices, thumb}]}], count}.
        Same shape (empty) when 'Texture Library/' is missing, so the page can
        just show a hint instead of erroring."""
        if not self._owner_ok():
            return {"weapons": [], "count": 0}
        man = self._texlib_manifest()
        key = (weapon or "").lower().strip()
        weapons = []
        for fam in sorted(man):
            if key and key not in ("all", "*") and fam != key:
                continue
            skins = []
            for v in (man[fam].get("skins") or []):
                skins.append({
                    "skin":   v.get("skin"),
                    "family": v.get("family") or fam,
                    "slices": v.get("slices") or len(((v.get("tex") or {}).get("CCC") or [])),
                    "thumb":  self._texlib_data_url(
                        self._texlib_safe(v.get("tex_dir"), v.get("thumb") or "thumb.png")),
                })
            skins.sort(key=lambda s: s["skin"] or "")
            if skins:
                weapons.append({"family": fam, "skins": skins})
        return {"weapons": weapons,
                "count": sum(len(w["skins"]) for w in weapons)}

    def load_library_texture(self, skin, slice_index=0):
        """CCC albedo PNG (2048^2) for one library skin slice, as a data URL.
        ~5 MB of base64 over the bridge -- the page must cache it per skin and
        never re-fetch it on a repaint."""
        if not self._owner_ok():
            return None
        v = self._texlib_find(skin)
        if not v:
            return None
        names = ((v.get("tex") or {}).get("CCC") or [])
        try:
            i = int(slice_index)
        except Exception:
            i = 0
        if not names or i < 0 or i >= len(names):
            return None
        return self._texlib_data_url(self._texlib_safe(v.get("tex_dir"), names[i]))

    # ---- mesh mods: bake the Forge's greebles into the bundle ------------
    def _mesh_roots(self):
        r"""(source, output) roots next to the app:
             meshes\               <- clean source bundles (one subfolder each)
             modded mesh bundles\  <- output (per weapon, per named skin)"""
        base = eng.app_dir()
        return os.path.join(base, "meshes"), os.path.join(base, "modded mesh bundles")

    def _find_mesh_bundle(self, weapon):
        """Locate the clean source .bundle for a weapon under 'meshes'. Checks
        meshes\\<weapon>\\ first, then every subfolder, then loose files in
        meshes\\. Prefers a LOD0 file whose name or folder matches the weapon."""
        root, _mod = self._mesh_roots()
        if not os.path.isdir(root):
            return None
        wl = (weapon or "").lower()
        search = []
        wdir = os.path.join(root, weapon)
        if os.path.isdir(wdir):
            search.append(wdir)
        try:
            for n in sorted(os.listdir(root)):
                p = os.path.join(root, n)
                if os.path.isdir(p) and p not in search:
                    search.append(p)
        except Exception:
            pass
        search.append(root)
        for d in search:
            try:
                files = [f for f in os.listdir(d) if f.lower().endswith(".bundle")]
            except Exception:
                continue
            folder_matches = os.path.basename(d).lower() == wl
            named = [f for f in files if wl and wl in f.lower()]
            pool = named or (files if folder_matches else [])
            pool.sort(key=lambda f: (0 if "lod0" in f.lower() else 1, f.lower()))
            if pool:
                return os.path.join(d, pool[0])
        return None

    def pick_bundle_file(self):
        """Native open-bundle dialog that returns the real file path (the in-page
        picker hides it). Reads the bytes so the Forge can patch the albedo, and
        remembers the folder so export can pop it back open as the paste target --
        e.g. the Unity cache <name_hash>\\<ver_hash> folder holding __data."""
        try:
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("All files (*.*)", "Unity bundle (*.bundle;*.bin)"))
            if not res:
                return {"ok": False, "cancelled": True}
            path = res[0] if isinstance(res, (list, tuple)) else res
            with open(path, "rb") as f:
                data = f.read()
            self._last_bundle_folder = os.path.dirname(path)
            return {"ok": True, "path": path,
                    "folder": os.path.dirname(path),
                    "name": os.path.basename(path),
                    "b64": base64.b64encode(data).decode("ascii")}
        except Exception as e:
            _log("pick_bundle_file error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def save_texture_bundle(self, filename, b64):
        """Write a texture-only modded bundle (the albedo the Forge just re-baked)
        into 'modded texture bundles' next to the app, named exactly like the
        original (so a __data stays __data), pop that folder, and also pop the
        folder the original was picked from -- the paste target. Geometry is never
        touched here; this only writes the bytes the page already built."""
        try:
            name = os.path.basename(filename or "").strip() or "modded.bundle"
            out = os.path.join(eng.app_dir(), "modded texture bundles")
            os.makedirs(out, exist_ok=True)
            data = base64.b64decode((b64 or "").split(",")[-1])
            p = os.path.join(out, name)
            with open(p, "wb") as f:
                f.write(data)
            paste = getattr(self, "_last_bundle_folder", None)
            if os.name == "nt":
                if os.path.isdir(out):
                    try:
                        os.startfile(out)  # noqa - where the new file landed
                    except Exception:
                        pass
                if paste and os.path.isdir(paste) and \
                   os.path.abspath(paste) != os.path.abspath(out):
                    try:
                        os.startfile(paste)  # noqa - the folder to paste it into
                    except Exception:
                        pass
            return {"ok": True, "out": p, "folder": out, "name": name,
                    "paste_folder": paste}
        except Exception as e:
            _log("save_texture_bundle error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def save_mesh_export(self, filename, text):
        """Write an exported mesh (OBJ) into 'mesh exports' next to the app and pop
        the folder. Plain geometry + UVs for viewing in Blender -- no game bundle,
        no injection, just the shape."""
        try:
            name = os.path.basename(filename or "").strip() or "mesh.obj"
            out = os.path.join(eng.app_dir(), "mesh exports")
            os.makedirs(out, exist_ok=True)
            p = os.path.join(out, name)
            with open(p, "w", encoding="utf-8") as f:
                f.write(text or "")
            if os.name == "nt" and os.path.isdir(out):
                try:
                    os.startfile(out)  # noqa - pop the folder
                except Exception:
                    pass
            return {"ok": True, "out": p, "folder": out, "name": name}
        except Exception as e:
            _log("save_mesh_export error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bigbox_cache_path(self, skin):
        """Resolve the Unity cache folder for a BigBox variant's first-person
        material bundle (where its CCC albedo lives) from pop1_index.json, so the
        page can hand the user a copyable Explorer path to the __data they replace.
        Resolves against whichever pop1_index.json sits next to the app, so it is
        correct per game version."""
        try:
            import json as _json, re as _re
            idx_path = os.path.join(eng.app_dir(), "pop1_index.json")
            if not os.path.isfile(idx_path):
                return {"ok": False, "error": "pop1_index.json not found next to the app"}
            bundles = _json.load(open(idx_path, encoding="utf-8")).get("bundles", [])
            rx = _re.compile(r"Assets/Prefabs/Item/Skins/([^/]+)/Quest/PBR_FirstPerson\.mat$")
            nh = vh = None
            for b in bundles:
                for p in (b.get("asset_paths") or []):
                    m = rx.match(p)
                    if m and m.group(1) == skin:
                        nh, vh = b.get("name_hash"), b.get("ver_hash")
                        break
                if nh:
                    break
            if not nh:
                return {"ok": False, "error": "no first-person material bundle found for " + str(skin)}
            root = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")),
                                "AppData", "LocalLow", "Unity", "BigBoxVR_Population_ ONE")
            folder = os.path.join(root, nh, vh)
            return {"ok": True, "folder": folder, "data": os.path.join(folder, "__data"),
                    "exists": os.path.isdir(folder), "name_hash": nh, "ver_hash": vh}
        except Exception as e:
            _log("bigbox_cache_path error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def backup_bigbox_cache(self):
        """One-click backup: copy every BigBox variant's first-person material cache
        bundle (__data + __info) into 'BigBox Cache Backup' next to the app, so the
        user has a restore point before replacing textures in the live cache."""
        try:
            import json as _json, re as _re, shutil as _sh
            idx_path = os.path.join(eng.app_dir(), "pop1_index.json")
            if not os.path.isfile(idx_path):
                return {"ok": False, "error": "pop1_index.json not found next to the app"}
            bundles = _json.load(open(idx_path, encoding="utf-8")).get("bundles", [])
            rx = _re.compile(r"Assets/Prefabs/Item/Skins/([^/]+)/Quest/PBR_FirstPerson\.mat$")
            pairs = {}
            for b in bundles:
                for p in (b.get("asset_paths") or []):
                    m = rx.match(p)
                    if m:
                        pairs[m.group(1)] = (b.get("name_hash"), b.get("ver_hash"))
            root = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")),
                                "AppData", "LocalLow", "Unity", "BigBoxVR_Population_ ONE")
            dest_root = os.path.join(eng.app_dir(), "BigBox Cache Backup")
            os.makedirs(dest_root, exist_ok=True)
            done = skipped = 0
            for skin, (nh, vh) in pairs.items():
                if not (nh and vh):
                    continue
                src = os.path.join(root, nh, vh)
                if not os.path.isdir(src):
                    skipped += 1
                    continue
                dst = os.path.join(dest_root, nh, vh)
                os.makedirs(dst, exist_ok=True)
                for fn in os.listdir(src):
                    sp = os.path.join(src, fn)
                    if os.path.isfile(sp):
                        _sh.copy2(sp, os.path.join(dst, fn))
                done += 1
            if os.name == "nt" and os.path.isdir(dest_root):
                try:
                    os.startfile(dest_root)
                except Exception:
                    pass
            return {"ok": True, "backed_up": done, "skipped": skipped, "folder": dest_root}
        except Exception as e:
            _log("backup_bigbox_cache error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def is_owner(self):
        """True only if an 'owner.key' marker file sits next to the app. That file is
        kept out of the share zip, so the Armory/store features stay owner-only."""
        try:
            return {"owner": os.path.isfile(os.path.join(eng.app_dir(), "owner.key"))}
        except Exception:
            return {"owner": False}

    def _owner_ok(self):
        """Owner-only backend gate: the owner.key marker file (dev build) OR a verified
        admin license (the installed app signed in with GW1DDY's admin key)."""
        try:
            if getattr(self, "_admin", False):
                return True
            return os.path.isfile(os.path.join(eng.app_dir(), "owner.key"))
        except Exception:
            return False

    def export_modded_bundle(self, weapon, project_json):
        """Bake the mesh features placed in the Forge (studs/bars/spikes/...) into
        the weapon bundle and write a modded .bundle into Bundle Output. The page
        calls this from the Mesh Mod panel, handing over the current project JSON.
        Reuses inject_skinproj.py, which never overwrites the clean source."""
        logs = []

        def log(m):
            logs.append(str(m))

        try:
            import inject_skinproj as isp
        except Exception as e:
            return {"ok": False, "error": "mesh injector not available in this build: %s" % e,
                    "log": logs}

        try:
            proj = json.loads(project_json) if isinstance(project_json, str) else (project_json or {})
        except Exception as e:
            return {"ok": False, "error": "couldn't read the project data: %s" % e, "log": logs}

        weapon = (weapon or proj.get("weapon") or "").strip()
        if not weapon:
            return {"ok": False, "error": "load a weapon first", "log": logs}
        if not (proj.get("greebles") or proj.get("replaceMesh")
                or proj.get("carveTris") or proj.get("hiddenTris") or proj.get("planeCuts")
                or proj.get("fillPoints")):
            log("no mesh edits -- exporting the stock mesh bundle unchanged")

        # resolve the clean source bundle from the 'meshes' folder next to the app
        # (one subfolder per bundle). Falls back to the old Library path so
        # existing setups keep working.
        bundle = self._find_mesh_bundle(weapon)
        if not bundle or not os.path.isfile(bundle):
            b = (self.cfg.get("bundle_path") or "").strip()
            if b and os.path.isfile(b):
                bundle = b
            else:
                try:
                    lb, _r = eng.library_files(weapon)
                    bundle = lb or ""
                except Exception:
                    bundle = ""
        if not bundle or not os.path.isfile(bundle):
            mroot, _mod = self._mesh_roots()
            return {"ok": False,
                    "error": "no source bundle for '%s' - put the clean .bundle in %s\\%s\\"
                             % (weapon, mroot, weapon),
                    "log": logs}

        # write to:  modded mesh bundles\<weapon>\<skin name>\<original bundle name>
        skin = (proj.get("skinName") or "mesh").strip() or "mesh"
        safe = "".join(c for c in skin if c.isalnum() or c in "-_ ").strip().replace(" ", "_") or "mesh"
        _mroot, modroot = self._mesh_roots()
        out_dir = os.path.join(modroot, weapon, safe)
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as e:
            return {"ok": False, "error": "couldn't make the output folder: %s" % e, "log": logs}
        # keep the source bundle's exact name so it drops straight into the game
        out_path = os.path.join(out_dir, os.path.basename(bundle))

        try:
            res = isp.apply_project(bundle, proj, log=log, out_path=out_path)
        except Exception:
            log(traceback.format_exc())
            return {"ok": False, "error": "injection failed - see the log", "log": logs}

        if not res.get("ok"):
            return {"ok": False, "error": res.get("reason") or "injection did not complete",
                    "log": logs}
        return {"ok": True, "out": res.get("out"), "folder": out_dir,
                "added_verts": res.get("added_verts"), "added_tris": res.get("added_tris"),
                "carved_tris": res.get("carved_tris"), "capped_tris": res.get("capped_tris"),
                "plane_cuts": res.get("plane_cuts"), "log": logs}

    def swap_game_mesh(self, weapon, pad_verts=False):
        """Pick a SOURCE mesh bundle and write its shape into the TARGET weapon's
        base bundle, keeping the base's identity + filename -- a drop-in that makes
        the base gun in-game take the source's shape. Reuses apply_project's
        whole-mesh replacement (source UVs are re-mapped onto the base layout)."""
        import webview
        logs = []

        def log(m):
            logs.append(str(m))

        try:
            import inject_skinproj as isp
            import inject_mesh as im
        except Exception as e:
            return {"ok": False, "error": "mesh tools not available in this build: %s" % e, "log": logs}

        weapon = (weapon or "").strip()
        if not weapon:
            return {"ok": False, "error": "load a weapon first", "log": logs}

        res = self.window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Unity mesh bundle (*.bundle)", "All files (*.*)"))
        if not res:
            return {"cancelled": True}
        src = res[0] if isinstance(res, (list, tuple)) else res
        if not src or not os.path.isfile(src):
            return {"ok": False, "error": "source bundle not found", "log": logs}

        try:
            sm = im.read_mesh(src)
            flat = []
            for v in sm["verts"]:
                flat.extend(v["Position"])
            if len(flat) < 9 or len(sm["indices"]) < 3:
                return {"ok": False, "error": "that bundle has no usable mesh", "log": logs}
            proj = {"v": 1, "weapon": weapon,
                    "replaceMesh": {"pos": flat, "idx": list(sm["indices"])},
                    "padVerts": bool(pad_verts),
                    "skinName": os.path.splitext(os.path.basename(src))[0][:40]}
        except Exception:
            log(traceback.format_exc())
            return {"ok": False, "error": "couldn't read the source mesh - see log", "log": logs}

        # resolve the TARGET base bundle (same resolution as export_modded_bundle)
        bundle = self._find_mesh_bundle(weapon)
        if not bundle or not os.path.isfile(bundle):
            b = (self.cfg.get("bundle_path") or "").strip()
            if b and os.path.isfile(b):
                bundle = b
            else:
                try:
                    lb, _r = eng.library_files(weapon)
                    bundle = lb or ""
                except Exception:
                    bundle = ""
        if not bundle or not os.path.isfile(bundle):
            mroot, _mod = self._mesh_roots()
            return {"ok": False,
                    "error": "no base bundle for '%s' - put the clean base .bundle in %s\\%s\\"
                             % (weapon, mroot, weapon), "log": logs}

        safe = "".join(c for c in proj["skinName"] if c.isalnum() or c in "-_ ").strip().replace(" ", "_") or "swap"
        _mroot, modroot = self._mesh_roots()
        out_dir = os.path.join(modroot, weapon, safe + "_swap")
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as e:
            return {"ok": False, "error": "couldn't make the output folder: %s" % e, "log": logs}
        out_path = os.path.join(out_dir, os.path.basename(bundle))

        try:
            r = isp.apply_project(bundle, proj, log=log, out_path=out_path)
        except Exception:
            log(traceback.format_exc())
            return {"ok": False, "error": "swap failed - see the log", "log": logs}
        if not r.get("ok"):
            return {"ok": False, "error": r.get("reason") or "swap did not complete", "log": logs}
        return {"ok": True, "out": r.get("out"), "folder": out_dir,
                "source": os.path.basename(src), "target": os.path.basename(bundle),
                "verts": len(sm["verts"]), "log": logs}

    # ---- Mesh parts library (starter parts to bolt onto guns) -----------
    def _mesh_lib_dir(self):
        return os.path.join(eng.app_dir(), "Mesh Library")

    def list_mesh_library(self):
        """Manifest of the starter parts (name/type/weapon/verts/tris/file) plus a
        base64 PNG thumbnail per part, for the in-app library browser."""
        root = self._mesh_lib_dir()
        man = os.path.join(root, "library.json")
        if not os.path.isfile(man):
            return {"ok": False, "error": "no 'Mesh Library' folder next to the app", "parts": []}
        try:
            data = json.load(open(man, encoding="utf-8"))
        except Exception as e:
            return {"ok": False, "error": "couldn't read library.json: %s" % e, "parts": []}
        out = []
        for p in data.get("parts", []):
            thumb = ""
            tp = p.get("thumb")
            if tp:
                fp = os.path.join(root, tp.replace("/", os.sep))
                if os.path.isfile(fp):
                    try:
                        thumb = "data:image/png;base64," + base64.b64encode(open(fp, "rb").read()).decode()
                    except Exception:
                        thumb = ""
            out.append({"name": p.get("name"), "type": p.get("type"), "weapon": p.get("weapon"),
                        "verts": p.get("verts"), "tris": p.get("tris"),
                        "file": p.get("file"), "thumb": thumb})
        return {"ok": True, "parts": out}

    def load_library_part(self, file):
        """Return one library part's OBJ text (the page parses it into geometry)."""
        root = os.path.abspath(self._mesh_lib_dir())
        fp = os.path.abspath(os.path.join(root, (file or "").replace("/", os.sep)))
        if not fp.startswith(root) or not os.path.isfile(fp):
            return {"ok": False, "error": "part not found"}
        try:
            txt = open(fp, encoding="utf-8").read()
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "obj": txt, "name": os.path.splitext(os.path.basename(fp))[0]}

    # ---- Weapon variant packages (custom damaged/variant meshes) ---------
    def _variant_dir(self):
        """Root that holds variant packages (each a folder with manifest.json +
        OBJ + break textures). Currently the AWP damaged-stock test drop."""
        base = eng.app_dir()
        for cand in (os.path.join(base, "Variants"),
                     os.path.join(base, "Claude - AWP Damaged Stock Test", "skinforge_package")):
            if os.path.isdir(cand):
                return cand
        return os.path.join(base, "Variants")

    def list_variants(self):
        """List variant packages (folder name + manifest label/weapon/thumb) for the
        preview picker. Preview/inspection assets, never a bundle build."""
        root = self._variant_dir()
        out = []
        if os.path.isdir(root):
            for d in sorted(os.listdir(root)):
                fp = os.path.join(root, d)
                mp = os.path.join(fp, "manifest.json")
                if not (os.path.isdir(fp) and os.path.isfile(mp)):
                    continue
                man = {}
                try:
                    man = json.load(open(mp, encoding="utf-8"))
                except Exception:
                    pass
                thumb = ""
                tp = os.path.join(fp, man.get("thumb", "thumb.png"))
                if os.path.isfile(tp):
                    try:
                        thumb = "data:image/png;base64," + base64.b64encode(open(tp, "rb").read()).decode()
                    except Exception:
                        thumb = ""
                out.append({"name": d, "label": man.get("name", d), "weapon": man.get("weapon"),
                            "type": man.get("type"), "preview_only": bool(man.get("preview_only", True)),
                            "thumb": thumb})
        return {"ok": True, "variants": out}

    def load_variant(self, name="awp_broken_stock"):
        """Return one variant package: the OBJ text (with vt/o/usemtl the page parses
        into skin+break groups), its break textures as data-URLs, and the manifest.
        Preview only; injection is a separate explicit step the owner triggers."""
        safe = re.sub(r"[^A-Za-z0-9_\-]", "", name or "")
        root = os.path.abspath(self._variant_dir())
        fp = os.path.abspath(os.path.join(root, safe))
        if not fp.startswith(root) or not os.path.isdir(fp):
            return {"ok": False, "error": "variant not found: %s" % name}

        def _b64(fn, mime="image/png"):
            p = os.path.join(fp, fn)
            if os.path.isfile(p):
                try:
                    return "data:%s;base64,%s" % (mime, base64.b64encode(open(p, "rb").read()).decode())
                except Exception:
                    return ""
            return ""

        man = {}
        mp = os.path.join(fp, "manifest.json")
        if os.path.isfile(mp):
            try:
                man = json.load(open(mp, encoding="utf-8"))
            except Exception:
                man = {}
        objfn = man.get("file", "")
        op = os.path.join(fp, objfn) if objfn else ""
        if not (op and os.path.isfile(op)):
            objs = [f for f in os.listdir(fp) if f.lower().endswith(".obj")]
            if not objs:
                return {"ok": False, "error": "no .obj in variant package"}
            op = os.path.join(fp, objs[0])
        try:
            obj = open(op, encoding="utf-8", errors="replace").read()
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "name": safe, "obj": obj, "manifest": man,
                "own_uv": bool(man.get("own_uv")),
                "texture": _b64(man.get("texture", "")) if man.get("texture") else "",
                "break_polymer": _b64(man.get("materials", {}).get("awp_break", {}).get("texture", "break_polymer.png")
                                      if isinstance(man.get("materials"), dict) else "break_polymer.png"),
                "break_wood": _b64("break_wood.png"),
                "thumb": _b64(man.get("thumb", "thumb.png")),
                "preview": _b64(man.get("preview", "preview.png"))}

    def _variant_pkg(self, name):
        """(folder, manifest, weapon, obj_path) for a variant package, guarded."""
        safe = re.sub(r"[^A-Za-z0-9_\-]", "", name or "")
        root = os.path.abspath(self._variant_dir())
        fp = os.path.abspath(os.path.join(root, safe))
        if not fp.startswith(root) or not os.path.isdir(fp):
            return None
        man = {}
        mp = os.path.join(fp, "manifest.json")
        if os.path.isfile(mp):
            try:
                man = json.load(open(mp, encoding="utf-8"))
            except Exception:
                man = {}
        objfn = man.get("file", "")
        op = os.path.join(fp, objfn) if objfn else ""
        if not (op and os.path.isfile(op)):
            objs = [f for f in os.listdir(fp) if f.lower().endswith(".obj")]
            op = os.path.join(fp, objs[0]) if objs else ""
        return {"dir": fp, "man": man, "weapon": (man.get("weapon") or "awp").lower(),
                "obj": op, "safe": safe}

    def variant_inject_mesh(self, name="awp_broken_stock_pro"):
        """SHAPE-ONLY test inject: replace the weapon's live in-game MESH bundle with
        this variant's geometry. The variant's own texture is NOT applied here — the
        gun's own skin wraps on by nearest vertex. Backs up the live mesh once, then
        atomic-swaps. Owner-only. (Injecting the variant's own texture is a later step.)"""
        if not self._owner_ok():
            return {"ok": False, "error": "This is owner-only."}
        try:
            import inject_skinproj as isp
        except Exception as e:
            return {"ok": False, "error": "mesh tools unavailable in this build: %s" % e}
        pk = self._variant_pkg(name)
        if not pk or not pk["obj"]:
            return {"ok": False, "error": "variant not found / no OBJ"}
        weapon = pk["weapon"]
        man = pk["man"] or {}
        # Inject the MATERIAL-MARKED mesh (body verts coincide with the base weapon so
        # the crisp original skin nearest-transfers straight on; only the fracture faces
        # are new). Prefer an explicit inject mesh; fall back to the display OBJ.
        obj_path = pk["obj"]
        inj = man.get("inject_file")
        if inj:
            cand = os.path.join(pk["dir"], inj)
            if os.path.isfile(cand):
                obj_path = cand
        break_mat = (man.get("break_material") or "break").lower()
        break_uv = man.get("break_uv") or [0.3584, 0.856, 0.0, 0.0]
        V, idx = [], []
        break_faceverts = set()
        cur = None
        try:
            for ln in open(obj_path, encoding="utf-8", errors="replace"):
                t = ln.split()
                if not t:
                    continue
                if t[0] == "v":
                    # X-negate: OBJ frame -> the game's bundle frame (bundle.x = -obj.x).
                    V += [-float(t[1]), float(t[2]), float(t[3])]
                elif t[0] == "usemtl":
                    cur = t[1].strip().lower()
                elif t[0] == "f":
                    vi = [int(x.split("/")[0]) - 1 for x in t[1:]]
                    for k in range(1, len(vi) - 1):
                        idx += [vi[0], vi[k + 1], vi[k]]   # reverse winding (X flip -> keep normals out)
                    if cur and break_mat in cur:
                        for q in vi:
                            break_faceverts.add(q)
        except Exception as e:
            return {"ok": False, "error": "couldn't read the variant OBJ: %s" % e}
        if len(V) < 9 or len(idx) < 3:
            return {"ok": False, "error": "variant OBJ has no geometry"}
        base = self._find_mesh_bundle(weapon)      # clean source in meshes\<weapon>\ (always pristine)
        if not base or not os.path.isfile(base):
            return {"ok": False, "error": "no clean %s mesh bundle in meshes\\%s\\ to build from" % (weapon, weapon)}
        bundle_name = os.path.basename(base)
        log = []
        proj = {"v": 1, "weapon": weapon, "replaceMesh": {"pos": V, "idx": idx},
                "padVerts": False, "noFit": True, "skinName": pk["safe"][:40],
                # fracture faces -> one dark-gunmetal texel: uniform UV == solid == no stretch
                "breakVerts": sorted(break_faceverts), "breakUV": [float(x) for x in break_uv],
                # rigid_skin -> pin every vert to the static bone so a foreign mesh doesn't
                # get dragged/stretched by the AWP's reload/bolt custom-skin animation
                "rigidSkin": bool(man.get("rigid_skin"))}
        out_dir = os.path.join(eng.app_dir(), "modded mesh bundles", weapon, pk["safe"])
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as e:
            return {"ok": False, "error": "couldn't make output folder: %s" % e}
        out = os.path.join(out_dir, bundle_name)
        try:
            r = isp.apply_project(base, proj, log=lambda m: log.append(str(m)), out_path=out)
        except Exception:
            return {"ok": False, "error": "mesh build crashed", "log": "\n".join(log) + "\n" + traceback.format_exc()}
        if not (r and r.get("ok")) or not os.path.isfile(out):
            return {"ok": False, "error": (r or {}).get("reason") or "mesh build failed", "log": "\n".join(log)}
        gdir = self._game_weapon_dir()
        if not gdir:
            return {"ok": True, "injected": False, "out": out, "log": "\n".join(log),
                    "note": "Built the modded mesh, but couldn't find the live game folder — the bundle is in 'modded mesh bundles'."}
        live = os.path.join(gdir, bundle_name)
        if not os.path.isfile(live):
            return {"ok": True, "injected": False, "out": out, "log": "\n".join(log),
                    "note": "Built it, but the live %s mesh file isn't where expected." % weapon}
        try:
            bak_dir = self._weapon_backup_dir()
            os.makedirs(bak_dir, exist_ok=True)
            bkp = os.path.join(bak_dir, bundle_name)
            if not os.path.isfile(bkp):
                shutil.copy2(live, bkp)
                log.append("backed up the original mesh")
            tmp = live + ".p1forge.tmp"
            shutil.copy2(out, tmp)
            os.replace(tmp, live)
        except PermissionError:
            return {"ok": False, "error": "The file is locked — fully close Population: One and the Meta app, then try again.", "log": "\n".join(log)}
        except Exception as e:
            return {"ok": False, "error": "inject error: %s" % e, "log": "\n".join(log)}
        return {"ok": True, "injected": True, "weapon": weapon, "verts": len(V) // 3, "tris": len(idx) // 3,
                "note": "Injected. FULLY restart Population: One, then hold the %s to see the broken shape." % weapon.upper()}

    def variant_restore_mesh(self, name="awp_broken_stock_pro"):
        """Copy the pristine mesh bundle back over the live game file (undo the test)."""
        if not self._owner_ok():
            return {"ok": False, "error": "This is owner-only."}
        pk = self._variant_pkg(name)
        weapon = pk["weapon"] if pk else "awp"
        base = self._find_mesh_bundle(weapon)
        if not base or not os.path.isfile(base):
            return {"ok": False, "error": "no clean %s mesh bundle to restore from" % weapon}
        bundle_name = os.path.basename(base)
        gdir = self._game_weapon_dir()
        if not gdir:
            return {"ok": False, "error": "couldn't find the live game folder"}
        live = os.path.join(gdir, bundle_name)
        bkp = os.path.join(self._weapon_backup_dir(), bundle_name)
        src = bkp if os.path.isfile(bkp) else base       # prefer the once-backed-up original
        try:
            tmp = live + ".p1forge.tmp"
            shutil.copy2(src, tmp)
            os.replace(tmp, live)
        except PermissionError:
            return {"ok": False, "error": "File locked — close Population: One and the Meta app first."}
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "note": "Restored the original %s mesh — restart the game." % weapon.upper()}

    # ---- Sound library (synthesized starter sounds) ---------------------
    def _sound_lib_dir(self):
        return os.path.join(eng.app_dir(), "Sound Library")

    def list_sound_library(self):
        """Manifest (name/category/tags/seconds/file) + a base64 waveform thumb
        per sound, for the in-app sound-library browser (sort + search)."""
        root = self._sound_lib_dir()
        man = os.path.join(root, "library.json")
        if not os.path.isfile(man):
            return {"ok": False, "error": "no 'Sound Library' folder next to the app", "sounds": []}
        try:
            data = json.load(open(man, encoding="utf-8"))
        except Exception as e:
            return {"ok": False, "error": "couldn't read library.json: %s" % e, "sounds": []}
        out = []
        for s in data.get("sounds", []):
            thumb = ""
            tp = s.get("thumb")
            if tp:
                fp = os.path.join(root, tp.replace("/", os.sep))
                if os.path.isfile(fp):
                    try:
                        thumb = "data:image/png;base64," + base64.b64encode(open(fp, "rb").read()).decode()
                    except Exception:
                        thumb = ""
            out.append({"name": s.get("name"), "category": s.get("category"),
                        "tags": s.get("tags") or [], "seconds": s.get("seconds"),
                        "file": s.get("file"), "thumb": thumb})
        return {"ok": True, "sounds": out}

    def load_sound_library(self, file):
        """Return a library sound's WAV as a base64 data URL (the editor decodes
        it into a clip; preview plays it)."""
        root = os.path.abspath(self._sound_lib_dir())
        fp = os.path.abspath(os.path.join(root, (file or "").replace("/", os.sep)))
        if not fp.startswith(root) or not os.path.isfile(fp):
            return {"ok": False, "error": "sound not found"}
        try:
            b = open(fp, "rb").read()
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "name": os.path.splitext(os.path.basename(fp))[0],
                "wav": "data:audio/wav;base64," + base64.b64encode(b).decode()}

    # ---- Billboards tab (Signs_CCC_tarray) ------------------------------
    def _bb_sanitize(self, name):
        import re
        n = re.sub(r"[^A-Za-z0-9_\- ]+", "", str(name or "")).strip().replace(" ", "_")
        n = re.sub(r"_+", "_", n).strip("_")
        return n[:60]

    def _bb_dirs(self):
        # one working set of slices; each Inject names its own output subfolder
        root = os.path.join(eng.app_dir(), "Billboards")
        return os.path.join(root, "slices"), os.path.join(root, "output")

    def _bb_asset(self):
        p = (self.cfg.get("billboard_asset") or "").strip()
        # an explicit, still-valid pick wins (unless it's the old sharedassets2 default)
        if p and os.path.isfile(p) and os.path.basename(p).lower() != "sharedassets2.assets":
            return p
        # otherwise derive from the ACTIVE platform's PopulationONE_Data (Steam/Meta),
        # preferring the 7-slice sharedassets4 over sharedassets2
        pdata = self._pdata_dir()
        if pdata:
            for base in ("sharedassets4.assets", "sharedassets2.assets"):
                cand = os.path.join(pdata, base)
                if os.path.isfile(cand):
                    return cand
        # legacy hardcoded Meta fallbacks
        for cand in (BB_DEFAULT_ASSET, BB_DEFAULT_ASSET_ALT):
            if os.path.isfile(cand):
                return cand
        return BB_DEFAULT_ASSET

    def _bb_find(self, env):
        fallback = None
        for obj in env.objects:
            if obj.type.name != "Texture2DArray":
                continue
            d = obj.read()
            if getattr(d, "m_Name", "") == BB_TEX_NAME:
                return d
            if obj.path_id == BB_TEX_PATHID:
                fallback = d
        if fallback is not None:
            return fallback
        raise RuntimeError("Signs_CCC_tarray not found in that .assets file")

    def bb_locate(self):
        p = self._bb_asset()
        return {"path": p, "exists": os.path.isfile(p)}

    def bb_pick_asset(self):
        res = self.window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Unity assets (*.assets)", "All files (*.*)"))
        if not res:
            return {"cancelled": True}
        path = res[0] if isinstance(res, (list, tuple)) else res
        self.cfg["billboard_asset"] = path
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass
        return {"path": path, "exists": os.path.isfile(path)}


    # ----- Ad boards (.ctex downloaded textures) -----------------------------
    def _archive_working(self):
        """On launch, move leftover edited PNGs into Billboards/previous/<time>/
        so the app always opens showing the ORIGINAL art (nothing is deleted)."""
        import time
        root = os.path.join(eng.app_dir(), "Billboards")
        srcs = [os.path.join(root, "slices"), os.path.join(root, "boards")]
        pngs = []
        for s in srcs:
            if os.path.isdir(s):
                pngs += [os.path.join(s, f) for f in os.listdir(s)
                         if f.lower().endswith(".png")]
        if not pngs:
            return
        stamp = time.strftime("%Y-%m-%d_%H%M%S")
        dest = os.path.join(root, "previous", stamp)
        for p in pngs:
            sub = os.path.basename(os.path.dirname(p))     # slices / boards
            d = os.path.join(dest, sub)
            os.makedirs(d, exist_ok=True)
            try:
                os.replace(p, os.path.join(d, os.path.basename(p)))
            except Exception:
                pass
        _log("archived %d working PNG(s) -> %s" % (len(pngs), dest))

    def _ctex_orig_dir(self):
        d = os.path.join(eng.app_dir(), "Billboards", BB_CTEX_ORIG)
        os.makedirs(d, exist_ok=True)
        return d

    def _ctex_original(self, name):
        """Path to our pristine copy of a board, making it on first use.
        Prefers the .ctex.orig backup, else the live file (assumed clean)."""
        keep = os.path.join(self._ctex_orig_dir(), name + ".ctex")
        if os.path.isfile(keep):
            return keep
        import shutil
        live = os.path.join(self._ctex_dir(), name + ".ctex")
        bak = live + ".orig"
        src = bak if os.path.isfile(bak) else live
        if os.path.isfile(src):
            shutil.copy2(src, keep)
            _log("saved pristine board copy: %s <- %s" % (keep, os.path.basename(src)))
            return keep
        return None

    def export_clean(self):
        """Write the clean, unmodified slice PNGs into Billboards/clean/ so they can
        be handed to someone to paint on and send back."""
        try:
            import UnityPy
            root = os.path.join(eng.app_dir(), "Billboards", "clean")
            os.makedirs(root, exist_ok=True)
            made = []

            # live ad boards (from the pristine .ctex copies)
            for nm in BB_CTEX:
                img = self._ctex_decode(nm)
                if img is None:
                    continue
                p = os.path.join(root, nm.replace("-Standalone", "") + ".png")
                img.save(p)
                made.append(os.path.basename(p))

            # sign slices (from a clean sharedassets if we have one)
            src = self._clean_signs_src()
            if src:
                d = self._bb_find(UnityPy.load(src))
                for i, im in enumerate(d.images):
                    p = os.path.join(root, "slice%d.png" % i)
                    im.convert("RGBA").save(p)
                    made.append(os.path.basename(p))

            if os.name == "nt" and os.path.isdir(root):
                try:
                    os.startfile(root)  # noqa
                except Exception:
                    pass
            return {"ok": True, "path": root, "count": len(made), "files": made,
                    "signs_src": os.path.basename(src) if src else None}
        except Exception as e:
            _log("export_clean error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def _clean_signs_src(self):
        """Prefer an untouched backup of sharedassets over the (maybe modded) game
        file, so exported sign slices are genuinely clean."""
        asset = self._bb_asset()
        base = os.path.basename(asset)
        for folder in (os.path.join(eng.app_dir(), "Backup Shared Assets"),
                       os.path.join(eng.app_dir(), "Billboards", "originals")):
            p = os.path.join(folder, base)
            if os.path.isfile(p):
                return p
        return asset if os.path.isfile(asset) else None

    def ctex_open_originals(self):
        try:
            d = self._ctex_orig_dir()
            if os.name == "nt":
                os.startfile(d)  # noqa
            return {"ok": True, "path": d}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _find_ctex_dir(self):
        """Locate the game's downloaded ad-board cache. The default is
        <home>\\AppData\\LocalLow\\BigBoxVR\\Population_ ONE\\cached, BUT the LocalLow
        company/product folder varies by build (Meta/Rift vs Steam vs Quest-link), and
        os.path.expanduser('~') can disagree with %USERPROFILE% on some machines. That's
        exactly why one PC finds the boards and another PC with the SAME files sitting in
        the folder does not. So: try the known spots under every home we can see, then
        glob LocalLow for whichever 'cached' folder actually holds the board files."""
        import glob
        probes = [n + ".ctex" for n in BB_CTEX]
        homes = []
        for h in (os.environ.get("USERPROFILE"), os.path.expanduser("~"),
                  os.environ.get("HOMEDRIVE", "") + os.environ.get("HOMEPATH", "")):
            h = (h or "").strip()
            if h and os.path.isdir(h) and h not in homes:
                homes.append(h)
        # 1) the two known folder-name layouts
        for h in homes:
            ll = os.path.join(h, "AppData", "LocalLow")
            for c in (os.path.join(ll, "BigBoxVR", "Population_ ONE", "cached"),
                      os.path.join(ll, "Unity", "BigBoxVR_Population_ ONE", "cached")):
                if any(os.path.isfile(os.path.join(c, p)) for p in probes):
                    _log("ctex dir  : boards at %s" % c)
                    return c
        # 2) scan LocalLow for any *\cached or *\*\cached holding the board files
        for h in homes:
            ll = os.path.join(h, "AppData", "LocalLow")
            for pat in (os.path.join(ll, "*", "cached"), os.path.join(ll, "*", "*", "cached")):
                for c in glob.glob(pat):
                    if any(os.path.isfile(os.path.join(c, p)) for p in probes):
                        _log("ctex dir  : boards found by scan at %s" % c)
                        return c
        _log("ctex dir  : boards NOT found under LocalLow; using default %s" % BB_CTEX_DIR)
        return BB_CTEX_DIR

    def _ctex_dir(self):
        # an explicit path saved in settings always wins
        d = (self.cfg.get("ctex_dir") or "").strip()
        if d:
            return d
        # otherwise auto-locate once and remember it for this session
        c = getattr(self, "_ctex_dir_cache", None)
        if not c:
            c = self._find_ctex_dir()
            self._ctex_dir_cache = c
        return c

    def _ctex_work(self):
        d = os.path.join(eng.app_dir(), "Billboards", "boards")
        os.makedirs(d, exist_ok=True)
        return d

    def _ctex_path(self, name):
        return os.path.join(self._ctex_dir(), name + ".ctex")

    def _ctex_read(self, name):
        """-> (header dict, raw bytes, containertype bytes) from the PRISTINE copy."""
        import zipfile
        p = self._ctex_original(name)      # never the live (maybe already-modded) file
        if not p or not os.path.isfile(p):
            return None
        with zipfile.ZipFile(p) as z:
            ct = z.read("ContainerType")
            hdr = json.loads(z.read("Header").decode("utf-8"))
            raw = z.read("RawData")
        return hdr, raw, ct

    def _ctex_decode(self, name):
        from UnityPy.export.Texture2DConverter import parse_image_data
        from UnityPy.enums import TextureFormat
        got = self._ctex_read(name)
        if not got:
            return None
        hdr, raw, _ct = got
        w, h = int(hdr["width"]), int(hdr["height"])
        base = (w // 4) * (h // 4) * 16          # BC3 base level
        img = parse_image_data(raw[:base], w, h, TextureFormat.DXT5,
                               (2021, 3, 0, 0), 0, None)
        return img.convert("RGBA")

    def ctex_list(self):
        try:
            from PIL import Image as _I
            work = self._ctex_work()
            out = []
            for nm, hint in BB_CTEX.items():
                if not self._ctex_original(nm):
                    continue
                orig = self._ctex_decode(nm)
                if orig is None:
                    continue
                p = os.path.join(work, nm + ".png")
                if os.path.isfile(p):
                    show = _I.open(p).convert("RGBA")
                    edited = (show.size != orig.size or show.tobytes() != orig.tobytes())
                else:
                    show = orig; edited = False
                out.append({"name": nm, "hint": hint,
                            "w": show.width, "h": show.height,
                            "edited": edited, "thumb": _img_to_data_url(show, 360)})
            _log("ctex_list : loaded %d board(s) from %s" % (len(out), self._ctex_dir()))
            return {"ok": True, "boards": out, "dir": self._ctex_dir()}
        except Exception as e:
            _log("ctex_list error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ctex_get(self, name):
        try:
            from PIL import Image as _I
            p = os.path.join(self._ctex_work(), name + ".png")
            img = _I.open(p).convert("RGBA") if os.path.isfile(p) else self._ctex_decode(name)
            if img is None:
                return {"ok": False, "error": "board not found"}
            sx, sy = self._bb_snaplines(img)
            # the boards are the same designs as the fixed Signs slices; serve the
            # matching region map so they line up like the slices (the yellow
            # Posters board = slice2's layout). Others fall back to auto-detect.
            si = BB_BOARD_SLICE.get(name)
            panels = ([{"x": x, "y": y, "w": w, "h": h}
                       for (x, y, w, h) in BB_REGIONS_FIXED[si]]
                      if si in BB_REGIONS_FIXED else [])
            return {"ok": True, "name": name, "w": img.width, "h": img.height,
                    "dataURL": _img_to_data_url(img, max(img.width, img.height)),
                    "snapX": sx, "snapY": sy, "panels": panels,
                    "hint": BB_CTEX.get(name, "")}
        except Exception as e:
            _log("ctex_get error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ctex_save(self, name, data_url):
        try:
            from PIL import Image as _I
            if "," in data_url:
                data_url = data_url.split(",", 1)[1]
            img = _I.open(BytesIO(base64.b64decode(data_url))).convert("RGBA")
            got = self._ctex_read(name)
            if got:
                w, h = int(got[0]["width"]), int(got[0]["height"])
                if img.size != (w, h):
                    img = img.resize((w, h), _I.LANCZOS)
            img.save(os.path.join(self._ctex_work(), name + ".png"))
            return {"ok": True, "name": name, "thumb": _img_to_data_url(img, 360)}
        except Exception as e:
            _log("ctex_save error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ctex_reset(self, name):
        try:
            p = os.path.join(self._ctex_work(), name + ".png")
            if os.path.isfile(p):
                os.remove(p)
            img = self._ctex_decode(name)
            return {"ok": True, "name": name, "edited": False,
                    "thumb": _img_to_data_url(img, 360)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def ctex_inject(self, name=None, install=False):
        """Rebuild edited .ctex files. install=True writes them into the game cache
        (backing up the originals first)."""
        try:
            import zipfile, shutil
            from PIL import Image
            from UnityPy.export.Texture2DConverter import image_to_texture2d
            from UnityPy.enums import TextureFormat
            proj = self._bb_sanitize(name)
            if not proj:
                return {"ok": False, "error": "Type a name first."}
            work = self._ctex_work()
            _sl, out_root = self._bb_dirs()
            out = os.path.join(out_root, proj)
            os.makedirs(out, exist_ok=True)

            def r4(x):
                return max(4, ((x + 3) // 4) * 4)

            files = []
            for nm in BB_CTEX:
                png = os.path.join(work, nm + ".png")
                got = self._ctex_read(nm)
                if not os.path.isfile(png) or not got:
                    continue
                hdr, orig_raw, ct = got
                w, h = int(hdr["width"]), int(hdr["height"])
                im = Image.open(png).convert("RGBA")
                if im.size != (w, h):
                    im = im.resize((w, h), Image.LANCZOS)
                blob = b""; lvl = 0
                while len(blob) < len(orig_raw) and lvl < 24:
                    lw = max(1, w >> lvl); lh = max(1, h >> lvl)
                    dim = (r4(lw), r4(lh))
                    lim = im if dim == im.size else im.resize(dim, Image.LANCZOS)
                    enc, _u = image_to_texture2d(lim, TextureFormat.DXT5, flip=True)
                    blob += enc; lvl += 1
                if len(blob) != len(orig_raw):
                    return {"ok": False, "error": "%s encoded %d want %d"
                            % (nm, len(blob), len(orig_raw))}
                outp = os.path.join(out, nm + ".ctex")
                with zipfile.ZipFile(outp, "w", zipfile.ZIP_DEFLATED) as zo:
                    zo.writestr("ContainerType", ct)
                    zo.writestr("Header", json.dumps(hdr, separators=(",", ":")))
                    zo.writestr("RawData", blob)
                rec = {"name": nm, "ok": True, "out": outp, "mips": lvl}
                if install:
                    live = self._ctex_path(nm)
                    bak = live + ".orig"
                    if not os.path.isfile(bak):
                        shutil.copy2(live, bak)      # one-time backup
                    shutil.copy2(outp, live)
                    rec["installed"] = live
                files.append(rec)
            if not files:
                return {"ok": False, "error": "No edited boards in Billboards\\boards."}
            if os.name == "nt" and os.path.isdir(out):
                try:
                    os.startfile(out)      # pop the folder so it's easy to grab/send
                except Exception:
                    pass
            return {"ok": True, "name": proj, "out": out, "files": files,
                    "installed": bool(install)}
        except Exception as e:
            _log("ctex_inject error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ctex_open_cache(self):
        try:
            d = self._ctex_dir()
            if os.name == "nt" and os.path.isdir(d):
                os.startfile(d)  # noqa
            return {"ok": True, "path": d}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _bb_extract_src(self):
        """Use the file you located (Locate...). To edit the 7-slice copy, locate it."""
        return self._bb_asset()

    def bb_extract(self):
        try:
            import UnityPy
            asset = self._bb_extract_src()
            if not os.path.isfile(asset):
                return {"ok": False, "error": "sharedassets2.assets not found - click Locate and pick it."}
            env = UnityPy.load(asset)
            d = self._bb_find(env)
            if (d.m_Width, d.m_Height) != (BB_W, BB_H) or d.m_Format != BB_FORMAT:
                return {"ok": False, "error": "unexpected spec %dx%dx%d fmt %d"
                        % (d.m_Width, d.m_Height, d.m_Depth, d.m_Format)}
            from PIL import Image as _Img
            sl, _out = self._bb_dirs()
            os.makedirs(sl, exist_ok=True)
            slices = []
            for i, img in enumerate(d.images):
                orig = img.convert("RGBA")
                p = os.path.join(sl, "slice%d.png" % i)
                if os.path.isfile(p):
                    show = _Img.open(p).convert("RGBA")
                    # "edited" only if the saved PNG actually differs from the game original
                    edited = (show.size != orig.size) or (show.tobytes() != orig.tobytes())
                else:
                    show = orig; edited = False
                slices.append({"index": i, "hint": BB_SLICE_HINTS.get(i, ""),
                               "edited": edited, "thumb": _img_to_data_url(show, 320)})
            return {"ok": True, "slices": slices}
        except Exception as e:
            _log("bb_extract error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_reset_all(self):
        """Delete all edited slice PNGs so Extract shows the located bundle's originals."""
        try:
            sl, _out = self._bb_dirs()
            removed = 0
            if os.path.isdir(sl):
                for f in os.listdir(sl):
                    if f.lower().startswith("slice") and f.lower().endswith(".png"):
                        try:
                            os.remove(os.path.join(sl, f)); removed += 1
                        except Exception:
                            pass
            return {"ok": True, "removed": removed}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def bb_reset_slice(self, index):
        """Revert one slice to the game original by deleting this project's edit."""
        try:
            import UnityPy
            sl, _out = self._bb_dirs()
            p = os.path.join(sl, "slice%d.png" % int(index))
            if os.path.isfile(p):
                os.remove(p)
            env = UnityPy.load(self._bb_asset())
            d = self._bb_find(env)
            img = d.images[int(index)].convert("RGBA")
            return {"ok": True, "index": int(index), "edited": False,
                    "thumb": _img_to_data_url(img, 320)}
        except Exception as e:
            _log("bb_reset_slice error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_pick_replace(self, index):
        try:
            from PIL import Image
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("PNG image (*.png)", "All files (*.*)"))
            if not res:
                return {"cancelled": True}
            src = res[0] if isinstance(res, (list, tuple)) else res
            img = Image.open(src).convert("RGBA")
            if img.size != (BB_W, BB_H):
                return {"ok": False, "error": "image is %dx%d, must be %dx%d"
                        % (img.size[0], img.size[1], BB_W, BB_H)}
            sl, _out = self._bb_dirs()
            os.makedirs(sl, exist_ok=True)
            img.save(os.path.join(sl, "slice%d.png" % int(index)))
            return {"ok": True, "index": int(index), "thumb": _img_to_data_url(img, 320)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _bb_game_copies(self, asset):
        """Every .assets file in the game folder that contains Signs_CCC_tarray."""
        folder = os.path.dirname(asset)
        out = []
        try:
            for f in sorted(os.listdir(folder)):
                if not f.lower().endswith(".assets"):
                    continue
                p = os.path.join(folder, f)
                try:
                    found = False; tail = b""
                    with open(p, "rb") as fh:
                        while True:
                            buf = fh.read(8 * 1024 * 1024)
                            if not buf:
                                break
                            if BB_TEX_NAME.encode() in (tail + buf):
                                found = True; break
                            tail = buf[-32:]
                    if found:
                        out.append(p)
                except Exception:
                    pass
        except Exception:
            pass
        return out or [asset]

    def _bb_patch_one(self, asset, sl, out_dir):
        """Encode the edited slices and in-place patch one .assets file.
        Uses that file's own slice count / dimensions (copies can differ)."""
        import UnityPy
        from PIL import Image
        from UnityPy.export.Texture2DConverter import image_to_texture2d
        from UnityPy.enums.GraphicsFormat import GRAPHICS_TO_TEXTURE_MAP, GraphicsFormat
        base = os.path.basename(asset)
        env = UnityPy.load(asset)
        d = self._bb_find(env)
        tf = GRAPHICS_TO_TEXTURE_MAP.get(GraphicsFormat(d.m_Format))
        depth = int(d.m_Depth)
        w, h = int(d.m_Width), int(d.m_Height)
        per = d.m_DataSize // depth

        def r4(x):
            return max(4, ((x + 3) // 4) * 4)

        def encode_with_mips(im):
            if im.size != (w, h):
                im = im.resize((w, h), Image.LANCZOS)
            o = b""; lvl = 0
            while len(o) < per and lvl < 24:
                lw = max(1, w >> lvl); lh = max(1, h >> lvl)
                dim = (r4(lw), r4(lh))
                lim = im if dim == im.size else im.resize(dim, Image.LANCZOS)
                enc, _ = image_to_texture2d(lim, tf, flip=True)
                o += enc; lvl += 1
            return o

        orig = bytes(d.image_data)
        originals = d.images        # `depth` images
        orig_chunks = [orig[i * per:(i + 1) * per] for i in range(depth)]
        blob = b""; used = []
        for i in range(depth):
            png = os.path.join(sl, "slice%d.png" % i)   # only slices 0..N you've edited
            edited_bytes = None
            if os.path.isfile(png):
                im = Image.open(png).convert("RGBA")
                ob = originals[i].convert("RGBA")
                if not (im.size == ob.size and im.tobytes() == ob.tobytes()):
                    edited_bytes = encode_with_mips(im)   # this slice actually changed
                    used.append("edited")
                else:
                    used.append("unchanged")
            else:
                used.append("original")
            # untouched slices keep the game's ORIGINAL bytes verbatim (exact build);
            # only genuinely-edited slices get re-encoded
            chunk = edited_bytes if edited_bytes is not None else orig_chunks[i]
            if len(chunk) != per:
                return {"ok": False, "file": base,
                        "error": "slice%d encoded %d (want %d)" % (i, len(chunk), per)}
            blob += chunk
        if len(blob) != len(orig):
            return {"ok": False, "file": base,
                    "error": "size mismatch %d vs %d (depth %d)" % (len(blob), len(orig), depth)}

        os.makedirs(out_dir, exist_ok=True)
        outp = os.path.join(out_dir, base)
        raw = open(asset, "rb").read()
        if raw.count(orig) == 1:
            idx = raw.find(orig)
            with open(outp, "wb") as f:
                f.write(raw[:idx] + blob + raw[idx + len(orig):])
            method = "in-place patch"
        else:
            d.image_data = blob; d.m_DataSize = len(blob); d.save()
            with open(outp, "wb") as f:
                f.write(env.file.save())
            method = "full re-save"
        v = UnityPy.load(outp); vd = self._bb_find(v)
        ok = (len(vd.images) == depth and all(x.size == (w, h) for x in vd.images))
        return {"ok": ok, "file": base, "out": outp, "method": method,
                "depth": depth, "used": used}

    def bb_inject(self, name=None):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        try:
            proj = self._bb_sanitize(name)
            if not proj:
                return {"ok": False, "error": "Type a name for this billboard file first."}
            asset = self._bb_asset()
            if not os.path.isfile(asset):
                return {"ok": False, "error": "sharedassets2.assets not found."}
            sl, out_root = self._bb_dirs()
            out = os.path.join(out_root, proj)      # Billboards/output/<name>/
            copies = self._bb_game_copies(asset)    # patch EVERY file that has the texture
            files = []
            for cpath in copies:
                try:
                    files.append(self._bb_patch_one(cpath, sl, out))
                except Exception as e:
                    _log("bb_inject (%s) error:\n%s" % (cpath, traceback.format_exc()))
                    files.append({"ok": False, "file": os.path.basename(cpath), "error": str(e)})
            ok = bool(files) and all(f.get("ok") for f in files)
            used = next((f.get("used") for f in files if f.get("used")), [])
            return {"ok": ok, "name": proj, "out": out, "files": files,
                    "used": used, "count": len(files)}
        except Exception as e:
            _log("bb_inject error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def _bb_backup_dir(self):
        return os.path.join(eng.app_dir(), "Billboards", "game-backup")

    def bb_inject_live(self, name=None):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        """Build + verify (via bb_inject into output), back up the untouched game
        files ONCE, then atomically swap each verified patched .assets over the
        LIVE game file. Same end state as copying by hand, but backed up + atomic."""
        try:
            res = self.bb_inject(name)
            if not res.get("ok"):
                return {"ok": False,
                        "error": "Build/verify failed \u2014 your game files were NOT touched.",
                        "files": res.get("files"), "detail": res.get("error")}
            import UnityPy
            game_dir = os.path.dirname(self._bb_asset())
            bak_dir = self._bb_backup_dir()
            os.makedirs(bak_dir, exist_ok=True)
            done = []
            for f in res.get("files", []):
                base = f.get("file"); built = f.get("out")
                if not base or not built or not os.path.isfile(built):
                    done.append({"file": base, "ok": False, "error": "built file missing"}); continue
                live = os.path.join(game_dir, base)
                if not os.path.isfile(live):
                    done.append({"file": base, "ok": False, "error": "live file not found"}); continue
                # one-time pristine backup (never overwrite an existing backup)
                bkp = os.path.join(bak_dir, base)
                if not os.path.isfile(bkp):
                    shutil.copy2(live, bkp)
                # stage next to the live file so the final swap is atomic (same volume)
                tmp = live + ".p1forge.tmp"
                shutil.copy2(built, tmp)
                try:
                    v = UnityPy.load(tmp); vd = self._bb_find(v)
                    good = bool(vd) and len(vd.images) > 0
                except Exception:
                    good = False
                if not good:
                    try: os.remove(tmp)
                    except Exception: pass
                    done.append({"file": base, "ok": False, "error": "staged file failed verify"}); continue
                os.replace(tmp, live)   # atomic swap
                done.append({"file": base, "ok": True, "live": live})
            ok = bool(done) and all(x.get("ok") for x in done)
            return {"ok": ok, "live": True, "game_dir": game_dir, "backup_dir": bak_dir,
                    "files": done, "count": len(done)}
        except Exception as e:
            _log("bb_inject_live error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_restore_live(self):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        """Copy the pristine backups back over the live game files."""
        try:
            bak_dir = self._bb_backup_dir()
            if not os.path.isdir(bak_dir):
                return {"ok": False, "error": "No backup found yet \u2014 nothing to restore."}
            game_dir = os.path.dirname(self._bb_asset())
            n = 0; files = []
            for f in sorted(os.listdir(bak_dir)):
                if not f.lower().endswith(".assets"):
                    continue
                src = os.path.join(bak_dir, f); dst = os.path.join(game_dir, f)
                tmp = dst + ".p1forge.tmp"
                shutil.copy2(src, tmp); os.replace(tmp, dst)
                n += 1; files.append(f)
            return {"ok": n > 0, "restored": n, "files": files,
                    "game_dir": game_dir, "backup_dir": bak_dir,
                    "error": None if n else "Backup folder held no .assets files."}
        except Exception as e:
            _log("bb_restore_live error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def _bb_detect(self, img):
        """Best-effort panel rectangles for a 1024x1024 slice. Returns [] on any error
        (the editor still lets the user draw regions manually)."""
        try:
            import numpy as np
            a = np.asarray(img.convert("RGB"))

            def cmask(arr):
                e = np.concatenate([arr[0,:,:], arr[-1,:,:], arr[:,0,:], arr[:,-1,:]])
                bg = np.median(e, axis=0)
                return (np.abs(arr.astype(np.int16) - bg).sum(axis=2) > 60)

            def runs(on, min_len, gap=8):
                segs=[]; s=None
                for i,v in enumerate(on):
                    if v and s is None: s=i
                    elif not v and s is not None: segs.append([s,i]); s=None
                if s is not None: segs.append([s,len(on)])
                merged=[]
                for seg in segs:
                    if merged and seg[0]-merged[-1][1] <= gap: merged[-1][1]=seg[1]
                    else: merged.append(seg)
                return [(x,y) for x,y in merged if y-x>=min_len]

            def seam(band, min_panel=70):
                b=band.astype(np.float32); var=b.var(axis=0).sum(axis=1); L=b.shape[1]
                rng=float(var.max()-var.min()); v=(var-var.min())/(rng+1e-6); sm=v<0.06
                cuts=[0]; i=0
                while i<L:
                    if sm[i]:
                        j=i
                        while j<L and sm[j]: j+=1
                        cuts.append((i+j)//2); i=j
                    else: i+=1
                cuts.append(L); cuts=sorted(set(cuts))
                return [(cuts[k],cuts[k+1]) for k in range(len(cuts)-1) if cuts[k+1]-cuts[k]>=min_panel]

            m=cmask(a); rects=[]
            for (y0,y1) in runs(m.mean(axis=1)>0.02, 40):
                band=a[y0:y1]; bm=cmask(band)
                xb=runs(bm.mean(axis=0)>0.03, 40)
                if len(xb)<=1:
                    xb=seam(band) or [(0,band.shape[1])]
                for (x0,x1) in xb:
                    cell=bm[:, x0:x1]; rws=np.where(cell.mean(axis=1)>0.03)[0]
                    ay0,ay1=(y0+int(rws.min()), y0+int(rws.max())+1) if len(rws) else (y0,y1)
                    if (x1-x0)>=40 and (ay1-ay0)>=40:
                        rects.append({"x":int(x0),"y":int(ay0),"w":int(x1-x0),"h":int(ay1-ay0)})
            out=[]
            for r in rects:
                if not any(abs(r["x"]-o["x"])<12 and abs(r["y"]-o["y"])<12 and
                           abs(r["w"]-o["w"])<12 and abs(r["h"]-o["h"])<12 for o in out):
                    out.append(r)
            return out
        except Exception:
            _log("bb_detect error:\n" + traceback.format_exc())
            return []

    def _bb_snaplines(self, img):
        """Detect thin white divider lines (panel borders) as snap guides.
        Returns (xs, ys) lists of slice-space positions; [] where none exist."""
        try:
            import numpy as np
            arr = np.asarray(img.convert("RGB"))
            mx = arr.max(2); mn = arr.min(2)
            white = (mn > 170) & ((mx - mn) < 50)
            H, W = white.shape

            def peaks(runs, span):
                r = runs / float(span); thr = 0.28; L = len(r); out = []; i = 0
                while i < L:
                    if r[i] > thr:
                        j = i
                        while j < L and r[j] > thr * 0.6: j += 1
                        out.append(int(i + int(np.argmax(r[i:j])))); i = j
                    else:
                        i += 1
                m = []
                for c in out:
                    if m and c - m[-1] < 6: continue
                    m.append(c)
                return m

            run = np.zeros(W, int); bestc = np.zeros(W, int)
            for y in range(H):
                run = np.where(white[y], run + 1, 0); bestc = np.maximum(bestc, run)
            run2 = np.zeros(H, int); bestr = np.zeros(H, int)
            for x in range(W):
                col = white[:, x]
                run2 = np.where(col, run2 + 1, 0); bestr = np.maximum(bestr, run2)
            return peaks(bestc, H), peaks(bestr, W)
        except Exception:
            _log("bb_snaplines error:\n" + traceback.format_exc())
            return [], []

    def _bb_regions_dir(self):
        return os.path.join(eng.app_dir(), "Billboards", "regions")

    def bb_load_regions(self, index):
        """Image rectangles for a slice as [{x,y,w,h}, ...].
        Priority: a saved regions/slice<i>.json (user-defined, exact) -> [].
        When there's no user-saved file we return NOTHING so the editor's live
        auto-detect (expandAllSigns) runs instead - the same path the Billboards
        boards use, which is why they line up perfectly. The old hardcoded
        BB_PANELS table used to win here and that's what made the Signs slices
        look wrong; it's intentionally no longer consulted."""
        try:
            import json
            p = os.path.join(self._bb_regions_dir(), "slice%d.json" % int(index))
            if os.path.isfile(p):
                with open(p, "r") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return {"ok": True, "regions": data, "src": "saved"}
            fixed = BB_REGIONS_FIXED.get(int(index))
            if fixed:
                return {"ok": True,
                        "regions": [{"x": x, "y": y, "w": w, "h": h}
                                    for (x, y, w, h) in fixed], "src": "fixed"}
            return {"ok": True, "regions": [], "src": "none"}
        except Exception as e:
            _log("bb_load_regions error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e), "regions": []}

    def bb_save_regions(self, index, rects):
        """Persist the image rectangles for a slice (from the editor) so that
        clicking any image selects its exact box, permanently."""
        try:
            import json
            d = self._bb_regions_dir()
            os.makedirs(d, exist_ok=True)
            clean = []
            for r in (rects or []):
                try:
                    x = int(round(r.get("x", 0))); y = int(round(r.get("y", 0)))
                    w = int(round(r.get("w", 0))); h = int(round(r.get("h", 0)))
                    if w > 2 and h > 2:
                        clean.append({"x": x, "y": y, "w": w, "h": h})
                except Exception:
                    pass
            with open(os.path.join(d, "slice%d.json" % int(index)), "w") as f:
                json.dump(clean, f)
            return {"ok": True, "index": int(index), "count": len(clean)}
        except Exception as e:
            _log("bb_save_regions error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_clear_regions(self, index):
        """Delete the saved regions file for a slice (revert to built-in/auto)."""
        try:
            p = os.path.join(self._bb_regions_dir(), "slice%d.json" % int(index))
            if os.path.isfile(p):
                os.remove(p)
            return {"ok": True, "index": int(index)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def bb_get_slice(self, index):
        """Full-res (1024x1024) slice PNG as a data URL, plus suggested panel regions."""
        try:
            import UnityPy
            from io import BytesIO
            asset = self._bb_extract_src()
            if not os.path.isfile(asset):
                return {"ok": False, "error": "sharedassets2.assets not found."}
            # prefer an already-edited slice on disk so re-opening shows current work
            sl_dir, _out = self._bb_dirs()
            edited = os.path.join(sl_dir, "slice%d.png" % int(index))
            if os.path.isfile(edited):
                from PIL import Image as _Img
                img = _Img.open(edited).convert("RGBA")
            else:
                env = UnityPy.load(asset)
                d = self._bb_find(env)
                img = d.images[int(index)].convert("RGBA")
            buf = BytesIO(); img.save(buf, format="PNG")
            url = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
            sx, sy = self._bb_snaplines(img)
            panels = self.bb_load_regions(int(index)).get("regions", [])
            return {"ok": True, "index": int(index),
                    "dataURL": url, "snapX": sx, "snapY": sy, "panels": panels,
                    "hint": BB_SLICE_HINTS.get(int(index), "")}
        except Exception as e:
            _log("bb_get_slice error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_save_slice(self, index, data_url):
        """Write an edited 1024x1024 slice PNG (from the editor canvas) to disk."""
        try:
            from PIL import Image
            from io import BytesIO
            if "," in data_url:
                data_url = data_url.split(",", 1)[1]
            img = Image.open(BytesIO(base64.b64decode(data_url))).convert("RGBA")
            if img.size != (BB_W, BB_H):
                img = img.resize((BB_W, BB_H), Image.LANCZOS)
            sl_dir, _out = self._bb_dirs()
            os.makedirs(sl_dir, exist_ok=True)
            img.save(os.path.join(sl_dir, "slice%d.png" % int(index)))
            return {"ok": True, "index": int(index), "thumb": _img_to_data_url(img, 320)}
        except Exception as e:
            _log("bb_save_slice error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def bb_open_output(self):
        try:
            out_root = os.path.join(eng.app_dir(), "Billboards", "output")
            os.makedirs(out_root, exist_ok=True)
            if os.name == "nt":
                os.startfile(out_root)  # noqa  -> shows one subfolder per project
            return {"ok": True, "path": out_root}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ======================================================================
    #  SOUNDS  -  FMOD Studio bank editing (gun sounds = Item.assets.bank)
    # ======================================================================
    _SND_PREVIEW_CAP = 24 * 1024 * 1024     # inline-preview WAV size ceiling

    def _snd_sa(self):
        """Locate the game's StreamingAssets folder (where the banks live)."""
        override = (self.cfg.get("sa_dir") or "") if isinstance(self.cfg, dict) else ""
        return fmod_bank.find_streaming_assets(override) if fmod_bank else None

    def _pdata_dir(self):
        """PopulationONE_Data for the ACTIVE platform (Steam or Meta), derived from
        the resolved StreamingAssets dir. Billboards (sharedassets2/4) and the
        reticle (sharedassets1) live here, one level up from StreamingAssets."""
        sa = self._snd_sa()
        return os.path.dirname(sa) if sa else None

    # ---- Steam / Meta platform selection --------------------------------------
    def _platform_sa(self, platform):
        if not fmod_bank:
            return ""
        return fmod_bank.GAME_SA_STEAM if str(platform).lower() == "steam" else fmod_bank.GAME_SA

    def platform_state(self):
        """Which store the user plays through + whether each default install path
        exists. The page shows the first-run picker when `chosen` is False."""
        meta = self._platform_sa("meta")
        steam = self._platform_sa("steam")
        plat = (self.cfg.get("platform") or "").strip().lower()
        return {"ok": True,
                "platform": plat if plat in ("steam", "meta", "custom") else "",
                "chosen": plat in ("steam", "meta", "custom"),
                "meta_exists": bool(meta and os.path.isdir(meta)),
                "steam_exists": bool(steam and os.path.isdir(steam)),
                "sa_dir": (self.cfg.get("sa_dir") or "")}

    def set_platform(self, platform):
        """Record Steam vs Meta and point every game-file path (sounds, textures,
        billboards, reticle) at that install by setting sa_dir to its
        StreamingAssets. Clears any old per-platform asset overrides + caches."""
        plat = "steam" if str(platform).lower() == "steam" else "meta"
        sa = self._platform_sa(plat)
        self.cfg["platform"] = plat
        self.cfg["sa_dir"] = sa
        self.cfg.pop("billboard_asset", None)   # re-derive from the new platform
        self.cfg.pop("reticle_asset", None)
        self._forget_bank_caches()
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass
        return {"ok": True, "platform": plat, "sa_dir": sa, "exists": os.path.isdir(sa)}

    def _normalize_to_sa(self, folder):
        """Resolve a user-picked folder to its StreamingAssets dir. Accepts the
        StreamingAssets folder itself, PopulationONE_Data, PopulationONE, or the
        Steam/Meta game root."""
        if not folder or not os.path.isdir(folder):
            return None
        cands = [folder,
                 os.path.join(folder, "StreamingAssets"),
                 os.path.join(folder, "PopulationONE_Data", "StreamingAssets"),
                 os.path.join(folder, "PopulationONE", "PopulationONE_Data", "StreamingAssets")]
        for c in cands:
            if os.path.isdir(c) and os.path.basename(c).lower() == "streamingassets":
                return c
        for c in cands:
            try:
                if os.path.isdir(c) and any(f.endswith(".assets.bank") for f in os.listdir(c)):
                    return c
            except Exception:
                pass
        return None

    def set_game_folder(self):
        """Manual fallback for a non-standard install (e.g. Steam on another drive):
        browse to the PopulationONE folder and point the app at it."""
        try:
            res = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        if not res:
            return {"cancelled": True}
        folder = res[0] if isinstance(res, (list, tuple)) else res
        sa = self._normalize_to_sa(folder)
        if not sa:
            return {"ok": False, "error": "That folder doesn't look like a Population: "
                    "ONE install (no StreamingAssets with game banks found inside)."}
        self.cfg["sa_dir"] = sa
        self.cfg.pop("billboard_asset", None)
        self.cfg.pop("reticle_asset", None)
        if not (self.cfg.get("platform") or "").strip():
            self.cfg["platform"] = "custom"
        self._forget_bank_caches()
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass
        return {"ok": True, "sa_dir": sa}

    def _forget_bank_caches(self):
        for attr in ("_snd_banks", "_orig_fmt_cache"):
            try:
                getattr(self, attr).clear()
            except Exception:
                pass

    def _snd_out(self):
        return os.path.join(eng.app_dir(), "Sound Mods")

    def _snd_get_bank(self, bank_file, fresh=False):
        """Load + cache a Bank by file name (in StreamingAssets). Re-reads if the
        file changed on disk (e.g. after an install)."""
        sa = self._snd_sa()
        if not sa:
            raise RuntimeError("game StreamingAssets folder not found")
        # Handout users are limited to the weapons bank. Every read/edit/install path
        # (list/preview/pick/transfer/rebuild/restore) loads through here, so this one
        # gate keeps them out of music/menu/night/character/etc. -- the owner is exempt.
        if not self._owner_ok() and os.path.basename(bank_file) != "Item.assets.bank":
            raise RuntimeError("Only the weapons bank (Item.assets.bank) is available in this version.")
        path = os.path.join(sa, os.path.basename(bank_file))
        if not os.path.exists(path):
            raise RuntimeError("bank not found: %s" % os.path.basename(bank_file))
        mt = os.path.getmtime(path)
        cached = self._snd_banks.get(path)
        if fresh or not cached or cached[0] != mt:
            cached = (mt, fmod_bank.Bank(path))
            self._snd_banks[path] = cached
        return cached[1]

    def _snd_open_any(self, path):
        """Open ANY FMOD bank (.bank RIFF) or raw FSB5 by absolute path (a file
        someone sent, not from the game), cached by path+mtime."""
        mt = os.path.getmtime(path)
        cached = self._snd_banks.get(path)
        if not cached or cached[0] != mt:
            with open(path, "rb") as f:
                head = f.read(8)
            bank = fmod_bank.Bank(path) if head[:4] == b"RIFF" else fmod_bank.ExtFsb(path)
            self._snd_banks[path] = (mt, bank)
        return self._snd_banks[path][1]

    def snd_open_external(self):
        """Open a bank / FSB / audio file the user was sent so they can pull
        sounds out of it. Returns kind='bank' (its sample list) or kind='audio'
        (a single clip, decoded to WAV for the editor)."""
        try:
            if not fmod_bank:
                return {"ok": False, "error": "sound engine unavailable in this build"}
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Sound files (*.bank;*.fsb;*.fsb5;*.wav;*.mp3;*.ogg;"
                            "*.flac;*.m4a;*.aac;*.opus;*.aiff;*.bytes;*.bin)",
                            "All files (*.*)"))
            if not res:
                return {"ok": False, "cancelled": True}
            path = res[0] if isinstance(res, (list, tuple)) else res
            name = os.path.basename(path)
            with open(path, "rb") as f:
                head = f.read(16)
            ext = os.path.splitext(name)[1].lower()
            is_wav = head[:4] == b"RIFF" and head[8:12] == b"WAVE"
            is_bank = (head[:4] == b"RIFF" and not is_wav) or head[:4] == b"FSB5" \
                or b"FSB5" in head
            # plain audio (real WAV, or mp3/ogg/... by header/ext) -> one clip
            if is_wav or (not is_bank and ext in fmod_bank.AUDIO_MIME):
                with open(path, "rb") as f:
                    data = f.read()
                wav = data if is_wav else fmod_bank.decode_audio_to_wav(data)
                return {"ok": True, "kind": "audio", "name": name, "path": path,
                        "wav": base64.b64encode(wav).decode("ascii")}
            # otherwise treat it as an FMOD bank / FSB and list its sounds
            b = self._snd_open_any(path)
            samples = b.sample_list()
            if not samples:
                return {"ok": False, "error": "no FMOD sounds found in this file"}
            return {"ok": True, "kind": "bank", "name": name, "path": path,
                    "codec": b.codec(), "count": len(samples), "samples": samples}
        except Exception as e:
            _log("snd_open_external error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_ext_extract(self, path, index):
        """Decode one sample of an external bank to a WAV data URL (preview / send
        to the editor)."""
        try:
            b = self._snd_open_any(path)
            index = int(index)
            s = b.fsb.samples[index]
            wav = fmod_bank.sample_to_wav(b, index)
            if not wav:
                return {"ok": False, "error": "could not decode (codec %s needs the "
                        "FMOD engine, which is unavailable here)" % b.codec()}
            return {"ok": True, "name": s.name,
                    "dataURL": "data:audio/wav;base64," + base64.b64encode(wav).decode("ascii"),
                    "seconds": round(s.nsamp / float(s.freq or 1), 2)}
        except Exception as e:
            _log("snd_ext_extract error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_ext_export(self, path):
        """Decode every sample of an external bank to .wav files in
        Extracted Sounds\\<file>\\ and open the folder."""
        try:
            b = self._snd_open_any(path)
            base = os.path.splitext(os.path.basename(path))[0]
            out = os.path.join(eng.app_dir(), "Extracted Sounds", base)
            os.makedirs(out, exist_ok=True)
            n = 0
            fails = 0
            for s in b.fsb.samples:
                try:
                    wav = fmod_bank.sample_to_wav(b, s.idx)
                    if not wav:
                        fails += 1
                        continue
                    nm = s.name or ("sample_%d" % s.idx)
                    nm = "".join(c if (c.isalnum() or c in "._- ") else "_" for c in nm)
                    with open(os.path.join(out, "%03d_%s.wav" % (s.idx, nm)), "wb") as f:
                        f.write(wav)
                    n += 1
                except Exception:
                    fails += 1
            try:
                os.startfile(out)
            except Exception:
                pass
            return {"ok": True, "dir": out, "count": n, "failed": fails}
        except Exception as e:
            _log("snd_ext_export error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_diff_pair(self, orig_path, mod_path):
        """Compare an ORIGINAL bank with a MODIFIED copy and mark which sounds
        changed, so the user can pick which mods to keep (e.g. keep every custom
        sound but drop a broken one back to stock). Exact + fast when both banks
        use the same codec (compares the raw stored sample bytes); if the codecs
        differ it can't diff reliably, so it flags every sound and says so."""
        try:
            o = self._snd_open_any(orig_path)
            m = self._snd_open_any(mod_path)
            osamps, msamps = o.fsb.samples, m.fsb.samples
            same_codec = (o.codec() == m.codec())
            rows, changed = [], 0
            for i in range(len(msamps)):
                s = msamps[i]
                ch = True
                in_orig = i < len(osamps)
                if same_codec and in_orig:
                    try:
                        ch = (o.fsb.sample_bytes(i) != m.fsb.sample_bytes(i))
                    except Exception:
                        ch = True
                if ch:
                    changed += 1
                rows.append({"idx": i, "name": s.name or ("sample_%d" % i),
                             "seconds": round((s.nsamp / float(s.freq)) if s.freq else 0, 2),
                             "changed": bool(ch), "in_orig": bool(in_orig)})
            return {"ok": True, "orig": os.path.basename(orig_path),
                    "mod": os.path.basename(mod_path), "count": len(rows),
                    "changed": changed, "codec": o.codec(), "mod_codec": m.codec(),
                    "codec_mismatch": (not same_codec),
                    "rebuildable": o.codec() in fmod_bank.REBUILDABLE_CODECS, "rows": rows}
        except Exception as e:
            _log("snd_diff_pair error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_merge_pair(self, orig_path, mod_path, indices, out_name="",
                       install=False, compress=True):
        """Build a clean copy of the ORIGINAL bank with the chosen MODIFIED
        sounds spliced in. The original file on disk is NEVER modified. Each
        merged sound is logged to the library with its name + a timestamp.
        Writes to Sound Mods\\output\\<name>; install=True also copies it over the
        live game bank (a one-time .orig backup is saved first)."""
        try:
            o = self._snd_open_any(orig_path)
            m = self._snd_open_any(mod_path)
            if o.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "Original bank codec (%s) can't be "
                        "rebuilt." % o.codec()}
            idxs = sorted({int(i) for i in (indices or [])})
            if not idxs:
                return {"ok": False, "error": "No sounds selected."}
            repl, names, stamp = {}, [], time.strftime("%Y-%m-%d %H:%M")
            for i in idxs:
                if i >= len(m.fsb.samples):
                    continue
                ms = m.fsb.samples[i]
                repl[i] = {"pcm": m.fsb.sample_audio(i),
                           "freq": ms.freq, "chans": ms.chans}
                nm = ms.name or ("sample_%d" % i)
                names.append(nm)
                try:                                    # library entry: name + timestamp
                    wav = fmod_bank.sample_to_wav(m, i)
                    if wav:
                        lib_id = self._snd_lib_add(wav, "%s · merged %s.wav" % (nm, stamp))
                        self._snd_lib_use(lib_id, os.path.basename(orig_path), i, nm)
                except Exception:
                    pass
            base = (out_name or "").strip() or (
                os.path.splitext(os.path.basename(orig_path))[0] + "_merged")
            base = "".join(c if (c.isalnum() or c in "._- ") else "_" for c in base) or "merged"
            out_dir = os.path.join(self._snd_out(), "output", base)
            os.makedirs(out_dir, exist_ok=True)
            out_path = os.path.join(out_dir, os.path.basename(orig_path))
            r = fmod_bank.rebuild_bank(o, repl, out_path,
                                       compress=(bool(compress) and o.codec() == "PCM16"))
            installed, backup = False, None
            if install:
                sa = self._snd_sa()
                live = os.path.join(sa, os.path.basename(orig_path)) if sa else None
                if live and os.path.exists(live):
                    backup = live + ".orig"
                    if not os.path.exists(backup):
                        shutil.copy2(live, backup)
                    shutil.copy2(out_path, live)
                    installed = True
                    self._snd_banks.pop(live, None)
            try:
                if os.name == "nt":
                    os.startfile(out_dir)
            except Exception:
                pass
            return {"ok": True, "out": out_path, "merged": len(repl), "names": names,
                    "installed": installed,
                    "backup": (os.path.basename(backup) if backup else None),
                    "compressed": bool(r.get("compressed")),
                    "size_mb": round(r["size"] / 1048576.0, 1)}
        except Exception as e:
            _log("snd_merge_pair error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_transfer(self, ext_path, ext_index, bank_file, index,
                     loop_fill=False, all_variants=False, keep_format=True,
                     pitch=0.0, bright=0.0):
        """Transfer one sound FROM an external bank someone sent you straight onto
        a game slot -- stages it as a pending replacement (same as picking a WAV,
        but the source is a sample inside the sent bank). pitch (semitones) /
        bright (dB) apply the same tweaks the Transfer preview uses. Rebuild +
        install to write it into the game."""
        try:
            b = self._snd_get_bank(bank_file)
            index = int(index)
            if b.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "This game bank's codec (%s) can't be "
                        "rebuilt." % b.codec()}
            src = self._snd_open_any(ext_path)
            ext_index = int(ext_index)
            wav = fmod_bank.sample_to_wav(src, ext_index)
            if not wav:
                return {"ok": False, "error": "could not decode the source sound "
                        "(codec %s needs the FMOD engine)" % src.codec()}
            if pitch or bright:
                wav = fmod_bank.apply_dsp_wav(wav, pitch, bright)
            try:
                src_name = src.fsb.samples[ext_index].name
            except Exception:
                src_name = None
            name = (src_name or ("sample_%d" % ext_index)) + ".wav"
            s = b.fsb.samples[index]
            pcm, efr, ech, shorter, filled = self._snd_conform(wav, s, keep_format, loop_fill, bank_file)
            lib_id = self._snd_lib_add(wav, name)
            self._snd_stage(bank_file, index, pcm, lib_id, name, efr, ech)
            self._snd_lib_use(lib_id, bank_file, index, s.name)
            also = (self._snd_stage_variants(bank_file, b, index, wav, lib_id,
                                             name, loop_fill, keep_format)
                    if all_variants else [])
            new_frames = len(pcm) // (2 * ech)
            stored = ((len(pcm) + 31) // 32) * 32
            sustained = fmod_bank.likely_looped(
                s.name or "", (s.nsamp / float(s.freq)) if s.freq else 0)
            res = {"ok": True, "index": index, "name": name, "lib_id": lib_id,
                   "src_name": src_name or "", "target": s.name or "",
                   "seconds": round(new_frames / float(efr or 1), 2),
                   "orig_seconds": round(s.nsamp / float(s.freq or 1), 2),
                   "frames": new_frames,
                   "fits": stored <= s.datalen,
                   "grows_by": max(0, stored - s.datalen),
                   "shorter": shorter and not filled,
                   "loop_filled": filled,
                   "sustained": sustained,
                   "also_staged": also}
            res.update(self._snd_stage_report(b, index, wav, pcm, efr, ech))
            return res
        except Exception as e:
            _log("snd_transfer error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_save_wav(self, wav_b64, name="sound"):
        """Save a WAV built in the editor to Sound Mods\\created\\ and open the
        folder (so a combined/modified sound can be kept or shared)."""
        try:
            data = base64.b64decode((wav_b64 or "").split(",")[-1])
            safe = "".join(c if (c.isalnum() or c in "._- ") else "_"
                           for c in (name or "sound")).strip() or "sound"
            if not safe.lower().endswith(".wav"):
                safe += ".wav"
            out = os.path.join(self._snd_out(), "created")
            os.makedirs(out, exist_ok=True)
            path = os.path.join(out, safe)
            with open(path, "wb") as f:
                f.write(data)
            try:
                os.startfile(out)
            except Exception:
                pass
            return {"ok": True, "path": path, "dir": out}
        except Exception as e:
            _log("snd_save_wav error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_locate(self):
        """List the game's sound banks + what each one is."""
        try:
            if not fmod_bank:
                return {"ok": False, "error": "sound engine unavailable in this build"}
            sa = self._snd_sa()
            banks = fmod_bank.list_banks(sa)
            if not self._owner_ok():
                # Handout users see ONLY the weapons bank -- no music/menu/night/
                # character/VO/etc. The owner (owner.key or admin license) sees all.
                banks = [b for b in banks if b.get("is_weapons")]
            return {"ok": True, "sa_dir": sa or "", "found": bool(sa), "banks": banks}
        except Exception as e:
            _log("snd_locate error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_list_samples(self, bank_file):
        """Parse one bank and return its sample list (names, rate, length)."""
        try:
            b = self._snd_get_bank(bank_file)
            codec = b.codec()
            pend = self._snd_pending.get(os.path.basename(bank_file), {})
            samples = b.sample_list()
            for s in samples:                       # mark staged swaps for the UI
                s["staged"] = (s["index"] in pend)
            return {"ok": True, "bank": os.path.basename(bank_file), "codec": codec,
                    "count": len(samples),
                    "rebuildable": (codec in fmod_bank.REBUILDABLE_CODECS),
                    "samples": samples}
        except Exception as e:
            _log("snd_list_samples error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_preview(self, bank_file, index):
        """Decode one sample to a WAV data URL for the in-page <audio> player.

        If the slot has a staged replacement, preview THAT (as it will sound
        in-game) so the play button reflects the sound you just picked, not the
        original. Un-stage (or Restore) to hear the original again."""
        try:
            b = self._snd_get_bank(bank_file)
            index = int(index)
            s = b.fsb.samples[index]
            entry = self._snd_pending.get(os.path.basename(bank_file), {}).get(index)
            staged = bool(entry)
            if staged:
                ech = entry.get("chans", s.chans)         # kept-format entries override
                efr = entry.get("freq", s.freq)
                pcm = fmod_bank.codec_roundtrip(entry["pcm"], b.codec(), ech)
                wav = fmod_bank.pcm16_to_wav(pcm, efr, ech)
                secs = round((len(entry["pcm"]) // (2 * ech)) / float(efr or 1), 2)
            else:
                # The game plays samples stamped above 48 kHz at ~48 kHz, so a 96 kHz
                # sound is slower/deeper in-game than in the raw file (same reason a
                # rebuilt 96 kHz gun came out deep). Decode normally, then re-tag the
                # WAV to 48 kHz -- SAME samples, played slower -- so the preview matches
                # the game instead of the sped-up raw-file speed. (Staged replacements
                # are already <=48 kHz, so their preview path is unchanged.)
                wav = fmod_bank.sample_to_wav(b, index)
                prate = int(s.freq or 0)
                if wav and prate > 48000:
                    try:
                        ww = wave.open(io.BytesIO(wav), "rb")
                        pcm = ww.readframes(ww.getnframes()); ch = ww.getnchannels(); ww.close()
                        wav = fmod_bank.pcm16_to_wav(pcm, 48000, ch)
                        prate = 48000
                    except Exception:
                        prate = int(s.freq or 0)
                secs = round(s.nsamp / float(prate or 1), 2)
            if not wav:
                return {"ok": False, "error": "could not decode (codec %s needs the "
                        "FMOD engine, which is unavailable here)" % b.codec()}
            if len(wav) > self._SND_PREVIEW_CAP:
                return {"ok": True, "tooBig": True, "name": s.name,
                        "seconds": secs, "bytes": len(wav), "staged": staged}
            url = "data:audio/wav;base64," + base64.b64encode(wav).decode("ascii")
            return {"ok": True, "name": s.name, "dataURL": url,
                    "freq": s.freq, "chans": s.chans, "seconds": secs,
                    "staged": staged}
        except Exception as e:
            _log("snd_preview error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def _snd_stage_report(self, b, index, src_bytes, pcm, out_freq=None, out_chans=None):
        """Extra fields for the staging UI so the format handling is visible:
          - source vs the ACTUAL stored format (out_freq/out_chans)
          - `kept`: the replacement keeps its own stereo/rate (not folded to slot)
          - `resampled`/`rechannel`: the source was actually converted
          - `warnings`: tone heads-ups (only when we fold to the slot; a kept
            source loses nothing, so the warning is skipped).
        Best-effort: never raises, returns {} on failure so staging still works."""
        rep = {}
        try:
            s = b.fsb.samples[index]
            of = int(out_freq or s.freq)
            oc = int(out_chans or s.chans)
            rep["slot_freq"] = s.freq
            rep["slot_chans"] = s.chans
            rep["out_freq"] = of
            rep["out_chans"] = oc
            rep["kept"] = bool(of != s.freq or oc != s.chans)   # source format, not the slot's
            sf = sc = 0
            if src_bytes:
                try:
                    sf, sc, ss = fmod_bank.audio_info(src_bytes)
                    if sf:
                        rep["src_freq"] = sf
                        rep["src_chans"] = sc
                        rep["src_seconds"] = round(ss, 2)
                except Exception:
                    pass
            rep["resampled"] = bool(sf and sf != of)
            rep["rechannel"] = bool(sc and sc != oc)
            rep["warnings"] = []
            if sound_match is not None and not rep["kept"]:
                try:
                    ref = b.fsb.sample_audio(index)
                    rep["warnings"] = sound_match.slot_warnings(pcm, ref, s.freq, s.chans)
                except Exception:
                    pass
        except Exception:
            pass
        return rep

    def snd_pick_wav(self, bank_file, index, loop_fill=False, all_variants=False,
                     keep_format=True):
        """Pick an audio file from disk, convert it to the slot's format, and
        stage it as a pending replacement (nothing is written to the game yet).

        loop_fill: if the clip is shorter than the slot, tile it up to the
        original length so a sustained/looped sound stays continuous.
        all_variants: also apply it to the numbered siblings (_01/_02/_03…)."""
        try:
            b = self._snd_get_bank(bank_file)
            index = int(index)
            if b.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "This bank's codec (%s) can't be "
                        "rebuilt." % b.codec()}
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Audio (*.wav;*.mp3;*.ogg;*.flac;*.m4a;*.aac;*.opus;*.aiff)",
                            "All files (*.*)"))
            if not res:
                return {"ok": False, "cancelled": True}
            path = res[0] if isinstance(res, (list, tuple)) else res
            with open(path, "rb") as f:
                data = f.read()
            s = b.fsb.samples[index]
            pcm, efr, ech, shorter, filled = self._snd_conform(data, s, keep_format, loop_fill, bank_file)
            lib_id = self._snd_lib_add(data, os.path.basename(path))
            self._snd_stage(bank_file, index, pcm, lib_id, os.path.basename(path), efr, ech)
            self._snd_lib_use(lib_id, bank_file, index, s.name)
            also = (self._snd_stage_variants(bank_file, b, index, data, lib_id,
                                             os.path.basename(path), loop_fill, keep_format)
                    if all_variants else [])
            new_frames = len(pcm) // (2 * ech)
            stored = ((len(pcm) + 31) // 32) * 32
            sustained = fmod_bank.likely_looped(
                s.name or "", (s.nsamp / float(s.freq)) if s.freq else 0)
            res = {"ok": True, "index": index, "name": os.path.basename(path),
                   "lib_id": lib_id,
                   "seconds": round(new_frames / float(efr or 1), 2),
                   "orig_seconds": round(s.nsamp / float(s.freq or 1), 2),
                   "frames": new_frames,
                   "fits": stored <= s.datalen,
                   "grows_by": max(0, stored - s.datalen),
                   "shorter": shorter and not filled,
                   "loop_filled": filled,
                   "sustained": sustained,
                   "also_staged": also}
            res.update(self._snd_stage_report(b, index, data, pcm, efr, ech))
            return res
        except Exception as e:
            _log("snd_pick_wav error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_set_wav(self, bank_file, index, wav_b64, name="edited.wav",
                    loop_fill=False, all_variants=False, keep_format=True,
                    pitch=0.0, bright=0.0):
        """Stage a WAV built in the in-app sound editor (base64, may be a data
        URL) as a pending replacement -- same as snd_pick_wav but the audio comes
        from the editor's mixdown, not a file dialog. pitch (semitones) / bright
        (dB) apply the same tweaks the Transfer preview uses."""
        try:
            b = self._snd_get_bank(bank_file)
            index = int(index)
            if b.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "This bank's codec (%s) can't be "
                        "rebuilt." % b.codec()}
            try:
                data = base64.b64decode((wav_b64 or "").split(",")[-1])
            except Exception as e:
                return {"ok": False, "error": "bad audio data: %s" % e}
            if not data:
                return {"ok": False, "error": "no audio data"}
            if pitch or bright:
                data = fmod_bank.apply_dsp_wav(data, pitch, bright)
            s = b.fsb.samples[index]
            nm = name or "edited.wav"
            pcm, efr, ech, shorter, filled = self._snd_conform(data, s, keep_format, loop_fill, bank_file)
            lib_id = self._snd_lib_add(data, nm)
            self._snd_stage(bank_file, index, pcm, lib_id, nm, efr, ech)
            self._snd_lib_use(lib_id, bank_file, index, s.name)
            also = (self._snd_stage_variants(bank_file, b, index, data, lib_id, nm,
                                             loop_fill, keep_format)
                    if all_variants else [])
            new_frames = len(pcm) // (2 * ech)
            stored = ((len(pcm) + 31) // 32) * 32
            res = {"ok": True, "index": index, "name": nm, "lib_id": lib_id,
                   "seconds": round(new_frames / float(efr or 1), 2),
                   "orig_seconds": round(s.nsamp / float(s.freq or 1), 2),
                   "frames": new_frames, "fits": stored <= s.datalen,
                   "grows_by": max(0, stored - s.datalen),
                   "shorter": shorter and not filled, "loop_filled": filled,
                   "also_staged": also}
            res.update(self._snd_stage_report(b, index, data, pcm, efr, ech))
            return res
        except Exception as e:
            _log("snd_set_wav error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_preview_convert(self, bank_file, index, wav_b64="", pitch=0.0,
                            bright=0.0, keep_format=True, ext_path="", ext_index=-1):
        """Preview how a transferred sound WILL sound in-game: apply the pitch/
        brightness tweaks, then conform to the target slot EXACTLY as a Transfer
        would, and hand back a WAV to play. Stages NOTHING. Source is either a
        base64 WAV (`wav_b64`, a dropped/sent audio file) or a sample inside a
        sent bank (`ext_path`+`ext_index`). This is the file-side conversion only
        -- the game's live event/bus DSP can't be replayed here."""
        try:
            b = self._snd_get_bank(bank_file)
            if wav_b64:
                data = base64.b64decode((wav_b64 or "").split(",")[-1])
            elif ext_path:
                src = self._snd_open_any(ext_path)
                data = fmod_bank.sample_to_wav(src, int(ext_index))
            else:
                return {"ok": False, "error": "no source audio"}
            if not data:
                return {"ok": False, "error": "could not read the source sound"}
            if pitch or bright:
                data = fmod_bank.apply_dsp_wav(data, pitch, bright)
            s = b.fsb.samples[int(index)]
            pcm, efr, ech, shorter, filled = self._snd_conform(data, s, keep_format, False, bank_file, skip_comp=True)
            wav = fmod_bank.pcm16_to_wav(pcm, efr, ech)
            return {"ok": True,
                    "wav": "data:audio/wav;base64," + base64.b64encode(wav).decode("ascii"),
                    "freq": efr, "chans": ech,
                    "seconds": round((len(pcm) // (2 * ech)) / float(efr or 1), 2)}
        except Exception as e:
            _log("snd_preview_convert error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_clear_replacement(self, bank_file, index):
        """Un-stage one pending replacement."""
        try:
            pend = self._snd_pending.get(os.path.basename(bank_file), {})
            pend.pop(int(index), None)
            return {"ok": True, "remaining": len(pend)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def snd_pending(self, bank_file):
        """Which slots are currently staged for this bank."""
        pend = self._snd_pending.get(os.path.basename(bank_file), {})
        return {"ok": True, "indices": sorted(pend.keys())}

    def snd_rebuild(self, bank_file, install=False, compress=False):
        """Splice the staged swaps into the bank. Always writes a copy to
        Sound Mods\\output; if install=True it also backs up the live bank once
        and copies the rebuilt bank over it, so the change is live in-game.

        compress: for the PCM16 weapons bank, re-encode the whole bank to FADPCM
        so the output is ~1/3 the size (takes ~a minute, slightly lossy)."""
        try:
            bank_file = os.path.basename(bank_file)
            pend = self._snd_pending.get(bank_file, {})
            if not pend:
                return {"ok": False, "error": "No replacements staged yet."}
            b = self._snd_get_bank(bank_file, fresh=True)
            if b.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "This bank's codec (%s) can't be "
                        "rebuilt." % b.codec()}
            out_dir = os.path.join(self._snd_out(), "output",
                                   bank_file[:-len(".assets.bank")]
                                   if bank_file.endswith(".assets.bank") else bank_file)
            out_path = os.path.join(out_dir, bank_file)
            def _repl(v):                                 # keep-format entries carry freq/chans
                if v.get("chans") or v.get("freq"):
                    return {"pcm": v["pcm"], "freq": v.get("freq"), "chans": v.get("chans")}
                return v["pcm"]
            repl = {k: _repl(v) for k, v in pend.items()}
            orig_size = os.path.getsize(b.path)

            # push encode progress to the page (throttled) so the UI can show a bar
            last = [0.0]

            def _prog(done, total):
                now = time.time()
                if now - last[0] < 0.25 and done < total:
                    return
                last[0] = now
                try:
                    if self.window:
                        self.window.evaluate_js(
                            "window.sndOnProgress&&window.sndOnProgress(%d,%d)" % (done, total))
                except Exception:
                    pass

            r = fmod_bank.rebuild_bank(b, repl, out_path, compress=compress, progress=_prog)

            installed = False
            backup = None
            if install:
                sa = self._snd_sa()
                live = os.path.join(sa, bank_file)
                backup = live + ".orig"
                if not os.path.exists(backup):        # preserve the pristine copy once
                    shutil.copy2(live, backup)
                shutil.copy2(out_path, live)
                installed = True
                self._snd_banks.pop(live, None)       # cache is now stale

            self._snd_pending[bank_file] = {}         # consumed
            try:
                if os.name == "nt":
                    os.startfile(out_dir)
            except Exception:
                pass
            return {"ok": True, "out": out_path, "installed": installed,
                    "backup": (os.path.basename(backup) if backup else None),
                    "replaced": r["replaced"], "delta_bytes": r["delta_bytes"],
                    "grew": r["delta_bytes"] != 0,
                    "compressed": bool(r.get("compressed")),
                    "size_mb": round(r["size"] / 1048576.0, 1),
                    "orig_mb": round(orig_size / 1048576.0, 1)}
        except Exception as e:
            _log("snd_rebuild error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_restore(self, bank_file):
        """Undo an install: copy the .orig backup back over the live bank."""
        try:
            bank_file = os.path.basename(bank_file)
            sa = self._snd_sa()
            live = os.path.join(sa, bank_file)
            backup = live + ".orig"
            if not os.path.exists(backup):
                return {"ok": False, "error": "No backup found (nothing installed yet)."}
            shutil.copy2(backup, live)
            self._snd_banks.pop(live, None)
            return {"ok": True, "restored": bank_file}
        except Exception as e:
            _log("snd_restore error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_export_wavs(self, bank_file):
        """Decode every sample in a bank to WAVs on disk (for working on them /
        for banks too big to preview inline). Opens the folder when done."""
        try:
            b = self._snd_get_bank(bank_file)
            base = os.path.basename(bank_file)
            base = base[:-len(".assets.bank")] if base.endswith(".assets.bank") else base
            out_dir = os.path.join(self._snd_out(), "extracted", base)
            os.makedirs(out_dir, exist_ok=True)
            n = 0
            for s in b.fsb.samples:
                wav = fmod_bank.sample_to_wav(b, s.idx)
                if not wav:
                    continue
                safe = "".join(c if (c.isalnum() or c in "-_.") else "_"
                               for c in (s.name or ("sample_%d" % s.idx)))
                with open(os.path.join(out_dir, "%03d_%s.wav" % (s.idx, safe)), "wb") as f:
                    f.write(wav)
                n += 1
            try:
                if os.name == "nt":
                    os.startfile(out_dir)
            except Exception:
                pass
            return {"ok": True, "count": n, "dir": out_dir}
        except Exception as e:
            _log("snd_export_wavs error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_open_out(self):
        try:
            out_root = os.path.join(self._snd_out(), "output")
            os.makedirs(out_root, exist_ok=True)
            if os.name == "nt":
                os.startfile(out_root)  # noqa
            return {"ok": True, "path": out_root}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- staging + replaced-sound library --------------------------------
    def _snd_stage(self, bank_file, index, pcm, lib_id, name, freq=None, chans=None):
        # freq/chans are set only when the replacement KEEPS its own format
        # (stereo/rate) instead of being folded to the slot; rebuild writes them
        # into the FSB5 header so the game plays it stereo.
        e = {"pcm": pcm, "lib_id": lib_id, "name": name}
        if freq:
            e["freq"] = int(freq)
        if chans:
            e["chans"] = int(chans)
        self._snd_pending.setdefault(os.path.basename(bank_file), {})[int(index)] = e

    def _snd_comp(self):
        """(pitch_semitones, bright_db) that cancels how the game client shifts audio
        on load. Default pitch +2 (GW1DDY's Meta calibration) so a fresh install
        compensates out of the box; an explicit saved value (including 0) wins."""
        try:
            p = self.cfg.get("snd_comp_pitch")
            b = self.cfg.get("snd_comp_bright")
            return (2.0 if p is None else float(p),
                    0.0 if b is None else float(b))
        except Exception:
            return (2.0, 0.0)

    def snd_get_comp(self):
        cp, cb = self._snd_comp()
        return {"ok": True, "pitch": cp, "bright": cb}

    def snd_set_comp(self, pitch=0.0, bright=0.0):
        """Save the in-game compensation. Auto-applies to every future transfer/
        apply so sounds land right in-game without re-tweaking each one."""
        try:
            self.cfg["snd_comp_pitch"] = max(-12.0, min(12.0, float(pitch or 0.0)))
            self.cfg["snd_comp_bright"] = max(-12.0, min(12.0, float(bright or 0.0)))
            eng.save_settings(self.cfg)
            return {"ok": True, "pitch": self.cfg["snd_comp_pitch"],
                    "bright": self.cfg["snd_comp_bright"]}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _snd_orig_format(self, bank_file, index):
        """Vanilla (freq, nsamp) for a slot, read from the .orig backup -- the rate
        the sample was DESIGNED for, even when the live slot's rate was corrupted by
        an earlier mislabeled replacement (e.g. an AKM stamped 44.1k when the game
        ships it at 48k). Cached per bank; (None, None) if there's no .orig."""
        try:
            # bank_file may be a bare name ("Item.assets.bank") from the page --
            # resolve it to the live file in StreamingAssets, THEN look for .orig
            # next to it. (Appending .orig to the bare name looked in the wrong dir
            # and silently disabled the whole rate fix.)
            sa = self._snd_sa()
            base = os.path.basename(bank_file)
            live = os.path.join(sa, base) if sa else bank_file
            orig = live + ".orig"
            if not os.path.isfile(orig):
                return (None, None)
            cache = getattr(self, "_orig_fmt_cache", None)
            if cache is None:
                cache = self._orig_fmt_cache = {}
            fmt = cache.get(base)
            if fmt is None:
                ob = fmod_bank.Bank(orig)
                fmt = {x.idx: (int(x.freq), int(x.nsamp)) for x in ob.fsb.samples}
                cache[base] = fmt
            return fmt.get(int(index), (None, None))
        except Exception:
            return (None, None)

    def _snd_conform(self, data, s, keep_format, loop_fill, bank_file=None, skip_comp=False):
        """Decode `data` for slot `s`. keep_format=True keeps the source's own
        stereo; False folds channels to the slot. The RATE is set to the slot's
        VANILLA rate (from .orig when available, else the live slot) so the game --
        which plays each sample at its stamped rate -- reproduces it at the right
        speed. Returns (pcm, freq, chans, shorter, filled)."""
        # In-game compensation: the game client plays sounds a touch deeper/duller
        # than the raw file (same idea as textures rendering brighter in-game). Pre-
        # apply the user's calibrated pitch/brightness bump so the sound lands right
        # IN-GAME. The preview passes skip_comp so it shows the intended, post-cancel
        # result (what the in-game sound should end up matching).
        if not skip_comp:
            cp, cb = self._snd_comp()
            if cp or cb:
                data = fmod_bank.apply_dsp_wav(data, cp, cb)
        # target = the rate/length the slot was DESIGNED for. Reading it from .orig
        # means an earlier mislabeled mod on the LIVE slot (e.g. AKM already stamped
        # 44.1k) can't drag the reference off the true 48k.
        tfreq, tnsamp = (int(s.freq or 0), int(s.nsamp or 0))
        if bank_file:
            of, on = self._snd_orig_format(bank_file, getattr(s, "idx", -1))
            if of:
                tfreq, tnsamp = of, (on or tnsamp)
        # 48 kHz cap. The game plays REBUILT samples stamped above 48 kHz an octave
        # too deep on Meta/Quest (vanilla 96 kHz banks load through the game's own
        # path and are fine; a rebuilt bank isn't). Proven by GW1DDY's guns: his AKM,
        # authored/kept at 48 kHz, sounds right; his Sako, resampled up to the slot's
        # vanilla 96 kHz, comes out WAY too deep. So never stamp an injected sample
        # above 48 kHz -- everything above it plays wrong, and 48->96 kHz is only
        # inaudible >24 kHz content anyway. Scale the reference length to match so the
        # shorter/loop-fill checks below stay honest.
        SAFE_MAX_HZ = 48000
        if tfreq > SAFE_MAX_HZ:
            if tnsamp:
                tnsamp = int(round(tnsamp * SAFE_MAX_HZ / float(tfreq)))
            tfreq = SAFE_MAX_HZ
        if keep_format:
            pcm, freq, chans = fmod_bank.wav_to_pcm16_keep(data, tfreq, s.chans)
            if int(freq or 0) != tfreq:
                src_frames = len(pcm) // (2 * max(1, chans))
                if (tnsamp and int(freq or 0) < tfreq
                        and abs(src_frames - tnsamp) <= max(4, tnsamp // 50)):
                    # SAME audio at a MISLABELED rate: its sample count matches the
                    # slot's original AND it's stamped BELOW the target, so it's that
                    # sound saved at too low a rate (e.g. the real AKM exported as
                    # 44.1k for a 48k slot). Resampling would faithfully keep it
                    # slow/deep -- instead RE-STAMP: play the exact same samples at the
                    # real rate = correct pitch. (Only when freq < tfreq: relabeling a
                    # 96k source DOWN to 48k while keeping its samples would HALVE its
                    # pitch, so a source above the target must always be resampled.)
                    freq = tfreq
                else:
                    # a genuinely different sound at another rate -> resample so it
                    # plays as authored, conformed to the slot's rate.
                    pcm = fmod_bank.wav_to_pcm16(data, tfreq, chans)
                    freq = tfreq
        else:
            pcm = fmod_bank.wav_to_pcm16(data, tfreq, s.chans)
            freq, chans = tfreq, s.chans
        raw_frames = len(pcm) // (2 * chans) if chans else 0
        shorter = raw_frames < tnsamp
        filled = False
        if loop_fill and shorter and raw_frames > 0:
            pcm = fmod_bank.tile_pcm16(pcm, chans, tnsamp)
            filled = True
        return pcm, freq, chans, shorter, filled

    def _snd_variant_siblings(self, b, index):
        """Other samples whose name differs only by the trailing _NN (round-robin
        variants of the same sound), e.g. RifleAWP_Firing_02/_03 for _01."""
        s = b.fsb.samples[index]
        base = fmod_bank.variant_base(s.name or "")
        if not base:
            return []
        return [x.idx for x in b.fsb.samples
                if x.idx != index and fmod_bank.variant_base(x.name or "") == base]

    def _snd_stage_variants(self, bank_file, b, primary_index, data, lib_id, name,
                            loop_fill, keep_format=True):
        """Stage the same source into every numbered sibling. Returns
        [{index, name}] for those staged."""
        staged = []
        for j in self._snd_variant_siblings(b, primary_index):
            try:
                sj = b.fsb.samples[j]
                pcm, efr, ech, _sh, _fl = self._snd_conform(data, sj, keep_format, loop_fill, bank_file)
                self._snd_stage(bank_file, j, pcm, lib_id, name, efr, ech)
                self._snd_lib_use(lib_id, bank_file, j, sj.name)
                staged.append({"index": j, "name": sj.name})
            except Exception:
                _log("stage_variant %d error:\n" % j + traceback.format_exc())
        return staged

    def _snd_lib_dir(self):
        return os.path.join(self._snd_out(), "library")

    def _snd_lib_index(self):
        return os.path.join(self._snd_lib_dir(), "library.json")

    def _snd_lib_load(self):
        p = self._snd_lib_index()
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"entries": []}

    def _snd_lib_save(self, idx):
        os.makedirs(self._snd_lib_dir(), exist_ok=True)
        with open(self._snd_lib_index(), "w", encoding="utf-8") as f:
            json.dump(idx, f, indent=2)

    def _snd_lib_add(self, data, name):
        """Save a picked WAV to the library (dedup by content). Returns its id."""
        import hashlib
        try:
            os.makedirs(self._snd_lib_dir(), exist_ok=True)
            h = hashlib.sha1(data).hexdigest()[:16]
            idx = self._snd_lib_load()
            ent = next((e for e in idx["entries"] if e["id"] == h), None)
            if ent is None:
                ext = os.path.splitext(name or "")[1].lower() or ".bin"
                fn = h + ext
                with open(os.path.join(self._snd_lib_dir(), fn), "wb") as f:
                    f.write(data)
                fr, ch, secs = fmod_bank.audio_info(data)   # works for any format
                idx["entries"].append({
                    "id": h, "file": fn, "name": name, "ext": ext,
                    "added": time.strftime("%Y-%m-%d %H:%M"),
                    "freq": fr, "chans": ch, "seconds": secs, "uses": []})
                self._snd_lib_save(idx)
            return h
        except Exception:
            _log("snd_lib_add error:\n" + traceback.format_exc())
            return None

    def _snd_lib_use(self, lib_id, bank_file, index, sample_name):
        if not lib_id:
            return
        try:
            idx = self._snd_lib_load()
            e = next((x for x in idx["entries"] if x["id"] == lib_id), None)
            if not e:
                return
            bank = os.path.basename(bank_file)
            e.setdefault("uses", [])
            e["uses"] = [u for u in e["uses"]
                         if not (u.get("bank") == bank and u.get("index") == int(index))]
            e["uses"].append({"bank": bank, "index": int(index),
                              "sample": sample_name,
                              "date": time.strftime("%Y-%m-%d %H:%M")})
            self._snd_lib_save(idx)
        except Exception:
            _log("snd_lib_use error:\n" + traceback.format_exc())

    def snd_library_list(self):
        try:
            idx = self._snd_lib_load()
            ents = sorted(idx["entries"], key=lambda e: e.get("added", ""), reverse=True)
            return {"ok": True, "entries": [{
                "id": e["id"], "name": e.get("name", e["id"]),
                "seconds": e.get("seconds", 0), "freq": e.get("freq", 0),
                "chans": e.get("chans", 0), "added": e.get("added", ""),
                "uses": e.get("uses", [])} for e in ents]}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def snd_apply_library(self, bank_file, index, lib_id, loop_fill=False,
                          all_variants=False, keep_format=True):
        """Stage a past library sound into a slot (no file dialog)."""
        try:
            b = self._snd_get_bank(bank_file)
            index = int(index)
            if b.codec() not in fmod_bank.REBUILDABLE_CODECS:
                return {"ok": False, "error": "codec %s can't be rebuilt" % b.codec()}
            idx = self._snd_lib_load()
            e = next((x for x in idx["entries"] if x["id"] == lib_id), None)
            if not e:
                return {"ok": False, "error": "library item not found"}
            with open(os.path.join(self._snd_lib_dir(), e["file"]), "rb") as f:
                data = f.read()
            s = b.fsb.samples[index]
            pcm, efr, ech, shorter, filled = self._snd_conform(data, s, keep_format, loop_fill, bank_file)
            self._snd_stage(bank_file, index, pcm, lib_id, e.get("name", lib_id), efr, ech)
            self._snd_lib_use(lib_id, bank_file, index, s.name)
            also = (self._snd_stage_variants(bank_file, b, index, data, lib_id,
                                             e.get("name", lib_id), loop_fill, keep_format)
                    if all_variants else [])
            new_frames = len(pcm) // (2 * ech)
            stored = ((len(pcm) + 31) // 32) * 32
            sustained = fmod_bank.likely_looped(
                s.name or "", (s.nsamp / float(s.freq)) if s.freq else 0)
            res = {"ok": True, "index": index, "name": e.get("name", lib_id),
                   "lib_id": lib_id,
                   "seconds": round(new_frames / float(efr or 1), 2),
                   "orig_seconds": round(s.nsamp / float(s.freq or 1), 2),
                   "fits": stored <= s.datalen, "grows_by": max(0, stored - s.datalen),
                   "shorter": shorter and not filled, "loop_filled": filled,
                   "sustained": sustained, "also_staged": also}
            res.update(self._snd_stage_report(b, index, data, pcm, efr, ech))
            return res
        except Exception as e:
            _log("snd_apply_library error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_library_preview(self, lib_id):
        try:
            idx = self._snd_lib_load()
            e = next((x for x in idx["entries"] if x["id"] == lib_id), None)
            if not e:
                return {"ok": False, "error": "not found"}
            data = open(os.path.join(self._snd_lib_dir(), e["file"]), "rb").read()
            if len(data) > self._SND_PREVIEW_CAP:
                return {"ok": True, "tooBig": True, "name": e.get("name")}
            mime = fmod_bank.audio_mime(e.get("file") or "")
            return {"ok": True, "name": e.get("name"),
                    "dataURL": "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii")}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def snd_library_delete(self, lib_id):
        try:
            idx = self._snd_lib_load()
            e = next((x for x in idx["entries"] if x["id"] == lib_id), None)
            if e:
                try:
                    os.remove(os.path.join(self._snd_lib_dir(), e["file"]))
                except Exception:
                    pass
                idx["entries"] = [x for x in idx["entries"] if x["id"] != lib_id]
                self._snd_lib_save(idx)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def snd_library_open(self):
        try:
            d = self._snd_lib_dir()
            os.makedirs(d, exist_ok=True)
            if os.name == "nt":
                os.startfile(d)
            return {"ok": True, "path": d}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---- compare: your download vs in-game vs original -------------------
    def snd_compare(self, bank_file, index):
        """A/B a staged replacement: your download, the exact in-game version
        (conformed + codec), the game's original sound, and your file matched to
        that original's loudness/tone."""
        try:
            if sound_match is None:
                return {"ok": False, "error": "match engine unavailable"}
            bank_file = os.path.basename(bank_file)
            index = int(index)
            entry = self._snd_pending.get(bank_file, {}).get(index)
            if not entry:
                return {"ok": False, "need_pick": True,
                        "error": "Replace this slot first, then Compare."}
            b = self._snd_get_bank(bank_file)
            s = b.fsb.samples[index]
            staged = entry["pcm"]

            raw = None
            raw_mime = "audio/wav"
            raw_freq, raw_chans = s.freq, s.chans
            if entry.get("lib_id"):
                li = self._snd_lib_load()
                le = next((x for x in li["entries"] if x["id"] == entry["lib_id"]), None)
                if le:
                    raw = open(os.path.join(self._snd_lib_dir(), le["file"]), "rb").read()
                    raw_mime = fmod_bank.audio_mime(le["file"])
                    fr, ch, _ = fmod_bank.audio_info(raw)     # any format
                    if fr:
                        raw_freq, raw_chans = fr, ch

            ingame = fmod_bank.codec_roundtrip(staged, b.codec(), s.chans)
            orig = b.fsb.sample_audio(index)
            matched, minfo = sound_match.match(staged, orig, s.freq, s.chans, do_eq=True)

            def url_pcm(pcm):
                wav = fmod_bank.pcm16_to_wav(pcm, s.freq, s.chans)
                if len(wav) > self._SND_PREVIEW_CAP:
                    return None
                return "data:audio/wav;base64," + base64.b64encode(wav).decode("ascii")

            raw_url = None
            if raw is not None and len(raw) <= self._SND_PREVIEW_CAP:
                raw_url = "data:" + raw_mime + ";base64," + base64.b64encode(raw).decode("ascii")

            cmp_ing = sound_match.compare(ingame, orig, s.freq, s.chans)
            return {"ok": True, "index": index, "codec": b.codec(),
                    "slot_freq": s.freq, "slot_chans": s.chans,
                    "raw_freq": raw_freq, "raw_chans": raw_chans,
                    "rate_changed": raw_freq != s.freq,
                    "chans_changed": raw_chans != s.chans,
                    "raw_url": raw_url, "ingame_url": url_pcm(ingame),
                    "orig_url": url_pcm(orig), "matched_url": url_pcm(matched),
                    "match_gain_db": minfo["gain_db"], "match_eq": minfo["eq_applied"],
                    "vs_original": cmp_ing}
        except Exception as e:
            _log("snd_compare error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def snd_apply_match(self, bank_file, index):
        """Replace the staged audio with the version matched to the original
        game sound's loudness + tone (so it sits right in the game mix)."""
        try:
            if sound_match is None:
                return {"ok": False, "error": "match engine unavailable"}
            bank_file = os.path.basename(bank_file)
            index = int(index)
            entry = self._snd_pending.get(bank_file, {}).get(index)
            if not entry:
                return {"ok": False, "error": "nothing staged"}
            b = self._snd_get_bank(bank_file)
            s = b.fsb.samples[index]
            orig = b.fsb.sample_audio(index)
            matched, minfo = sound_match.match(entry["pcm"], orig, s.freq, s.chans, do_eq=True)
            entry["pcm"] = matched
            return {"ok": True, "gain_db": minfo["gain_db"], "eq": minfo["eq_applied"]}
        except Exception as e:
            _log("snd_apply_match error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    # ===== Reticle swap (custom crosshair in sharedassets1 sights) =========
    _RET_LABELS = {
        "scope_crosshair": ("AWP / Sniper scope", "The scoped-sniper crosshair"),
        "Reticle_4":       ("Red-dot preset",     "Ring + ticks + centre dot"),
        "reflex_crosshair":("Reflex sight",       "Reflex / holo crosshair"),
        "scope_circlemask":("Scope vignette",     "Black ring around the scope"),
        "tunnel_reticle":  ("Scope tunnel",       "Inner scope tunnel reticle"),
    }

    def _ret_assets(self):
        import reticle_swap as _r
        p = (self.cfg.get("reticle_asset") or "").strip()
        if p and os.path.isfile(p):
            return p
        # derive from the ACTIVE platform's PopulationONE_Data (Steam/Meta)
        pdata = self._pdata_dir()
        if pdata:
            cand = os.path.join(pdata, "sharedassets1.assets")
            if os.path.isfile(cand):
                return cand
        return _r.find_assets()

    def _ret_bdir(self):
        # Stable path so Apply and Restore always agree, no matter whether you ran
        # the exe from dist\, the app folder, or `python app.py`.
        base = os.environ.get("LOCALAPPDATA") or eng.app_dir()
        return os.path.join(base, "Pop1Forge", "Reticle Backup")

    def ret_boot(self):
        import reticle_swap as _r
        p = self._ret_assets()
        return {"found": bool(p and os.path.isfile(p)), "assets": p or "",
                "backup": _r.backup_exists(self._ret_bdir())}

    def ret_pick_assets(self):
        res = self.window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Unity assets (*.assets)", "All files (*.*)"))
        if not res:
            return {"cancelled": True}
        self.cfg["reticle_asset"] = res[0] if isinstance(res, (list, tuple)) else res
        try:
            eng.save_settings(self.cfg)
        except Exception:
            pass
        return self.ret_boot()

    def ret_list(self):
        try:
            import reticle_swap as _r
            import UnityPy
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Population: One not found. Click Locate."}
            env = UnityPy.load(p)
            found = {}
            for obj in env.objects:
                if obj.type.name != "Texture2D":
                    continue
                d = obj.read()
                nm = getattr(d, "m_Name", "")
                if nm in _r.RETICLES and nm not in found:
                    label, hint = self._RET_LABELS.get(nm, (nm, ""))
                    found[nm] = {"name": nm, "label": label, "hint": hint,
                                 "w": int(d.m_Width), "h": int(d.m_Height),
                                 "thumb": _img_to_data_url(d.image.convert("RGBA"), 240)}
            out = [found[n] for n in _r.RETICLES if n in found]
            return {"ok": True, "reticles": out, "assets": p}
        except Exception as e:
            _log("ret_list error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_apply(self, name=None, whiten=True):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        try:
            import reticle_swap as _r
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Install not found."}
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("PNG image (*.png)", "All files (*.*)"))
            if not res:
                return {"cancelled": True}
            png = res[0] if isinstance(res, (list, tuple)) else res
            info = _r.inject(p, name, png, whiten=bool(whiten), backup_dir=self._ret_bdir())
            info["thumb"] = _img_to_data_url(_r.verify(p, name).convert("RGBA"), 240)
            info["ok"] = True
            _log("reticle applied %s <- %s" % (name, png))
            return info
        except ValueError as e:               # size mismatch etc. — nothing written badly
            return {"ok": False, "error": str(e)}
        except Exception as e:
            _log("ret_apply error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_restore(self):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        try:
            import reticle_swap as _r
            done = _r.restore(self._ret_assets(), self._ret_bdir())
            if not done:
                return {"ok": False, "error": "No backup yet — nothing to restore."}
            r = self.ret_list()
            r["restored"] = done
            return r
        except PermissionError:
            return {"ok": False, "error": "Can't write the game file — close Population: One, then Restore."}
        except Exception as e:
            _log("ret_restore error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_open_backup(self):
        d = self._ret_bdir()
        if os.path.isdir(d) and os.name == "nt":
            try:
                os.startfile(d)  # noqa
            except Exception:
                pass
        return {"ok": os.path.isdir(d), "path": d}

    def ret_template(self, name=None):
        """The ORIGINAL (pristine) sight image as a PNG dataURL — always the stock
        reticle even if a mod is live now, so the editor starts from the original
        every time. Prefers the pristine backup slice; falls back to the live file."""
        try:
            import reticle_swap as _r
            import UnityPy
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Install not found."}
            env = UnityPy.load(p)
            for obj in env.objects:
                if obj.type.name != "Texture2D":
                    continue
                d = obj.read()
                if getattr(d, "m_Name", "") == name:
                    w, h = int(d.m_Width), int(d.m_Height)
                    slice_path = os.path.join(self._ret_bdir(), name + ".slice")
                    if os.path.isfile(slice_path):
                        with open(slice_path, "rb") as f:
                            img = _r._decode_slice(f.read(), w, h)   # the pristine original
                    else:
                        img = d.image.convert("RGBA")                # never modded -> live is original
                    return {"ok": True, "name": name, "w": w, "h": h,
                            "dataURL": _img_to_data_url(img, max(w, h))}
            return {"ok": False, "error": "sight not found"}
        except Exception as e:
            _log("ret_template error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_current(self, name=None):
        """The reticle CURRENTLY live in the game file (your applied mod if there is
        one, otherwise stock) as a PNG dataURL — so you can keep editing exactly
        what's in the game, not restart from the original."""
        try:
            import UnityPy
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Install not found."}
            env = UnityPy.load(p)
            for obj in env.objects:
                if obj.type.name != "Texture2D":
                    continue
                d = obj.read()
                if getattr(d, "m_Name", "") == name:
                    w, h = int(d.m_Width), int(d.m_Height)
                    img = d.image.convert("RGBA")            # the LIVE reticle, as-is
                    return {"ok": True, "name": name, "w": w, "h": h,
                            "dataURL": _img_to_data_url(img, max(w, h))}
            return {"ok": False, "error": "sight not found"}
        except Exception as e:
            _log("ret_current error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_import(self):
        """Native file dialog -> the chosen image as a PNG dataURL (alpha preserved)."""
        try:
            from PIL import Image
            res = self.window.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False,
                file_types=("Image (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "All files (*.*)"))
            if not res:
                return {"cancelled": True}
            path = res[0] if isinstance(res, (list, tuple)) else res
            img = Image.open(path).convert("RGBA")
            return {"ok": True, "w": img.width, "h": img.height,
                    "name": os.path.basename(path),
                    "dataURL": _img_to_data_url(img, 2048)}
        except Exception as e:
            _log("ret_import error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_apply_data(self, name=None, data_url=None, whiten=True, install=True):
        if not self._owner_ok():
            return {"ok": False, "error": "This feature is owner-only."}
        """Apply an aligned image (base64 PNG from the editor canvas) to a sight.

        install=True : patch the live game file (one-time backup saved).
        install=False: build a shareable copy — the modded sharedassets1.assets.resS
        + the reticle PNG + a how-to — into Reticle Output\\<name>\\, WITHOUT touching
        the game, so it can be sent to someone."""
        try:
            import reticle_swap as _r
            from PIL import Image
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Install not found."}
            if not data_url:
                return {"ok": False, "error": "no image"}
            if "," in data_url:
                data_url = data_url.split(",", 1)[1]
            img = Image.open(BytesIO(base64.b64decode(data_url))).convert("RGBA")
            if install:
                info = _r.inject_image(p, name, img, whiten=bool(whiten),
                                       backup_dir=self._ret_bdir())
                info["thumb"] = _img_to_data_url(_r.verify(p, name).convert("RGBA"), 240)
                info["ok"] = True
                info["installed"] = True
                _log("reticle applied (aligned) %s" % name)
                return info
            # build-to-file: bake the reticle INLINE into a small copy of
            # sharedassets1.assets (~20 MB) so it can be shared WITHOUT the 385 MB
            # .resS. The live game is untouched; every other texture still streams
            # from the recipient's own .resS.
            safe = "".join(c if (c.isalnum() or c in "._- ") else "_"
                           for c in (name or "reticle")) or "reticle"
            outdir = os.path.join(eng.app_dir(), "Reticle Output", safe)
            os.makedirs(outdir, exist_ok=True)
            out_assets = os.path.join(outdir, "sharedassets1.assets")
            info = _r.build_assets_file(p, name, img, out_assets, whiten=bool(whiten))
            try:                                             # small PNG for app users
                img.save(os.path.join(outdir, safe + ".png"))
            except Exception:
                pass
            try:
                mb = info.get("bytes", 0) / 1e6
                with open(os.path.join(outdir, "HOW TO USE.txt"), "w", encoding="utf-8") as f:
                    f.write(
                        "Custom Population: ONE reticle for sight '%s'.\n\n"
                        "This is the SMALL share file (~%.0f MB). It does NOT need the\n"
                        "385 MB .resS \u2014 the reticle is baked into this sharedassets1.assets.\n\n"
                        "TWO ways to use it:\n\n"
                        "1) Drop-in (no app):\n"
                        "   - Close Population: One.\n"
                        "   - Go to  ...\\PopulationONE_Data\\\n"
                        "   - BACK UP your own 'sharedassets1.assets' (copy it somewhere safe).\n"
                        "   - Replace it with the 'sharedassets1.assets' in this folder.\n"
                        "     (Leave your 'sharedassets1.assets.resS' ALONE \u2014 this reticle\n"
                        "      doesn't use it; your other textures still do.)\n"
                        "   - Launch. To undo: put your backed-up original back.\n\n"
                        "2) In POP-1 Skin Forge: Reticle tab -> Edit the SAME sight ->\n"
                        "   Import piece -> pick %s.png -> Apply to game.\n\n"
                        "Start from a STOCK sharedassets1.assets and be on the same game\n"
                        "version as the sender. A game update resets reticles \u2014 re-apply\n"
                        "after patches.\n"
                        % ((name or "reticle"), mb, safe))
            except Exception:
                pass
            if os.name == "nt":
                try:
                    os.startfile(outdir)  # noqa
                except Exception:
                    pass
            info["ok"] = True
            info["installed"] = False
            info["out"] = outdir
            info["thumb"] = _img_to_data_url(img, 240)
            _log("reticle built to small .assets %s -> %s (%.1f MB)"
                 % (name, outdir, info.get("bytes", 0) / 1e6))
            return info
        except ValueError as e:               # size mismatch — nothing written badly
            return {"ok": False, "error": str(e)}
        except PermissionError:
            return {"ok": False, "error": "Can't write the game file — close Population: One, then Apply."}
        except Exception as e:
            _log("ret_apply_data error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_export(self):
        """Write the ORIGINAL sight PNGs to a folder and open it (a base to paint on)."""
        try:
            import reticle_swap as _r
            p = self._ret_assets()
            if not p or not os.path.isfile(p):
                return {"ok": False, "error": "Install not found."}
            out = os.path.join(eng.app_dir(), "Reticle Originals")
            made = _r.export_originals(p, self._ret_bdir(), out)
            if os.name == "nt" and os.path.isdir(out):
                try:
                    os.startfile(out)  # noqa
                except Exception:
                    pass
            return {"ok": True, "count": len(made), "dir": out,
                    "files": [os.path.basename(m) for m in made]}
        except Exception as e:
            _log("ret_export error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    # ---- reticle project library (save your own designs by name) ---------
    def _ret_lib_dir(self):
        base = os.environ.get("LOCALAPPDATA") or eng.app_dir()
        return os.path.join(base, "Pop1Forge", "Reticle Library")

    def _ret_lib_index(self):
        return os.path.join(self._ret_lib_dir(), "library.json")

    def _ret_lib_read(self):
        p = self._ret_lib_index()
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"entries": []}

    def _ret_lib_write(self, idx):
        os.makedirs(self._ret_lib_dir(), exist_ok=True)
        with open(self._ret_lib_index(), "w", encoding="utf-8") as f:
            json.dump(idx, f, indent=2)

    def ret_lib_save(self, name=None, data_url=None):
        """Save the current reticle design (PNG from the editor) to the library
        under a name, with a timestamp + thumbnail. Returns its id."""
        try:
            from PIL import Image
            if not data_url:
                return {"ok": False, "error": "no image"}
            raw = data_url.split(",", 1)[1] if "," in data_url else data_url
            img = Image.open(BytesIO(base64.b64decode(raw))).convert("RGBA")
            os.makedirs(self._ret_lib_dir(), exist_ok=True)
            rid = "r" + str(int(time.time() * 1000))
            fn = rid + ".png"
            img.save(os.path.join(self._ret_lib_dir(), fn))
            nm = (str(name).strip() if name else "") or time.strftime("Reticle %Y-%m-%d %H:%M")
            idx = self._ret_lib_read()
            idx["entries"].append({
                "id": rid, "file": fn, "name": nm,
                "added": time.strftime("%Y-%m-%d %H:%M"),
                "w": img.width, "h": img.height,
                "thumb": _img_to_data_url(img, 160)})
            self._ret_lib_write(idx)
            _log("reticle saved to library: %s (%s)" % (nm, rid))
            return {"ok": True, "id": rid, "name": nm}
        except Exception as e:
            _log("ret_lib_save error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_lib_list(self):
        try:
            idx = self._ret_lib_read()
            ents = sorted(idx["entries"], key=lambda e: e.get("added", ""), reverse=True)
            return {"ok": True, "entries": [{
                "id": e["id"], "name": e.get("name", e["id"]),
                "added": e.get("added", ""), "thumb": e.get("thumb", "")}
                for e in ents]}
        except Exception as e:
            _log("ret_lib_list error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_lib_load(self, rid=None):
        """Return a saved reticle's full-res PNG as a data URL, to load into the editor."""
        try:
            idx = self._ret_lib_read()
            e = next((x for x in idx["entries"] if x["id"] == rid), None)
            if not e:
                return {"ok": False, "error": "not found"}
            fp = os.path.join(self._ret_lib_dir(), e["file"])
            if not os.path.isfile(fp):
                return {"ok": False, "error": "file missing"}
            b = open(fp, "rb").read()
            return {"ok": True, "name": e.get("name", ""),
                    "dataURL": "data:image/png;base64," + base64.b64encode(b).decode()}
        except Exception as e:
            _log("ret_lib_load error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_lib_rename(self, rid=None, name=None):
        try:
            idx = self._ret_lib_read()
            e = next((x for x in idx["entries"] if x["id"] == rid), None)
            if not e:
                return {"ok": False, "error": "not found"}
            e["name"] = (str(name).strip() if name else "") or e.get("name", "")
            self._ret_lib_write(idx)
            return {"ok": True, "name": e["name"]}
        except Exception as e:
            _log("ret_lib_rename error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_lib_delete(self, rid=None):
        try:
            idx = self._ret_lib_read()
            e = next((x for x in idx["entries"] if x["id"] == rid), None)
            if not e:
                return {"ok": False, "error": "not found"}
            try:
                os.remove(os.path.join(self._ret_lib_dir(), e["file"]))
            except Exception:
                pass
            idx["entries"] = [x for x in idx["entries"] if x["id"] != rid]
            self._ret_lib_write(idx)
            return {"ok": True}
        except Exception as e:
            _log("ret_lib_delete error:\n" + traceback.format_exc())
            return {"ok": False, "error": str(e)}

    def ret_lib_open(self):
        d = self._ret_lib_dir()
        os.makedirs(d, exist_ok=True)
        if os.name == "nt":
            try:
                os.startfile(d)  # noqa
            except Exception:
                pass
        return {"ok": True, "path": d}


